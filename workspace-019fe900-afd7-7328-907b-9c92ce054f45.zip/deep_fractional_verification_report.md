# Deep Fractional Jet-Spectrum Verification

This report stress-tests the fractional jet-spectrum research note using Fourier-mode models for the cat map, exact symmetric-power jet resonance calculations, a two-cycle obstruction witness, and Green-truncation tail tests.

Overall: **PASS**

- ✅ **fourier_threshold_lambda_Lambda_minus_1** — s=(below,critical,above) data (s,last,ratio last/last-5)=[(0.65, 0.00037947919212620395, 0.18558516575586811), (1, 1.3763819204711736, 1.0), (1.35, 4992.176726174458, 5.388361704057056)]
- ✅ **fourier_threshold_lambda_Lambda_minus_2** — s=(below,critical,above) data (s,last,ratio last/last-5)=[(1.65, 0.000522308299237513, 0.18558516575586803), (2, 1.8944271909999175, 1.0000000000000007), (2.35, 6871.141789703501, 5.388361704057058)]
- ✅ **fourier_threshold_lambda_Lambda_minus_3** — s=(below,critical,above) data (s,last,ratio last/last-5)=[(2.65, 0.0007188956999825589, 0.18558516575586803), (3, 2.6074553353412706, 1.0), (3.35, 9457.315332341821, 5.388361704057057)]
- ✅ **periodic_principal_jet_resonance_order_1** — lambda=Lambda^-1; min |lambda*eig(Sym^k A^-T)-1|=0.000e+00; scaled eigs=[0.14589803 1.        ]
- ✅ **periodic_principal_jet_resonance_order_2** — lambda=Lambda^-2; min |lambda*eig(Sym^k A^-T)-1|=4.441e-16; scaled eigs=[0.02128624 0.14589803 1.        ]
- ✅ **periodic_principal_jet_resonance_order_3** — lambda=Lambda^-3; min |lambda*eig(Sym^k A^-T)-1|=0.000e+00; scaled eigs=[0.00310562 0.02128624 0.14589803 1.        ]
- ✅ **periodic_principal_jet_resonance_order_4** — lambda=Lambda^-4; min |lambda*eig(Sym^k A^-T)-1|=0.000e+00; scaled eigs=[4.53103854e-04 3.10562002e-03 2.12862363e-02 1.45898034e-01
 1.00000000e+00]
- ✅ **two_cycle_first_jet_not_surjective_witness** — C0 det=-3/4, first-jet det=0, rank=1, augmented rank for rhs(1,0)=2
- ✅ **green_truncation_tail_behavior_s_1.5** — tail10-20=3.409e-02, tail20-30=2.772e-04, ratio=0.00813
- ✅ **green_truncation_tail_behavior_s_2.0** — tail10-20=1.894e+01, tail20-30=1.894e+01, ratio=1
- ✅ **green_truncation_tail_behavior_s_2.25** — tail10-20=8.441e+02, tail20-30=9.361e+03, ratio=11.1
- ✅ **holder_green_operator_series_theta_0.5** — partial=2, bound=2
- ✅ **holder_green_operator_series_theta_0.9** — partial=10, bound=10
- ✅ **holder_green_operator_series_theta_0.99** — partial=100, bound=100
- ✅ **holder_green_operator_series_theta_1_diverges** — partial sum for theta=1 after 5000 terms=5000, no uniform bound
- ✅ **fractional_note_display_math_balanced** — 69 vs 69
- ✅ **fractional_note_inline_math_balanced** — 140 vs 140
- ✅ **text_has_operator_norms_on_\(C^\alpha** — operator norms on \(C^\alpha\) include all Hölder variation
- ✅ **text_has_full_triangular_jet_return_m** — full triangular jet return map
- ✅ **text_has_k+\alpha\le_r+\beta** — k+\alpha\le r+\beta
- ✅ **text_has_Hyperbolic_toral_base** — Hyperbolic toral base
- ✅ **text_has_Periodic_jet-resonance_obstr** — Periodic jet-resonance obstruction

## Interpretation

- The cat-map Fourier model verifies the predicted threshold rho_s = lambda Lambda^s: below threshold tails decay, at threshold they are neutral, and above threshold they grow.
- Symmetric-power computations verify periodic jet resonances when lambda=Lambda^{-k}.
- The two-cycle witness verifies failure of first-jet surjectivity despite C0 invertibility.
- The operator-radius formulation is validated in a sequence model: summable radii below one and divergence at radius one.