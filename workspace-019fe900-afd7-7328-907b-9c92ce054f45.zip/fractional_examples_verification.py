from pathlib import Path
import math, json
import sympy as sp
results=[]
def add(n,ok,d): results.append({'name':n,'ok':bool(ok),'detail':d})
Lambda=(3+math.sqrt(5))/2
for N in [1,2,3]:
    lam=Lambda**(-N)
    sstar=math.log(1/lam)/math.log(Lambda)
    add(f'toral_threshold_N_{N}', abs(sstar-N)<1e-12, f'lambda=Lambda^-{N}, s*={sstar}')
# radius below and at threshold for N=2
lam=Lambda**(-2)
add('toral_radius_below_threshold', lam*(Lambda**1.5)<1, f'radius s=1.5: {lam*Lambda**1.5}')
add('toral_radius_at_threshold', abs(lam*(Lambda**2)-1)<1e-12, f'radius s=2: {lam*Lambda**2}')
# isometry radius
for lam in [0.2,0.7,0.95]:
    add(f'isometry_radius_{lam}', lam<1, f'rho_s={lam} for all allowed s')
s=Path('/home/user/fractional_jet_spectrum_research_note.md').read_text()
add('text_has_toral_example', 'Hyperbolic toral base' in s and 'regularity threshold' in s, 'toral example present')
add('text_has_isometry_example', 'Isometric base dynamics' in s, 'isometry example present')
all_ok=all(r['ok'] for r in results)
lines=['# Fractional Examples Verification','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for r in results: lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['name']}** — {r['detail']}")
Path('/home/user/fractional_examples_verification_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results},indent=2))
