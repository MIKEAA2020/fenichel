from pathlib import Path
import re,json
p=Path('/home/user/final_manuscript_external_hps_closed.md')
s=p.read_text()
checks=[]
def add(n,ok,d): checks.append({'name':n,'ok':bool(ok),'detail':d})
add('display_balanced',s.count('\\[')==s.count('\\]'),f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_balanced',s.count('\\(')==s.count('\\)'),f"{s.count('\\(')} vs {s.count('\\)')}")
add('env_balanced',re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s),str((re.findall(r'\\begin\{([^}]+)\}',s),re.findall(r'\\end\{([^}]+)\}',s))))
for pat in ['maps center cones strictly','follows by the same argument','Your assessment','Final honest','What has been repaired','invalid Lipschitz','false Lipschitz']:
 add('absent_'+pat[:18],pat not in s,pat)
for pat in ['full two-sided HPS Hadamard graph transform','not the separate stable-forward/unstable-backward component transform','Appendix J. External two-sided HPS input and reduction','External HPS--Banach invariant-section theorem','Bates--Lu--Zeng [9]','compatibility of the forward and backward base correspondences','Affine examples can satisfy','[9] P. W. Bates, K. Lu, C. Zeng']:
 add('present_'+pat[:22],pat in s,pat)
all_ok=all(c['ok'] for c in checks)
lines=['# External HPS Closure Integrity Check','',f'Manuscript: `{p}`','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for c in checks: lines.append(f"- {'✅' if c['ok'] else '❌'} **{c['name']}** — {c['detail']}")
Path('/home/user/external_hps_integrity_check_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'checks':checks},indent=2))
