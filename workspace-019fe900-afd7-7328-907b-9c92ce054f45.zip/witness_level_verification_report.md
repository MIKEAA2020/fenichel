# Witness-Level Verification Report

This report records small explicit witnesses and counter-witnesses for the most fragile mathematical points in the manuscript. Unlike random tests, these examples are meant to be inspectable by hand.

Overall status: **PASS**

## ✅ W1_exact_target_fibre_projection_witness

In a two-point bundle with varying splitting, target-fibre projection solves the cohomological equation exactly; source-fibre projection does not.

```json
{
  "Q0": "Matrix([[1, 0], [0, 1]])",
  "Q1": "Matrix([[1, 1], [0, 1]])",
  "B0": "Matrix([[1/2, 2], [0, 2]])",
  "B1": "Matrix([[1/2, -1/2], [0, 2]])",
  "q0": "Matrix([[4], [3]])",
  "q1": "Matrix([[2], [-1]])",
  "z0_exact": "Matrix([[10/3], [-5/3]])",
  "z1_exact": "Matrix([[7/3], [-1/3]])",
  "z0_green_target": "Matrix([[10/3], [-5/3]])",
  "z1_green_target": "Matrix([[7/3], [-1/3]])",
  "correct_residual": "[0, 0, 0, 0]",
  "z0_wrong_source": "Matrix([[20/3], [-5/3]])",
  "z1_wrong_source": "Matrix([[7], [-1/3]])",
  "wrong_residual": "[3, 0, 1, 0]"
}
```

## ✅ W2_C0_invertible_but_C1_jet_singular

A two-cycle has an invertible C0 cohomological operator but singular first-jet operator when first-order bunching fails.

```json
{
  "A_C0": "Matrix([[-1/2, 1], [1, -1/2]])",
  "det_A_C0": "-3/4",
  "A_jet": "Matrix([[-1, 1], [1, -1]])",
  "det_A_jet": "0",
  "normal_product": "1/4",
  "jet_product": "1"
}
```

## ✅ W3_exact_loss_of_dichotomy_singular

If B=I over f=id, the cohomological operator on constants has nontrivial kernel.

```json
{
  "I_minus_B": "Matrix([[0, 0], [0, 0]])",
  "rank": 0,
  "kernel_vector": "any constant vector"
}
```

## ✅ W4_naive_Lipschitz_composition_counterexample

For a triangular wave of period p, h(x+p/2)-h(x) has Lipschitz constant 2 Lip(h), so small base shifts need not be small in Lipschitz norm on a Lipschitz ball.

```json
{
  "period": "1/25",
  "Lip_h": "100",
  "shift": "p/2",
  "Lip_difference": "200",
  "ratio": "2"
}
```

## ✅ W5_parabolic_rho_ge_one_divergence_witness

For rho>1, the smoothing convolution is singular at t=s; lower bounds grow as the cutoff tends to zero.

```json
{
  "rho": "6/5",
  "alpha_minus_gamma": "1/2",
  "lower_cutoff_1e-2": "4.4089162",
  "lower_cutoff_1e-8": "181.80764"
}
```

## ✅ W6_parabolic_valid_gamma_bound_witness

For rho=1/2 and alpha-gamma=1, the convolution bound equals Gamma(1/2)=sqrt(pi).

```json
{
  "rho": "1/2",
  "alpha_minus_gamma": "1",
  "bound": "sqrt(pi)",
  "numeric": 1.772453850905516
}
```

## ✅ W7_HPS_constant_selection_witnesses

Explicit constants show a valid contraction/radius choice and an invalid one.

```json
{
  "valid": {
    "C": 2,
    "gap": 1,
    "N": 10,
    "delta": 0.001,
    "omega": 0.01,
    "L": 0.01,
    "rho": 0.1,
    "q": 0.04209079985952497,
    "Cdelta+q*rho": 0.006209079985952497
  },
  "invalid": {
    "C": 2,
    "gap": 0.1,
    "N": 1,
    "delta": 0.1,
    "omega": 0.2,
    "L": 0.2,
    "q": 2.809674836071919
  }
}
```

## ✅ W8_local_diffeomorphism_covering_not_diffeomorphism

The circle map theta -> 2 theta mod 2pi is a local diffeomorphism and a twofold covering, not a diffeomorphism; closeness to identity is needed in Lemma 5.2.

```json
{
  "map": "S^1 -> S^1, z -> z^2",
  "degree": 2,
  "preimages_of_1": [
    "1",
    "-1"
  ]
}
```

## Interpretation

- W1 gives an exact two-fibre witness that the projection of q_j must be taken in the target fibre E_{m_{j+1}}.
- W2 shows why C^k bunching is stronger than C^0 dichotomy: the first-jet operator can be singular even when the C^0 operator is invertible.
- W3, W5, and W6 certify the necessity of dichotomy and parabolic smoothing hypotheses.
- W4 certifies why the proof uses C^0 graph contraction plus cone invariance rather than a naive Lipschitz-norm contraction.
- W7 records concrete constants for the graph-transform contraction/radius scheme.
- W8 certifies that Lemma 5.2 needs closeness to the identity, not just local diffeomorphism.