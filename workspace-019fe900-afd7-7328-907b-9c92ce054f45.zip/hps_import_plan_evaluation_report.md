# Evaluation of Proposed HPS Import/Verification Plan

## Verdict

The plan is directionally correct: the failed componentwise matching lemma should not be repaired, and the manuscript should rely on the genuine two-sided HPS Hadamard graph-transform theorem for the full normally hyperbolic case.

However, the proposed “Banach-bundle verification lemma” should not be inserted as a proved theorem in the strong form stated. It still compresses the core HPS matching argument into the sentence that compatibility is part of the HPS construction. That is acceptable as an explanation of the imported theorem, but not as a new self-contained proof.

## What was implemented

I implemented the safe parts:

1. The manuscript now states explicitly that the graph transform in Theorem 4.1 is the full two-sided HPS Hadamard graph transform, not the separate stable-forward/unstable-backward component transform.
2. It states that component equations alone do not imply invariance.
3. It explains that finite-dimensional compatibility of the forward and backward base correspondences is part of the HPS graph-transform theorem.
4. It explains that in Banach fibres the required estimates are Banach contraction estimates in local bundle charts, patched by transported differences.
5. It records that affine examples can satisfy the separate component equations while failing the full graph equation.

## What was not implemented

I did not insert Theorem R.1 and Lemma R.2 as a new proof closing the full two-sided Banach-bundle theorem. That would overstate what has been proved. The manuscript remains honest: Theorem 4.1 is the structural HPS input.

## Current status

The full two-sided Banach-bundle HPS theorem is handled by the HPS structural input and the precise explanatory text now added. Surrounding special and linear cases are proved in Appendices A--I.
