# Randomized Counterexample Search Report

This search tries to falsify the manuscript formulae in random finite-dimensional models and also deliberately violates hypotheses to see whether the estimates fail as expected.

Overall status: **PASS**

- ✅ **random_valid_hyperbolic_green_formula_trials** — trials=200, max correct error=3.11e-15, median=8.33e-16, max cond=1.03e+01, failures=[]
- ✅ **random_wrong_source_projection_counterexamples_found** — wrong projection error >1e-3 in 200/200; median wrong error=1.44e+00; max=2.96e+00
- ✅ **constant_splitting_control_source_equals_target_projection** — constant splitting: max wrong-projection error=6.66e-16, max correct=6.66e-16
- ✅ **random_rate_gap_valid_cases_bounded** — valid bounded cases=135; tested random beta<gamma<alpha
- ✅ **random_rate_gap_violations_produce_counterexamples** — invalid blow-up cases=127; examples=[(1.19403081781106, 0.6908973385137458, 1.8149310707265884, 8.255938288476165e+32, 2.1070093262312564), (1.186786567807137, 0.03443646169097936, 0.012825640040844015, 1.405368025208738, 11187.967323618806), (0.9408414499077213, 0.43606010290547265, 1.9294449697099412, 8.997781663394648e+51, 1.5987530640963104)]
- ✅ **random_parabolic_valid_convolution_matches_bound** — valid parabolic trials matching gamma-bound=120/120
- ✅ **random_parabolic_gamma_ge_alpha_counterexamples** — invalid gamma>=alpha large-growth cases=64/80; examples=[(0.7249958818836343, 1.1733650941283784, 1.5477670584580172, 810104933.7400943), (0.24999759974103308, 0.8570835151477925, 1.1861317993424765, 415235149.81062424), (0.5868075883974169, 1.3030973231300171, 1.7612885067730657, 175657976499.34875)]
- ✅ **random_hps_constant_selection_valid_examples_exist** — valid random choices=197/200
- ✅ **random_hps_bad_constants_fail_as_expected** — bad choices failing contraction/radius=200/200

## Interpretation

- No randomized valid hyperbolic cocycle trial falsified the Green formula.
- Random varying-splitting trials produced many counterexamples to the wrong source-fibre projection convention, supporting the target-fibre projection used in the manuscript.
- Deliberate violations of the rate-gap and parabolic smoothing hypotheses produced blow-up or loss of contraction as expected.
- These are randomized finite-dimensional falsification tests, not proofs of the infinite-dimensional theorems.