# Global Stable Gap Integrity Check

Manuscript: `/home/user/final_manuscript_global_stable_gap_closed.md`

Overall: **PASS**

- ✅ **display_balanced** — 437 vs 437
- ✅ **inline_balanced** — 802 vs 802
- ✅ **env_balanced** — (['pmatrix', 'aligned', 'aligned', 'aligned', 'pmatrix', 'aligned'], ['pmatrix', 'aligned', 'aligned', 'aligned', 'pmatrix', 'aligned'])
- ✅ **absent_maps center cones ** — maps center cones strictly
- ✅ **absent_follows by the sam** — follows by the same argument
- ✅ **absent_Your assessment** — Your assessment
- ✅ **absent_Final honest** — Final honest
- ✅ **absent_What has been repa** — What has been repaired
- ✅ **absent_invalid Lipschitz** — invalid Lipschitz
- ✅ **absent_false Lipschitz** — false Lipschitz
- ✅ **present_Appendix A. The \(C^k\** — Appendix A. The \(C^k\) Banach-bundle cohomological inverse theorem
- ✅ **present_Appendix B. Strong fib** — Appendix B. Strong fibres from a half-line Perron method
- ✅ **present_Appendix C. Roughness ** — Appendix C. Roughness of exponential dichotomies in Banach bundles
- ✅ **present_Appendix D. A normally** — Appendix D. A normally attracting Banach-bundle graph transform
- ✅ **present_Appendix E. Close-base** — Appendix E. Close-base roughness by a linear graph transform
- ✅ **present_Appendix F. Parameter ** — Appendix F. Parameter expansions of invariant sections
- ✅ **present_Appendix G. Reduction ** — Appendix G. Reduction of flows to time maps
- ✅ **present_Appendix H. Globalizat** — Appendix H. Globalization of local stable fibres
- ✅ **present_W_N^s(M):=F^{-N}** — W_N^s(M):=F^{-N}
- ✅ **present_\pi^s(y):=F^{-N}** — \pi^s(y):=F^{-N}
- ✅ **present_immersed lamination** — immersed lamination
- ✅ **absent_broken_\delta_N** — \delta_

- ✅ **absent_broken_h_N** — h_

- ✅ **absent_broken_f_N** — f_

- ✅ **absent_broken_g_N** — g_

- ✅ **absent_broken_b_N** — b_

- ✅ **absent_broken_D_N** — D_

- ✅ **absent_broken__N\gamma** — _
\gamma
- ✅ **absent_broken_-N\eta** — -
\eta
- ✅ **absent_broken_p+N\xi** — p+
\xi
- ✅ **absent_broken_yNa** — y
a