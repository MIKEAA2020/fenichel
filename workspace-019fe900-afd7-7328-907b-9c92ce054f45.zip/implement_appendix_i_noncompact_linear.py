from pathlib import Path
p=Path('/home/user/final_manuscript_global_stable_gap_closed.md')
s=p.read_text()

# Add Section 8.3 cross-reference.
s=s.replace('''Let \\(M\\) be a complete finite-dimensional \\(C^{r+1}\\) manifold with bounded geometry. Bounded geometry may be taken to include a positive injectivity radius, uniformly bounded curvature and covariant derivatives up to the required order, a uniformly controlled bundle atlas, a uniform tubular radius, uniformly bounded bundle projections, and uniformly bounded derivatives of \\(f\\), \\(f^{-1}\\), \\(B\\), and the nonlinear terms. Assume uniform exponential dichotomy estimates and uniform bunching constants.''',
'''Let \\(M\\) be a complete finite-dimensional \\(C^{r+1}\\) manifold with bounded geometry. Bounded geometry may be taken to include a positive injectivity radius, uniformly bounded curvature and covariant derivatives up to the required order, a uniformly controlled bundle atlas, a uniform tubular radius, uniformly bounded bundle projections, and uniformly bounded derivatives of \\(f\\), \\(f^{-1}\\), \\(B\\), and the nonlinear terms. Assume uniform exponential dichotomy estimates and uniform bunching constants. Appendix I proves the corresponding noncompact uniform cohomological inverse theorem in \\(C_b^k\\) spaces.''')

appendix_i = r'''
## Appendix I. Uniform cohomological inverses on noncompact bases

This appendix gives a theorem-level version of the linear part of the noncompact extension. It shows precisely how compactness in Theorem 3.1 may be replaced by bounded geometry and uniform estimates.

### I.1. Setting and statement

Let \(M\) be a complete finite-dimensional \(C^{r+1}\) manifold with bounded geometry, and let \(E\to M\) be a \(C^{r+1}\) Banach bundle with bounded geometry: uniformly controlled local trivializations, uniformly bounded transition maps and derivatives up to order \(r+1\), and a uniformly bounded connection. Let

\[
f:M\to M
\]

be a \(C^{r+1}\) diffeomorphism with uniformly bounded derivatives of \(f\) and \(f^{-1}\) up to order \(r+1\). Let

\[
B_m:E_m\to E_{f(m)}
\]

be a \(C^r\) bundle automorphism with uniformly bounded derivatives up to order \(r\), preserving a \(C^r\) splitting

\[
E=E^s\oplus E^u
\]

with uniformly bounded projections and uniformly bounded derivatives up to order \(r\).

Assume a uniform exponential dichotomy: for every orbit \(m_n=f^n(m)\),

\[
\|\Phi^s(n,k)\|\le C\lambda^{n-k},
\qquad n\ge k,
\]

and

\[
\|\Phi^u(k,n)\|\le C\lambda^{n-k},
\qquad n\ge k,
\]

with constants independent of \(m\). Assume also uniform \(j\)-bunching for \(0\le j\le r\): there are constants \(C_j>0\) and \(\theta_j\in(0,1)\), independent of \(m\), such that

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m_n)\|^j
\le C_j\theta_j^n,
\qquad n\ge0,
\]

and

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|^j
\le C_j\theta_j^n,
\qquad n\ge0.
\]

Let \(C_b^k(M,E)\) denote the space of bounded \(C^k\) sections whose covariant derivatives up to order \(k\) are bounded and uniformly continuous in the bounded-geometry atlas. Then, for every \(0\le k\le r\),

\[
\mathcal A:C_b^k(M,E)\to C_b^k(M,f^*E),
\qquad
(\mathcal A\zeta)(m)=\zeta(f(m))-B_m\zeta(m),
\]

is an isomorphism, and

\[
\|\mathcal A^{-1}q\|_{C_b^k}
\le C_k\|q\|_{C_b^k}.
\]

### I.2. The \(C_b^0\) Green inverse

For \(q\in C_b^0(M,f^*E)\), define along the orbit \(m_n=f^n(m)\)

\[
q_n=q(m_n)\in E_{m_{n+1}}.
\]

Decompose in the target fibre,

\[
q_n^
\sigma=P_{m_{n+1}}^
\sigma q_n.
\]

Set

\[
\zeta_n^s
=
\sum_{j=-\infty}^{n-1}\Phi^s(n,j+1)q_j^s,
\]

and

\[
\zeta_n^u
=
-
\sum_{j=n}^{\infty}\Phi^u(n,j+1)q_j^u.
\]

The uniform dichotomy gives

\[
\|\zeta_n^s\|
\le
\frac{C\sup_m\|P_m^s\|}{1-
\lambda}
\|q\|_{C_b^0},
\]

and the same estimate for the unstable term. Hence

\[
\|\mathcal Gq\|_{C_b^0}
\le C\|q\|_{C_b^0}.
\]

The same telescoping calculation as in Section 3 gives

\[
\mathcal A\mathcal Gq=q.
\]

A bounded homogeneous solution has vanishing stable part by taking the initial time to \(-\infty\), and vanishing unstable part by taking the terminal time to \(+\infty\). Thus the bounded solution is unique.

Uniform continuity follows because the summands are uniformly continuous in the bounded-geometry atlas, with a common exponential majorant. Uniform convergence of uniformly continuous summands gives a uniformly continuous sum. Therefore

\[
\mathcal G:C_b^0(M,f^*E)
\to
C_b^0(M,E)
\]

is a bounded inverse.

### I.3. Higher derivatives

The higher-order proof is the uniform version of Appendix A. Differentiating the cohomological equation in uniformly controlled charts gives, at order \(k\), a principal equation for the \(k\)-jet

\[
J\mapsto B_mJ\circ(Df(m)^{-1})^{\otimes k}.
\]

The stable part of the induced \(k\)-jet cocycle is bounded by

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m_n)\|^k,
\]

and the backward unstable part by

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|^k.
\]

The uniform \(k\)-bunching hypothesis gives a uniform exponential dichotomy for the induced jet cocycle. Applying the \(C_b^0\) inverse to the induced equation yields

\[
\|D^k\zeta\|_{C_b^0}
\le C_k\|q\|_{C_b^k}
\]

after lower-order terms have been controlled by induction. The bounded-geometry assumptions guarantee that all connection coefficients, transition functions, and Faà di Bruno terms have uniform constants. Induction gives

\[
\|
\mathcal Gq\|_{C_b^k}
\le C_k\|q\|_{C_b^k}.
\]

### I.4. Role in the noncompact extension

This theorem supplies the linear inverse needed for a noncompact graph transform or invariant-section theorem. The nonlinear step still requires a uniform tube, uniform admissible cones or matching estimates, and a graph transform whose contraction constants are independent of the base point. Those are exactly the additional hypotheses stated in Section 8.3.

---
'''
# clean artifacts
appendix_i=appendix_i.replace('q_n^\n\\sigma','q_n^\\sigma')
appendix_i=appendix_i.replace('P_{m_{n+1}}^\n\\sigma','P_{m_{n+1}}^\\sigma')
appendix_i=appendix_i.replace('1-\n\\lambda','1-\\lambda')
appendix_i=appendix_i.replace('\\|\n\\mathcal Gq','\\|\\mathcal Gq')

marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_i+'\n## References')

s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, and Appendix H proves the globalization of local stable fibres under explicit domain assumptions.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, Appendix H proves the globalization of local stable fibres under explicit domain assumptions, and Appendix I proves the uniform noncompact cohomological inverse theorem.''')

out=Path('/home/user/final_manuscript_noncompact_linear_gap_closed.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
