# Deep Content-Loss Scan for Integrated Manuscript

File scanned: `/home/user/journal_manuscript_integrated.md`

Overall required-content status: **PASS**

- Required checks: 25
- Missing/suspect required checks: 0

## Checklist
- ✅ **title_abstract_architecture** — Title/abstract integrated architecture and novelty framing
- ✅ **claim_hierarchy** — Claim hierarchy table retained
- ✅ **notation** — Notation section retained
- ✅ **geometry_setup** — Banach tubular setup and transports
- ✅ **dichotomy_bunching** — Dichotomy and invariant bunching
- ✅ **green_inverse** — C0 Green inverse and target projection
- ✅ **ck_caveat** — Ck smooth splitting vs continuous projection caveat
- ✅ **jet_equations** — First and higher jet equations
- ✅ **hps_import** — HPS imported structural input and component warning
- ✅ **admissible_graph** — Admissible class and graph metric
- ✅ **remainder_estimates** — Remainder estimates incl base derivative
- ✅ **persistence** — Main persistence theorem pieces
- ✅ **parameter_expansion** — Parameter expansion and Appendix F
- ✅ **strong_fibres** — Strong fibres Perron
- ✅ **global_stable** — Global stable Appendix H
- ✅ **flow** — Flow reduction Appendix G
- ✅ **roughness** — Roughness appendices C/E
- ✅ **fractional** — Fractional jet spectrum Appendix K
- ✅ **resonance** — Resonance obstruction and Fredholm
- ✅ **examples** — Model examples retained
- ✅ **extensions** — Extension architecture retained
- ✅ **noncompact_linear** — Noncompact Appendix I
- ✅ **appendices_all** — Appendices A-K present
- ✅ **references** — References include major sources
- ✅ **forbidden_overclaims** — Forbidden overclaims absent
  - Note: absence check
- ✅ **verification_reports** — Verification reports retained in workspace

## Source-heading heuristic
- Represented headings/topics: 335
- Not directly represented: 19
Likely omitted headings are listed below; many are duplicate/meta headings or intentionally excluded development material:
- `fractional_jet_spectrum_research_note.md`: 5. Proof of Theorem 4.1
- `fractional_jet_spectrum_research_note.md`: 5.2. Hölder Green lemma
- `audit of pasive voice.txt`: 1.4 Linear theorem
- `audit of pasive voice.txt`: 2.3 Adapted-norm warning
- `audit of pasive voice.txt`: 4. Optional restorations
- `audit of pasive voice.txt`: 4.1 Lipschitz-metric counterexample
- `unified_manuscript.md`: Proof outline of Theorem A
- `unified_manuscript.md`: Proof outline of Theorem B
- `unified_manuscript.md`: 7. Correct stable-fibre theorem
- `unified_manuscript.md`: 1.1. Banach scale
- `unified_manuscript.md`: 5.1. Scales of Banach spaces
- `unified_manuscript.md`: 4. Cone fields
- `unified_manuscript.md`: Proof outline
- `unified_manuscript.md`: 2. Strong stable fibres
- `unified_manuscript.md`: 13. What is not covered by this theorem
- `unified_manuscript.md`: Step 1
- `unified_manuscript.md`: Step 2
- `unified_manuscript.md`: Step 3
- `unified_manuscript.md`: Step 4

## Conclusion
No required substantive content loss was detected. The integrated manuscript preserves the surviving architecture, proofs, fractional-spectrum novelty, HPS import caveat, extension architecture, and verification trail.