from pathlib import Path
p=Path('/home/user/final_manuscript_gap_resolutions.md')
s=p.read_text()

# Add mention after structural HPS paragraph if not already
s=s.replace('''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. A fully self-contained proof must carry out the two-sided Hadamard matching construction, the transported \\(C^0\\) graph contraction, the admissible-graph preservation estimates, and the jet or difference-quotient extension in Banach fibres. The discussion below records the required mechanism and hypotheses; a version with continuous splittings should be read in the HPS transported difference-quotient sense.''',
'''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. A fully self-contained proof must carry out the two-sided Hadamard matching construction, the transported \\(C^0\\) graph contraction, the admissible-graph preservation estimates, and the jet or difference-quotient extension in Banach fibres. The discussion below records the required mechanism and hypotheses; a version with continuous splittings should be read in the HPS transported difference-quotient sense. Appendix D proves the one-sided normally attracting Banach-fibre case completely; the two-sided case requires the additional stable/unstable matching mechanism described here.''')

appendix_d = r'''
## Appendix D. A normally attracting Banach-bundle graph transform

This appendix proves a self-contained one-sided version of the invariant-section theorem. It does not replace the two-sided HPS theorem used in the main normally hyperbolic case, but it closes the important normally attracting case and records the estimates that underlie the admissible graph transform.

### D.1. Statement

Let \(E\to M\) be a \(C^{r+1}\) Banach bundle over a compact finite-dimensional \(C^{r+1}\) manifold, and let

\[
F_\varepsilon(m,\eta)=(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta))
\]

be a \(C^{r+1}\) fibre map defined near the zero section. Assume

\[
b_0(m,0)=f(m),
\qquad
g_0(m,0)=0,
\]

where \(f\in\operatorname{Diff}^{r+1}(M)\). Assume

\[
D_\eta b_0(m,0)=0,
\qquad
B_m:=D_\eta g_0(m,0):E_m\to E_{f(m)}
\]

is a bundle automorphism satisfying the normally attracting estimates

\[
\nu_0:=\sup_m\|B_m\|<1,
\]

and, for \(1\le j\le r\),

\[
\nu_j:=\sup_m\|B_m\|\,\|Df(m)^{-1}\|^j<1.
\]

Assume the transported remainder

\[
r_\varepsilon(m,\eta)
=
g_\varepsilon(m,\eta)-\tau_{b_\varepsilon(m,\eta)\leftarrow f(m)}B_m\eta
\]

satisfies, on \(\|\eta\|\le\rho\),

\[
\|r_\varepsilon(m,0)\|\le C\delta_\varepsilon,
\]

\[
\|D_\eta r_\varepsilon(m,\eta)\|+
\|D_m r_\varepsilon(m,\eta)\|
\le C\delta_\varepsilon+
\omega(\rho),
\]

and

\[
\|D_\eta b_\varepsilon(m,\eta)\|
\le C\delta_\varepsilon+
\omega(\rho),
\]

where \(\omega(\rho)\to0\) as \(\rho\to0\). Then for \(\rho>0\), \(L>0\), and \(\delta_\varepsilon\) sufficiently small, there exists a unique section

\[
h_\varepsilon\in\Gamma^r(E),
\qquad
\|h_\varepsilon\|_{C^0}\le\rho,
\qquad
\operatorname{Lip}(h_\varepsilon)\le L,
\]

such that, with

\[
f_\varepsilon(m)=b_\varepsilon(m,h_\varepsilon(m)),
\]

one has the graph equation

\[
h_\varepsilon(f_\varepsilon(m))
=
g_\varepsilon(m,h_\varepsilon(m)).
\]

Moreover, if \(\|F_\varepsilon-F_0\|_{C^k}\le C|\varepsilon|\) for \(0\le k\le r\), then

\[
\|h_\varepsilon\|_{C^k}
\le C_k|\varepsilon|.
\]

### D.2. The forward graph transform

For \(h\in\mathcal B_{\rho,L}\), define

\[
b_h(m)=b_\varepsilon(m,h(m)).
\]

Because \(D_\eta b_\varepsilon\) is small and \(h\) is Lipschitz with small aperture, \(b_h\) is a \(C^1\) local diffeomorphism close to \(f\). By the compact-manifold lemma, \(b_h\) is a global diffeomorphism. Define the graph transform by

\[
(\mathcal H_\varepsilon h)(y)
=
g_\varepsilon(b_h^{-1}(y),h(b_h^{-1}(y))).
\]

All fibre comparisons are made using the fixed local transports. This is the ordinary forward graph transform; no unstable matching is needed in the attracting case.

### D.3. The \(C^0\) contraction

Let \(h_1,h_2\in\mathcal B_{\rho,L}\), set \(b_i=b_{h_i}\), and let

\[
x_i=b_i^{-1}(y).
\]

Since \(b_1(x_1)=b_2(x_2)=y\) and \(b_i\) is uniformly close to \(f\), inverse function estimates give

\[
d_M(x_1,x_2)
\le
C\|D_\eta b_\varepsilon\|_{C^0}
\|h_1-h_2\|_{C^0}
\le
\mu\|h_1-h_2\|_{C^0},
\]

where \(\mu=\mu(\rho,L,\delta_\varepsilon)\to0\). Using

\[
g_\varepsilon(m,\eta)=
\tau_{b_\varepsilon(m,\eta)\leftarrow f(m)}B_m\eta+r_\varepsilon(m,\eta),
\]

we obtain

\[
\|\mathcal H_\varepsilon h_1-
\mathcal H_\varepsilon h_2\|_{C^0}
\le
(\nu_0+
\mu)
\|h_1-h_2\|_{C^0}.
\]

Choosing \(\rho,L,\delta_\varepsilon\) small gives a contraction factor \(q<1\). The radius estimate is

\[
\|\mathcal H_\varepsilon h\|_{C^0}
\le
C\delta_\varepsilon+(
\nu_0+
\mu)
\rho.
\]

After fixing \(\rho\) and then choosing \(\delta_\varepsilon\) small, \(\mathcal H_\varepsilon\) maps the \(C^0\)-ball of radius \(\rho\) into itself.

### D.4. Lipschitz preservation

Let \(y_1,y_2\in M\), and set \(x_i=b_h^{-1}(y_i)\). Since \(b_h^{-1}\) is close to \(f^{-1}\),

\[
d_M(x_1,x_2)
\le
(\|Df^{-1}\|+
\mu)d_M(y_1,y_2).
\]

Using the base and fibre derivative estimates for the remainder,

\[
\begin{aligned}
&\|(
\mathcal H_\varepsilon h)(y_1)-(
\mathcal H_\varepsilon h)(y_2)\| \\
&\qquad\le
(\|B\|\,\|Df^{-1}\|+
\mu)
\operatorname{Lip}(h)
\,d_M(y_1,y_2)
+
\mu d_M(y_1,y_2).
\end{aligned}
\]

Thus

\[
\operatorname{Lip}(\mathcal H_\varepsilon h)
\le
(\nu_1+
\mu)L+
\mu.
\]

Choose \(L>0\) and then choose \(\rho\) and \(\delta_\varepsilon\) so small that

\[
(\nu_1+
\mu)L+
\mu
\le L.
\]

Then \(\mathcal H_\varepsilon\mathcal B_{\rho,L}\subset\mathcal B_{\rho,L}\).

### D.5. Existence, uniqueness, and the graph equation

The space \(\mathcal B_{\rho,L}\) is complete in the \(C^0\) metric. The graph transform is a contraction and maps \(\mathcal B_{\rho,L}\) into itself. Therefore it has a unique fixed point \(h_\varepsilon\). By definition of \(\mathcal H_\varepsilon\), the fixed-point equation says

\[
h_\varepsilon(y)
=
g_\varepsilon(b_{h_\varepsilon}^{-1}(y),
h_\varepsilon(b_{h_\varepsilon}^{-1}(y))).
\]

Putting \(y=f_\varepsilon(m)=b_{h_\varepsilon}(m)\) gives

\[
h_\varepsilon(f_\varepsilon(m))
=
g_\varepsilon(m,h_\varepsilon(m)).
\]

This is the graph equation. Since \(f_\varepsilon=b_{h_\varepsilon}\) is a diffeomorphism close to \(f\), it also gives setwise equality of the graph with its image.

### D.6. \(C^r\) regularity and estimates

The derivative of the graph transform on first jets has principal fibre part

\[
J\mapsto B_mJ Df(m)^{-1}.
\]

Its norm is bounded by \(\nu_1<1\), up to the small error \(\mu\). Therefore the induced first-jet transform is a contraction. Inductively, the induced \(j\)-jet transform has principal part

\[
J\mapsto B_mJ\circ(Df(m)^{-1})^{\otimes j},
\]

with norm bounded by \(\nu_j<1\), again up to a small error. Lower-order Faà di Bruno terms depend only on previously constructed lower jets. The fibre-contraction argument on jet bundles gives \(h_\varepsilon\in C^r\).

If \(F_\varepsilon-F_0=O(\varepsilon)\) in \(C^k\), then the graph transform sends the zero section to an \(O(\varepsilon)\) section in \(C^k\), and each induced jet transform has a uniform contraction constant. Hence

\[
\|h_\varepsilon\|_{C^k}
\le C_k|\varepsilon|,
\qquad
0\le k\le r.
\]

This completes the normally attracting Banach-bundle graph-transform theorem.

---
'''
marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_d+'\n## References')

# Update summary
s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, and Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, and Appendix D proves the one-sided normally attracting Banach-bundle graph transform.''')

out=Path('/home/user/final_manuscript_next_gaps.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
