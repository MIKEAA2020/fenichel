from pathlib import Path
p=Path('/home/user/final_manuscript_parameter_gap_closed.md')
s=p.read_text()

# Add cross-reference in Section 7.
s=s.replace('''By the flow property, invariance extends to all \\(t\\in\\mathbb R\\).''',
'''By the flow property, invariance extends to all \\(t\\in\\mathbb R\\). Appendix G records this time-\\(T\\) reduction as a standalone lemma.''')

appendix_g = r'''
## Appendix G. Reduction of flows to time maps

This appendix isolates the time-\(T\) reduction used in Section 7. The point is to state exactly where full-flow invariance of the unperturbed manifold enters.

### G.1. Setting

Let \(\Phi_t^\varepsilon\) be a \(C^{r+1}\) local flow defined for \(|t|\le T\) on a fixed neighbourhood of a compact manifold \(M\). Assume

\[
\Phi_t^0(M)=M,
\qquad |t|\le T.
\]

Let

\[
F_\varepsilon:=\Phi_T^\varepsilon.
\]

Suppose the time-\(T\) map theorem gives an admissible invariant graph \(M_\varepsilon\) for \(F_\varepsilon\), locally unique among graphs in a prescribed tube with prescribed Lipschitz and cone bounds:

\[
F_\varepsilon(M_\varepsilon)=M_\varepsilon.
\]

Assume also that \(\Phi_t^\varepsilon\to\Phi_t^0\) in \(C^1\), uniformly for \(t\in[0,T]\), on the relevant tube. Then

\[
\Phi_t^\varepsilon(M_\varepsilon)=M_\varepsilon,
\qquad 0\le t\le T.
\]

Consequently, by the flow property,

\[
\Phi_t^\varepsilon(M_\varepsilon)=M_\varepsilon
\]

for all times for which the local flow is defined along the orbit.

### G.2. Proof

For \(0\le t\le T\), define

\[
N_t:=\Phi_t^\varepsilon(M_\varepsilon).
\]

Because the maps of a flow commute,

\[
F_\varepsilon(N_t)
=
\Phi_T^\varepsilon\Phi_t^\varepsilon(M_\varepsilon)
=
\Phi_t^\varepsilon\Phi_T^\varepsilon(M_\varepsilon)
=
\Phi_t^\varepsilon(M_\varepsilon)
=N_t.
\]

Thus \(N_t\) is invariant under the same time-\(T\) map.

We must check that \(N_t\) lies in the uniqueness class. Since \(M_\varepsilon\) is an admissible graph close to \(M\), and since \(\Phi_t^\varepsilon\) is uniformly \(C^1\)-close to \(\Phi_t^0\) for \(t\in[0,T]\), while \(\Phi_t^0(M)=M\), the image \(N_t\) remains in the same tubular neighbourhood for all \(t\in[0,T]\) when \(\varepsilon\) is small. The derivative of \(\Phi_t^\varepsilon\) maps the tangent spaces of \(M_\varepsilon\) to tangent spaces of \(N_t\); uniform \(C^1\)-closeness and compactness preserve the prescribed Lipschitz and cone bounds after, if necessary, choosing the admissible constants with a small margin. Hence \(N_t\) is an admissible invariant graph for \(F_\varepsilon\).

By local uniqueness for the time-\(T\) map,

\[
N_t=M_\varepsilon.
\]

Therefore

\[
\Phi_t^\varepsilon(M_\varepsilon)=M_\varepsilon,
\qquad 0\le t\le T.
\]

For arbitrary positive time, write \(t=nT+s\) with \(n\in\mathbb N\) and \(0\le s<T\). Repeated use of the time-\(T\) invariance and the just-proved invariance for \(s\in[0,T]\) gives invariance for \(t\). Negative times follow similarly when the local flow is defined backward along the relevant orbit.

### G.3. Necessity of full-flow invariance of the unperturbed manifold

If one only knows

\[
\Phi_T^0(M)=M
\]

and not \(\Phi_t^0(M)=M\) for \(0<t<T\), then \(\Phi_t^0(M)\) may leave the tubular neighbourhood of \(M\). In that case

\[
N_t=\Phi_t^\varepsilon(M_\varepsilon)
\]

need not lie in the admissible class for the time-\(T\) graph transform, so the uniqueness argument cannot be applied. Therefore the time-map reduction requires full-flow invariance of \(M\), or else one must construct the invariant manifold directly by a continuous-time Perron method.

---
'''
marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_g+'\n## References')

s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, and Appendix F proves the parameter-expansion recursion.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, and Appendix G proves the time-map reduction for flows.''')

out=Path('/home/user/final_manuscript_flow_gap_closed.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
