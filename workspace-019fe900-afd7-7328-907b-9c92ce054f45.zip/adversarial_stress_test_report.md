# Adversarial Stress-Test Report

This run tries harder to break the manuscript by using ill-conditioned oblique splittings, near-loss of hyperbolicity, failure of bunching, false Lipschitz-composition estimates, invalid parabolic exponents, and bad HPS constants.

Overall status: **PASS**

- ✅ **oblique_ill_conditioned_bundle_green_formula** — trials=100, max err=1.07e-11, median err=4.87e-13, max linear cond=1.54e+04, max projection norm sum=8.00e+01, failures=[]
- ✅ **near_loss_of_hyperbolicity_green_constant_blowup_expected** — (lambda,res,zsup,(1-lambda)zsup)=[(0.5, np.float64(1.7763568394002505e-15), np.float64(2.3286138123997064), np.float64(1.1643069061998532)), (0.8, np.float64(5.329070518200751e-15), np.float64(4.927308277264356), np.float64(0.985461655452871)), (0.9, np.float64(1.6431300764452317e-14), np.float64(7.158513507940125), np.float64(0.7158513507940123)), (0.95, np.float64(4.796163466380676e-14), np.float64(9.229443050988072), np.float64(0.46147215254940405)), (0.98, np.float64(4.2896242113954486e-14), np.float64(10.957280647104158), np.float64(0.21914561294208335)), (0.99, np.float64(6.435130206483564e-14), np.float64(10.786923066433271), np.float64(0.10786923066433281)), (0.995, np.float64(3.347322419244847e-14), np.float64(11.324211935356063), np.float64(0.05662105967678036))]
- ✅ **exact_loss_of_dichotomy_operator_singular_counterexample** — rank(I-B) with B=I is 0 < 2
- ✅ **c0_inverse_can_hold_while_c1_bunching_fails** — det C0=-0.75, det jet=0, products B=0.25, B/Df product=1
- ✅ **naive_lipschitz_composition_smallness_counterexample** — Lip(h)=100.0, betas=[0.02, 0.01, 0.004, 0.002], Lip(h(.+beta)-h)=[np.float64(200.00000000408562), np.float64(200.00000000532907), np.float64(200.00000000408562), np.float64(200.0000000069278)], supdiffs=[np.float64(2.0), np.float64(1.0000000000000142), np.float64(0.4000000000000057), np.float64(0.20000000000000284)]
- ✅ **local_diffeomorphism_not_close_to_identity_can_be_covering_not_diffeo** — circle doubling map derivative=2, approximate preimages of 0 on grid=4
- ✅ **parabolic_rho_ge_one_singularity_counterexample** — rho=1.08, analytic lower bounds as cutoff->0=[(0.01, 2.8341897569972323), (0.0001, 10.338285895396519), (1e-06, 21.18500489733978), (1e-08, 36.86328392485415)]
- ✅ **parabolic_gamma_ge_alpha_growth_counterexample** — gamma-alpha=0.15, cutoff integrals=[(5, 5.952713694918076), (10, 12.951202212930378), (20, 47.39751533563055), (40, 672.0600328528889), (80, 195237.94243845833)]
- ✅ **hps_random_adversarial_constants_have_expected_pass_fail_split** — valid=549, invalid=451, borderline examples=[(0.9681698869324106, 1.6649687751447793, 0.05605261223523785, 13, 2.024625392122392e-06, 0.00010980943177720151, 0.09883886710956823, 0.6766572415167483, 0.6551225359493263), (0.9906973878401006, 4.8001882297704945, 0.08167499834432704, 33, 0.001547180555107067, 1.789009642837506e-05, 0.13729831124153877, 0.26453491217336716, 0.26950080437262003), (0.9761614174696306, 2.1707504510797326, 1.2383082765939963, 1, 0.005766416426320194, 0.1540051744122372, 4.267426537456132e-05, 0.023587226757852076, 0.035542391764670625), (1.0105994445757345, 7.3614071469588, 0.10454759683492526, 19, 8.213402179929616e-05, 7.3212295528437074e-06, 6.184431087945543e-06, 0.5045509052008968, 0.5105034865312922), (0.9710198073799005, 2.848738483161451, 0.05784120120550332, 26, 0.03863778765688621, 0.07953614788340965, 0.0004176045462651798, 0.0015556954096762495, 0.11157956365943789)]

## Main conclusions

1. The Green formula survives randomized oblique, ill-conditioned splitting tests when the hypotheses hold.
2. Constants blow up as hyperbolicity is lost, and exact loss of dichotomy produces a singular cohomological operator.
3. The C^1 bunching assumption is genuinely stronger than the C^0 dichotomy: a two-cycle example has an invertible C^0 operator but a singular first-jet operator.
4. A triangular-wave test reproduces the failure of naive Lipschitz-norm composition smallness, justifying the manuscript’s use of C^0 graph contraction plus separate cone invariance.
5. Parabolic conditions rho<1 and gamma<alpha are stress-tested by explicit divergent/growing counterexamples when violated.
6. The constant-selection scheme for the HPS graph transform has both passing and failing regions exactly as expected.