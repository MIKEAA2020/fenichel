from pathlib import Path
p=Path('/home/user/final_manuscript_all_findings.md')
s=p.read_text()

# Update roughness sentence in Section 5.
s=s.replace('''where \\(B_\\varepsilon\\) is the perturbed normal cocycle. The cocycle \\(B_\\varepsilon\\) is \\(C^0\\)-close to \\(B\\), and \\(f_\\varepsilon\\) is \\(C^1\\)-close to \\(f\\). Roughness of exponential dichotomies gives an exponential dichotomy for \\(B_\\varepsilon\\), possibly with weakened rates; see, for example, Palmer [6]. Equivalently, we obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original stable and unstable summands.''',
'''where \\(B_\\varepsilon\\) is the perturbed normal cocycle. The cocycle \\(B_\\varepsilon\\) is \\(C^0\\)-close to \\(B\\), and \\(f_\\varepsilon\\) is \\(C^1\\)-close to \\(f\\). Roughness of exponential dichotomies gives an exponential dichotomy for \\(B_\\varepsilon\\), possibly with weakened rates. Appendix C proves the fixed-base Banach-bundle roughness estimate by a linear half-line Perron argument; the equivalent close-base formulation follows after the usual bundle transports and is the standard roughness theorem of Palmer [6]. Equivalently, we obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original stable and unstable summands.''')

appendix_c = r'''
## Appendix C. Roughness of exponential dichotomies in Banach bundles

This appendix records the linear robustness estimate used for persistence of the normal splitting. We state and prove the fixed-base version. The close-base version, where the base diffeomorphism is also perturbed, follows by the same estimates after transporting fibres to a common reference bundle; this is the standard roughness theorem for exponential dichotomies.

### C.1. Statement

Let \(E\to M\) be a Banach bundle over a compact base, and let

\[
B_m:E_m\to E_{f(m)}
\]

be a bundle automorphism over a homeomorphism \(f:M\to M\). Assume that \(B\) has an exponential dichotomy

\[
E_m=E_m^s\oplus E_m^u
\]

with projections uniformly bounded by \(K_P\), and with constants \(C>0\) and \(0<\lambda<1\):

\[
\|\Phi^s(n,k)\|\le C\lambda^{n-k},
\qquad n\ge k,
\]

and

\[
\|\Phi^u(k,n)\|\le C\lambda^{n-k},
\qquad n\ge k.
\]

Let

\[
\widetilde B_m=B_m+R_m:E_m\to E_{f(m)}
\]

be another bundle automorphism over the same base map, with

\[
\sup_m\|R_m\|\le\delta.
\]

Then, for every \(\gamma\) with

\[
\lambda<\gamma<1,
\]

there exists \(\delta_0>0\) such that if \(0<\delta<\delta_0\), the cocycle \(\widetilde B\) has an exponential dichotomy with rate \(\gamma\). Its stable and unstable bundles are graphs over the original bundles:

\[
\widetilde E_m^s=\{a+L_m^s a:a\in E_m^s\},
\qquad
L_m^s:E_m^s\to E_m^u,
\]

and

\[
\widetilde E_m^u=\{b+L_m^u b:b\in E_m^u\},
\qquad
L_m^u:E_m^u\to E_m^s,
\]

with

\[
\sup_m\|L_m^s\|+\\sup_m\|L_m^u\|
\le C_\gamma\delta.
\]

The perturbed projections are uniformly bounded and converge to the original projections as \(\delta\to0\).

### C.2. Stable graph by a half-line Perron equation

Fix \(m\in M\) and write \(m_n=f^n(m)\). Along this orbit, the perturbed linear equation is

\[
x_{n+1}=B_{m_n}x_n+R_{m_n}x_n.
\]

Choose \(\gamma\in(\lambda,1)\) and define the weighted sequence space

\[
\ell_\gamma^+
=
\left\{
x=(x_n)_{n\ge0}:
\|x\|_\gamma=
\sup_{n\ge0}\gamma^{-n}\|x_n\|<\infty
\right\}.
\]

For a prescribed stable coordinate \(a\in E_m^s\), define a linear Perron operator on \(\ell_\gamma^+\) by

\[
(\mathcal T_a x)_n^s
=
\Phi^s(n,0)a
+
\sum_{k=0}^{n-1}
\Phi^s(n,k+1)P^s_{m_{k+1}}R_{m_k}x_k,
\]

and

\[
(\mathcal T_a x)_n^u
=
-
\sum_{k=n}^{\infty}
\Phi^u(n,k+1)P^u_{m_{k+1}}R_{m_k}x_k.
\]

Set \(\mathcal T_a x=(\mathcal T_a x)^s+(\mathcal T_a x)^u\). The first sum is finite and the second converges absolutely in the weighted norm.

Indeed, using \(\|x_k\|\le\gamma^k\|x\|_\gamma\),

\[
\gamma^{-n}
\left\|
\sum_{k=0}^{n-1}
\Phi^s(n,k+1)P^sR_kx_k
\right\|
\le
C K_P\delta\|x\|_\gamma
\sum_{k=0}^{n-1}
\gamma^{-n}\lambda^{n-k-1}
\gamma^k.
\]

Writing \(j=n-k-1\), this is bounded by

\[
C K_P\delta\gamma^{-1}
\sum_{j=0}^{\infty}(\lambda/\gamma)^j
\|x\|_\gamma
\le
C_1(\gamma)\delta\|x\|_\gamma.
\]

Similarly,

\[
\gamma^{-n}
\left\|
\sum_{k=n}^{\infty}
\Phi^u(n,k+1)P^uR_kx_k
\right\|
\le
C K_P\delta\|x\|_
\gamma
\sum_{k=n}^{\infty}
\gamma^{-n}\lambda^{k+1-n}
\gamma^k.
\]

Writing \(j=k-n\), this becomes

\[
C K_P\delta\lambda
\sum_{j=0}^{\infty}(\lambda\gamma)^j
\|x\|_
\gamma
\le
C_2(
\gamma)\delta\|x\|_
\gamma.
\]

Thus

\[
\|\mathcal T_a x-\mathcal T_a y\|_
\gamma
\le
C_3(\gamma)
\delta\|x-y\|_
\gamma.
\]

For \(\delta\) small enough, \(C_3(\gamma)
\delta<1\), so \(\mathcal T_a\) is a contraction. It has a unique fixed point \(x(a)
\in\ell_
\gamma^+\). The dependence on \(a\) is linear and bounded, since \(\mathcal T_a\) is affine in \(a\).

Define

\[
L_m^s a:=P_m^u x_0(a).
\]

Then

\[
\widetilde E_m^s:=\{a+L_m^s a:a\in E_m^s\}
\]

is the set of initial data whose forward perturbed orbit lies in \(\ell_\gamma^+\). Since the fixed point satisfies the variation-of-constants formula, \(\widetilde E^s\) is invariant under \(\widetilde B\). Moreover,

\[
\|L_m^s a\|
\le C_\gamma\delta\|a\|.
\]

The fixed point estimate also gives, for \(x_0\in\widetilde E_m^s\),

\[
\|\widetilde\Phi(n,0)x_0\|
\le
C_\gamma\gamma^n\|x_0\|.
\]

### C.3. Unstable graph

Apply the same construction to the inverse cocycle over negative time. Equivalently, fix \(b\in E_m^u\) and solve the backward weighted equation in

\[
\ell_\gamma^-=
\left\{
x=(x_n)_{n\le0}:
\sup_{n\le0}\gamma^{n}\|x_n\|<\infty
\right\}.
\]

The backward dichotomy estimate gives a contraction for \(\delta\) small. This produces a graph

\[
\widetilde E_m^u=
\{b+L_m^u b:b\in E_m^u\},
\]

with

\[
\|L_m^u\|
\le C_\gamma\delta,
\]

and, for \(x_0\in\widetilde E_m^u\),

\[
\|\widetilde\Phi(-n,0)x_0\|
\le
C_\gamma\gamma^n\|x_0\|,
\qquad n\ge0.
\]

### C.4. Splitting and projections

For \(\delta\) small, both graph maps have norm less than one. Hence

\[
E_m=\widetilde E_m^s\oplus\widetilde E_m^u
\]

for every \(m\), and the associated projections are uniformly bounded. The graph norms are \(O(\delta)\), so the perturbed projections converge uniformly to the original projections.

Continuity of \(m\mapsto \widetilde E_m^s\) and \(m\mapsto \widetilde E_m^u\) follows from continuous dependence of the contraction fixed point on parameters. If the cocycle depends with higher regularity and the corresponding graph transforms act on higher regularity section spaces with bunching, the same argument gives higher regularity of the splitting.

This proves the fixed-base roughness theorem.

---
'''

marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_c+'\n## References')

# Update summary mention Appendix C
s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, and Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, and Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles.''')

out=Path('/home/user/final_manuscript_gap_resolutions.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
