# Computational Verification Report

Manuscript checked: `/home/user/final_manuscript_full_revised.md`

Computational checks cannot prove the infinite-dimensional theorems. They can, however, test formula consistency, signs, indexing, delimiter balance, and representative finite-dimensional/rate-model consequences of the displayed estimates.

Overall status: **PASS**

- ✅ **display_math_delimiters** — \[ count=243, \] count=243
- ✅ **inline_math_delimiters** — \( count=446, \) count=446
- ✅ **latex_environment_balance** — begin={'pmatrix': 1, 'aligned': 2}, end={'pmatrix': 1, 'aligned': 2}
- ✅ **no_chat_repair_meta_language** — found=[]
- ✅ **no_common_mojibake** — found=[]
- ✅ **green_operator_solves_model_equation** — constant dichotomy model max residual=1.554e-15; B=diag(0.4,2.5)
- ✅ **green_operator_geometric_bound_model** — sample zsup=2.03717, qsup=1.29618, bound=4.3206, lambda=0.4
- ✅ **sample_jet_bunching_products_strict** — products (k, stable, unstable_back)=[(0, 0.28, 0.3), (1, 0.322, 0.345), (2, 0.37029999999999996, 0.39674999999999994), (3, 0.425845, 0.4562624999999999), (4, 0.4897217499999999, 0.5247018749999998)]
- ✅ **stable_perron_convolution_bounded_sample** — max weighted stable convolution=2.4596, alpha_s=1.7, gamma=0.9
- ✅ **center_unstable_perron_convolution_bounded_sample** — max weighted cu convolution=1.85395, beta_cu=0.35, gamma=0.9
- ✅ **stable_gap_assumptions_consistent** — beta_cu=0.35 < gamma=0.9 < alpha_s=1.7
- ✅ **hps_schematic_constants_can_be_chosen** — q=0.0626709, radius_rhs=0.00826709, rho=0.1
- ✅ **parabolic_convolution_bound_condition** — sample_sup=1.82697, analytic_bound=1.84456, gamma=0.6, alpha=1.3, rho=0.4
- ✅ **remainder_mean_value_estimate_consistent** — raw_bound=0.001315, absorbed_bound=0.001415, eta=0.05

## Interpretation

- The Green-operator sign and indexing were tested in a two-dimensional constant stable/unstable model and solved the cohomological equation to numerical precision.
- The induced jet-cocycle bunching products were checked in a representative model and stayed strictly below one.
- The stable-fibre Perron convolution estimates were tested with rates satisfying `beta_cu < gamma < alpha_s`; the weighted sums stayed uniformly bounded.
- The parabolic smoothing convolution condition `gamma < alpha` and `rho < 1` was checked against the analytic gamma-function bound.
- The HPS schematic contraction and radius-preservation inequalities were checked for one admissible choice of small constants.