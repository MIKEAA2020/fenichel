from pathlib import Path
import json
import numpy as np
results=[]
def add(n,ok,d): results.append({'name':n,'ok':bool(ok),'detail':d})
# finite-rank compact witness: K diag(1, 1/2, 1/3, 0...) approximated finite dimension.
N=8
K=np.diag([1]+[1/(j+1) for j in range(1,N)])
I=np.eye(N)
rank=np.linalg.matrix_rank(I-K, tol=1e-12)
eigs=np.linalg.eigvals(K)
add('compact_finite_rank_non_surjective_has_eigenvalue_one', rank<N and min(abs(eigs-1))<1e-12,
    f'rank(I-K)={rank} < {N}; eigenvalues={eigs}')
# compact no unit eigenvalue: K diag(1/2,1/3,...) I-K invertible finite section with bounded inverse max 2.
K2=np.diag([1/(j+2) for j in range(N)])
invnorm=np.linalg.norm(np.linalg.inv(I-K2),2)
add('compact_no_unit_eigenvalue_invertible_witness', np.linalg.matrix_rank(I-K2)==N and invnorm<2.1,
    f'rank={np.linalg.matrix_rank(I-K2)}, inverse norm≈{invnorm:.3f}')
# noncompact shift witness on finite truncations approximates unilateral shift: I-S increasingly ill conditioned near spectral point 1 but S has no eigenvector 1 in l2.
conds=[]
for N in [20,50,100]:
    S=np.zeros((N,N))
    for i in range(1,N): S[i,i-1]=1  # unilateral shift truncation
    conds.append(float(np.linalg.cond(np.eye(N)-S)))
add('noncompact_shift_warns_no_eigenvalue_needed', conds[-1]>conds[0],
    f'finite truncation cond(I-S_N) grows: {conds}; infinite unilateral shift has 1 in spectrum but no l2 eigenvector')
# text checks
for file in ['fractional_jet_spectrum_research_note.md','final_manuscript_fractional_spectrum_added.md']:
    s=Path('/home/user/'+file).read_text()
    add('text_'+file+'_has_compact_fredholm', 'Compact jet-return Fredholm alternative' in s and 'Without compactness' in s, 'present')
all_ok=all(r['ok'] for r in results)
lines=['# Compact Fredholm Resonance Verification','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for r in results: lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['name']}** — {r['detail']}")
Path('/home/user/compact_fredholm_resonance_verification_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results},indent=2))
