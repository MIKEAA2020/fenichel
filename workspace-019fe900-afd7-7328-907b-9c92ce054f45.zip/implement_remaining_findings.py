from pathlib import Path
p=Path('/home/user/final_manuscript_hps_corrected.md')
s=p.read_text()

# Add Appendix A note after Theorem 3.1 proof end.
old='''Parameter dependence follows from the same estimates. If the data and dichotomy projections depend continuously on a parameter and the dichotomy constants are uniform, then the Green sums converge uniformly in both the base point and the parameter. Higher parameter regularity follows by differentiating the parameter-dependent cohomological equation, or by using parameter difference quotients, provided the corresponding parameter-bunching estimates hold. ∎

---

## 4. The invariant-section theorem'''
new='''Parameter dependence follows from the same estimates. If the data and dichotomy projections depend continuously on a parameter and the dichotomy constants are uniform, then the Green sums converge uniformly in both the base point and the parameter. Higher parameter regularity follows by differentiating the parameter-dependent cohomological equation, or by using parameter difference quotients, provided the corresponding parameter-bunching estimates hold. ∎

Appendix A gives a self-contained proof of the \\(C^k\\) cohomological inverse theorem under the clean hypothesis that the splitting and projections have the required \\(C^r\\) regularity. The continuous-projection version used in the HPS setting should be read in the transported difference-quotient sense described above.

---

## 4. The invariant-section theorem'''
assert old in s
s=s.replace(old,new)

# Add Lipschitz counterexample remark after two-sided graph transform paragraph.
old='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched in one time direction and unstable components in the opposite time direction; the center coordinate labels the transformed graph. The admissible-graph preservation estimate comes from these stable/unstable matching equations, not from forward invariance of center cones.

Higher regularity follows by lifting the graph transform to jet bundles.'''
new='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched in one time direction and unstable components in the opposite time direction; the center coordinate labels the transformed graph. The admissible-graph preservation estimate comes from these stable/unstable matching equations, not from forward invariance of center cones.

A contraction in the Lipschitz norm is not available in general. For instance, on \\(M=\\mathbb T^1\\), let \\(h\\) be a triangular wave of period \\(p\\). Then \\(\\operatorname{Lip}(h)=4/p\\), while for the shift \\(\\beta=p/2\\), the difference \\(h(\\cdot+\\beta)-h\\) has Lipschitz constant \\(8/p\\). Thus composition by a small base shift need not be small in Lipschitz norm on a Lipschitz ball. This is why the fixed point is taken in the transported \\(C^0\\) graph metric and the Lipschitz bound is preserved separately by admissible-graph estimates.

Higher regularity follows by lifting the graph transform to jet bundles.'''
assert old in s
s=s.replace(old,new)

# Add alternative construction remark after Theorem 5.1 proof before Section 6
old='''Theorem 4.1 gives local uniqueness among admissible graphs. If one wants uniqueness among all sufficiently \\(C^1\\)-close invariant manifolds, one must first show that every such manifold lies in the admissible class. This is usually true for manifolds whose tangent spaces remain inside the prescribed center cones in tubular coordinates, but the theorem’s intrinsic uniqueness statement is the qualified admissible-graph uniqueness above. ∎

---

## 6. Stable and unstable fibres'''
new='''Theorem 4.1 gives local uniqueness among admissible graphs. If one wants uniqueness among all sufficiently \\(C^1\\)-close invariant manifolds, one must first show that every such manifold lies in the admissible class. This is usually true for manifolds whose tangent spaces remain inside the prescribed center cones in tubular coordinates, but the theorem’s intrinsic uniqueness statement is the qualified admissible-graph uniqueness above. ∎

**Remark.** Another common proof strategy constructs local center-stable and center-unstable manifolds and obtains the normally hyperbolic manifold as their transverse intersection,

\\[
M_\\varepsilon
=
W^{cs}_{\\mathrm{loc}}\\cap W^{cu}_{\\mathrm{loc}}.
\\]

That approach is equivalent in spirit but requires separate hypotheses and constructions for the two larger invariant manifolds. We do not use it in the proof above.

---

## 6. Stable and unstable fibres'''
assert old in s
s=s.replace(old,new)

# Add Appendix B note after stable fibre theorem proof or regularity section? Insert after Theorem 6.1 proof end.
old='''This gives the desired local strong stable fibre. ∎

---

### 6.1. Stable manifold, phase projection, and tracking'''
new='''This gives the desired local strong stable fibre. ∎

Appendix B records the same half-line Perron construction as a standalone theorem, including the self-map estimate, contraction estimate, tracking estimate, tangency, and unstable analogue.

---

### 6.1. Stable manifold, phase projection, and tracking'''
assert old in s
s=s.replace(old,new)

appendices = r'''
## Appendix A. The \(C^k\) Banach-bundle cohomological inverse theorem

This appendix gives a self-contained proof of the linear \(C^k\) inverse theorem under a clean regularity hypothesis on the splitting. The continuous-projection version used in the HPS difference-quotient setting is obtained by replacing the covariant derivative computations below with transported difference quotients.

### A.1. Statement

Let \(M\) be a compact finite-dimensional \(C^{r+1}\) manifold, let \(E\to M\) be a \(C^{r+1}\) Banach bundle, and let \(f\in\operatorname{Diff}^{r+1}(M)\). Let

\[
B_m:E_m\to E_{f(m)}
\]

be a \(C^r\) bundle automorphism preserving a \(C^r\) splitting

\[
E=E^s\oplus E^u.
\]

Assume that the projections onto \(E^s\) and \(E^u\) are \(C^r\) and uniformly bounded. Assume that \(B\) has an exponential dichotomy and that, for every \(0\le k\le r\), there are constants \(C_k>0\) and \(\theta_k\in(0,1)\) such that

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m_n)\|^k
\le
C_k\theta_k^n,
\qquad n\ge0,
\]

and

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|^k
\le
C_k\theta_k^n,
\qquad n\ge0.
\]

Then, for every \(0\le k\le r\), the operator

\[
\mathcal A:\Gamma^k(E)\to\Gamma^k(f^*E),
\qquad
(\mathcal A\zeta)(m)=\zeta(f(m))-B_m\zeta(m),
\]

is an isomorphism and

\[
\|\mathcal A^{-1}q\|_{C^k}
\le
C_k'\|q\|_{C^k}.
\]

The \(C^k\) norms may be defined using a fixed \(C^r\) connection or a finite bundle atlas. Compactness of \(M\) and boundedness of the transition maps make the resulting norms equivalent.

### A.2. The \(C^0\) inverse

The \(C^0\) inverse is the Green operator constructed in Section 3. Along an orbit \(m_n=f^n(m)\), the equation becomes

\[
\zeta_{n+1}-B_{m_n}\zeta_n=q_n,
\qquad q_n\in E_{m_{n+1}}.
\]

Decompose the forcing in the target fibre:

\[
q_n^\sigma=P_{m_{n+1}}^\sigma q_n.
\]

Then

\[
\zeta_n^s
=
\sum_{j=-\infty}^{n-1}
\Phi^s(n,j+1)q_j^s,
\]

and

\[
\zeta_n^u
=
-
\sum_{j=n}^{\infty}
\Phi^u(n,j+1)q_j^u.
\]

The exponential dichotomy gives absolute and uniform convergence and

\[
\|\zeta\|_{C^0}\le C\|q\|_{C^0}.
\]

The same formulas show \(\mathcal A\zeta=q\). A bounded homogeneous solution has zero stable part by letting the initial time tend to \(-\infty\), and zero unstable part by letting the terminal time tend to \(+\infty\). Hence the bounded solution is unique.

### A.3. First derivatives

Use the fixed connection to write covariant derivatives. Differentiating

\[
\zeta(f(m))-B_m\zeta(m)=q(m)
\]

gives, in local bundle coordinates,

\[
D\zeta(f(m))Df(m)-B_mD\zeta(m)=Dq(m)+D_mB(m)\zeta(m)+L_1(m)\zeta(m),
\]

where \(L_1\) denotes connection terms with uniformly bounded coefficients. These terms are lower order. With

\[
J(m)=D\zeta(m),
\]

the equation becomes

\[
J(f(m))-B_mJ(m)Df(m)^{-1}=Q_1(m).
\]

The homogeneous first-jet cocycle is

\[
J\mapsto B_mJDf(m)^{-1}.
\]

Along the stable subbundle it is bounded by

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m_n)\|,
\]

and along the unstable subbundle, backward in time, by

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|.
\]

The \(1\)-bunching estimate therefore gives an exponential dichotomy for the first-jet cocycle. Applying the \(C^0\) Green inverse to the first-jet equation yields

\[
\|J\|_{C^0}
\le
C\|Q_1\|_{C^0}.
\]

Since \(Q_1\) depends linearly on \(Dq\) and on \(\zeta\), and since \(\|\zeta\|_{C^0}\le C\|q\|_{C^0}\), we obtain

\[
\|\zeta\|_{C^1}\le C\|q\|_{C^1}.
\]

### A.4. Higher derivatives

Assume inductively that, for some \(1\le k\le r\),

\[
\|\zeta\|_{C^{k-1}}\le C\|q\|_{C^{k-1}}.
\]

The \(k\)-th covariant derivative of the equation has principal part

\[
D^k\zeta(f(m))\circ Df(m)^{\otimes k}-B_mD^k\zeta(m).
\]

All remaining terms contain derivatives of \(f\), \(B\), the connection coefficients, \(q\), and \(\zeta\), but derivatives of \(\zeta\) occur only up to order \(k-1\). Thus the lower-order terms are controlled by the induction hypothesis.

The principal homogeneous \(k\)-jet cocycle is

\[
J\mapsto B_mJ\circ(Df(m)^{-1})^{\otimes k},
\]

where

\[
J(m)\in \operatorname{Sym}^k(T_m^*M;E_m).
\]

The stable part is controlled by

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m_n)\|^k,
\]

and the backward unstable part by

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|^k.
\]

The \(k\)-bunching condition gives an exponential dichotomy for the induced \(k\)-jet cocycle. The \(C^0\) Green inverse applied to this induced equation gives

\[
\|D^k\zeta\|_{C^0}\le C_k\|q\|_{C^k}.
\]

Induction proves

\[
\|\mathcal A^{-1}q\|_{C^k}\le C_k\|q\|_{C^k}
\]

for every \(0\le k\le r\).

### A.5. Parameter dependence

If \(f\), \(B\), and \(q\) depend on a parameter and the dichotomy and bunching constants are uniform, the \(C^0\) Green sums converge uniformly in the parameter. Differentiating the parameter-dependent cohomological equation gives linear equations of the same type, with inhomogeneous terms controlled by lower parameter derivatives. Under the corresponding mixed base/parameter bunching conditions, the same induction gives the claimed parameter regularity.

### A.6. Continuous projections

If the dichotomy projections are merely continuous, the derivative computation above should not be read as differentiating the projections. Instead, one works with transported difference quotients. The principal difference-quotient cocycles are the same jet cocycles displayed above, and the lower-order commutator terms converge uniformly. This is precisely the HPS difference-quotient mechanism. The self-contained proof above therefore closes the smooth-splitting case, while the continuous-splitting case is obtained by the standard transported difference-quotient interpretation.

---

## Appendix B. Strong fibres from a half-line Perron method

This appendix records a standalone proof of the local strong stable fibre theorem. The unstable theorem follows by applying the same argument to the inverse map.

### B.1. Statement

Let \(F\) be a \(C^{r+1}\) local diffeomorphism of a Banach space or Banach manifold, and let \(M\) be an invariant \(C^r\) manifold. Fix \(p\in M\) and write

\[
p_n=F^n(p),
\qquad A_n=DF(p_n).
\]

Assume that along the orbit there is an invariant splitting

\[
T_{p_n}X=E^s_{p_n}\oplus E^{cu}_{p_n},
\qquad
E^{cu}_{p_n}=T_{p_n}M\oplus E^u_{p_n},
\]

with uniformly bounded projections. Assume that

\[
\|\Phi^s(n,k)\|\le C e^{-\alpha_s(n-k)},
\qquad n\ge k,
\]

and

\[
\|\Phi^{cu}(n,k)\|\le C e^{\beta_{cu}(k-n)},
\qquad n\le k.
\]

Assume

\[
\beta_{cu}<\alpha_s.
\]

Then for every \(\gamma\in(\beta_{cu},\alpha_s)\), there exists a local strong stable fibre \(W^s_{\mathrm{loc}}(p)\) through \(p\), tangent to \(E^s_p\), such that points on the fibre track the orbit of \(p\) at rate \(e^{-\gamma n}\).

### B.2. Moving coordinates and remainders

Work in uniformly controlled moving coordinates along \(p_n\), so that a nearby orbit is written

\[
p_n+\xi_n,
\qquad
\xi_n=\xi_n^s+
\xi_n^{cu}.
\]

The equation is

\[
\xi_{n+1}=A_n\xi_n+R_n(\xi_n),
\]

where

\[
R_n(0)=0,
\qquad DR_n(0)=0.
\]

After shrinking the coordinate neighbourhood, uniformly in \(n\),

\[
\|R_n(\xi)\|\le C\|\xi\|^2,
\qquad
\|DR_n(\xi)\|\le C\|\xi\|.
\]

### B.3. The weighted space and Perron operator

Choose \(\gamma\) with

\[
\beta_{cu}<\gamma<\alpha_s.
\]

Let

\[
\ell_\gamma^+=
\left\{
\xi=(\xi_n)_{n\ge0}:
\|\xi\|_\gamma=
\sup_{n\ge0}e^{\gamma n}\|\xi_n\|<\infty
\right\}.
\]

For \(a\in E^s_p\), define

\[
(\mathcal P_a\xi)_n^s
=
\Phi^s(n,0)a+
\sum_{k=0}^{n-1}
\Phi^s(n,k+1)P^s_{k+1}R_k(\xi_k),
\]

and

\[
(\mathcal P_a\xi)_n^{cu}
=
-
\sum_{k=n}^{\infty}
\Phi^{cu}(n,k+1)P^{cu}_{k+1}R_k(\xi_k).
\]

Set

\[
\mathcal P_a\xi=(\mathcal P_a\xi)^s+(\mathcal P_a\xi)^{cu}.
\]

The center component belongs to \(\xi^{cu}\); it is not frozen.

### B.4. Self-map estimate

Let

\[
B_r=\{\xi\in\ell_\gamma^+:\|\xi\|_\gamma\le r\}.
\]

If \(\xi\in B_r\), then

\[
\|\xi_k\|\le r e^{-\gamma k},
\]

and therefore

\[
\|R_k(\xi_k)\|\le Cr^2e^{-2\gamma k}.
\]

The stable homogeneous term satisfies

\[
e^{\gamma n}\|\Phi^s(n,0)a\|
\le
C e^{-(\alpha_s-\gamma)n}\|a\|
\le C\|a\|.
\]

The stable nonlinear convolution is bounded by

\[
C r^2 e^{\gamma n}
\sum_{k=0}^{n-1}e^{-\alpha_s(n-k-1)}e^{-2\gamma k}
\le C r^2,
\]

because \(\gamma<\alpha_s\). The center-unstable convolution is bounded by

\[
C r^2 e^{\gamma n}
\sum_{k=n}^{\infty}e^{\beta_{cu}(k+1-n)}e^{-2\gamma k}.
\]

Writing \(k=n+j\), this becomes

\[
C r^2 e^{-\gamma n}
\sum_{j=0}^{\infty}e^{(\beta_{cu}-2\gamma)j},
\]

which is uniformly bounded since \(\beta_{cu}<\gamma\). Hence

\[
\|\mathcal P_a\xi\|_\gamma
\le
C\|a\|+Cr^2.
\]

Choose \(r>0\) small and \(\|a\|\le c r\). Then \(\mathcal P_a(B_r)\subset B_r\).

### B.5. Contraction estimate

For \(\xi,\eta\in B_r\), the mean-value theorem and the bound on \(DR_n\) give

\[
\|R_k(\xi_k)-R_k(\eta_k)\|
\le
C r e^{-\gamma k}\|\xi_k-
\eta_k\|
\le
C r e^{-2\gamma k}\|\xi-
\eta\|_
\gamma.
\]

The same convolution estimates as above yield

\[
\|\mathcal P_a\xi-
\mathcal P_a\eta\|_
\gamma
\le
C r\|\xi-
\eta\|_
\gamma.
\]

Taking \(r\) smaller if necessary gives \(Cr<1\). Thus \(\mathcal P_a\) is a contraction on \(B_r\).

### B.6. The stable fibre, tracking, and tangency

By the Banach fixed-point theorem, there is a unique \(\xi(a)\in B_r\) satisfying

\[
\mathcal P_a\xi(a)=\xi(a).
\]

Define

\[
W^s_{\mathrm{loc}}(p)=
\{p+
\xi_0(a):a\in E^s_p,
\|a\|\text{ sufficiently small}\}.
\]

The fixed-point equation is exactly the variation-of-constants formula for the nonlinear orbit equation, so the point \(p+
\xi_0(a)\) has a forward orbit staying in the coordinate neighbourhood and satisfying

\[
\|F^n(p+
\xi_0(a))-F^n(p)\|
\le
C e^{-\gamma n}\|a\|.
\]

Tangency follows by differentiating the fixed-point equation at \(a=0\). Since \(R_n(0)=0\) and \(DR_n(0)=0\), the derivative satisfies

\[
(D_a\xi(a)|_{a=0})_n^s=
\Phi^s(n,0),
\qquad
(D_a\xi(a)|_{a=0})_n^{cu}=0.
\]

At \(n=0\), this gives

\[
D_a\xi_0(0)=\operatorname{id}_{E^s_p}.
\]

Therefore

\[
T_pW^s_{\mathrm{loc}}(p)=E^s_p.
\]

Local uniqueness holds among trajectories in the weighted class because the Perron operator has a unique fixed point.

### B.7. The unstable fibre

Apply the preceding theorem to \(F^{-1}\), grouping

\[
T_{p_n}X=E^u_{p_n}\oplus E^{cs}_{p_n},
\qquad
E^{cs}_{p_n}=T_{p_n}M\oplus E^s_{p_n}.
\]

If the backward unstable contraction rate dominates the backward growth rate of \(E^{cs}\), the same half-line argument on negative time gives \(W^u_{\mathrm{loc}}(p)\), tangent to \(E^u_p\). Internal regularity of these fibres and transverse regularity of the family require additional bunching and are not consequences of the basic contraction alone.

---
'''

# Insert appendices before references, after Summary
marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendices+'\n## References')

# Update summary to mention appendices
s=s.replace('The ambient phase space may be infinite-dimensional. The base manifold is finite-dimensional and compact in the main theorem. We obtain extensions',
'''The ambient phase space may be infinite-dimensional. The base manifold is finite-dimensional and compact in the main theorem. Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, and Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem. We obtain extensions''')

out=Path('/home/user/final_manuscript_all_findings.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
