from pathlib import Path
p=Path('/home/user/fractional_jet_spectrum_research_note.md')
s=p.read_text()
insert=r'''
## 10. Model examples

### 10.1. Hyperbolic toral base with scalar attracting normal direction

Let

\[
A=
\begin{pmatrix}
2&1\\
1&1
\end{pmatrix}
\]

act on \(\mathbb T^2\). Its expanding eigenvalue is

\[
\Lambda=
\frac{3+
\sqrt5}{2}>1.
\]

Let \(E=\mathbb T^2\times\mathbb R\), and let the normal cocycle be scalar multiplication by

\[
0<
\lambda<1.
\]

Then the cohomological equation is

\[
\zeta(Ax)-
\lambda
a
\zeta(x)=q(x).
\]

The stable Green summands at real order \(s=k+
\alpha\) have growth rate

\[
\widehat\rho_s=
\lambda\Lambda^s.
\]

Consequently the Green inverse is bounded on every \(C^s\) space with

\[
s<
\frac{
\log(1/
\lambda)}{
\log\Lambda}.
\]

Thus the regularity threshold is

\[
s_*=
\frac{
\log(1/
\lambda)}{
\log\Lambda}.
\]

If \(\lambda=
\Lambda^{-N}\) for an integer \(N\), then the principal order-\(N\) jet return map at the fixed point \(0\in\mathbb T^2\) has eigenvalue one. Hence the periodic jet-resonance obstruction applies at order \(N\). This gives an explicit family where the fractional spectrum predicts the loss of integer-order surjectivity at the threshold.

### 10.2. Isometric base dynamics

If \(f\) is an isometry and the bundle transports, projections, and cocycle products have uniformly bounded Hölder constants, then

\[
\operatorname{Lip}(f^{\pm n})=1.
\]

For a scalar normally attracting cocycle \(B_m=\lambda\), \(0<\lambda<1\), the fractional radius is simply

\[
\widehat\rho_s=\lambda
\]

for all \(s\) allowed by the regularity of the data. Thus the cohomological inverse loses no regularity beyond the regularity already present in the coefficients. This contrasts with the hyperbolic toral example, where tangent distortion creates a finite regularity threshold.

---
'''
marker='---\n\n## References'
assert marker in s
# clean accidental artifacts
insert=insert.replace('0<\n\\lambda','0<\\lambda')
insert=insert.replace('-\n\\lambda\na\n\\zeta','-\\lambda\\zeta')
insert=insert.replace('k+\n\\alpha','k+\\alpha')
insert=insert.replace('s<\n\\frac','s<\\frac')
insert=insert.replace('\\frac{\n\\log','\\frac{\\log')
insert=insert.replace('1/\n\\lambda','1/\\lambda')
insert=insert.replace('\\lambda=\n\\Lambda','\\lambda=\\Lambda')
s=s.replace(marker, insert+marker)
p.write_text(s)
print(p, len(s.splitlines()), len(s))
