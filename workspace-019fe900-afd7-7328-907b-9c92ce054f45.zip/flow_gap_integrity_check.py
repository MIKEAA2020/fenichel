from pathlib import Path
import re,json
p=Path('/home/user/final_manuscript_flow_gap_closed.md')
s=p.read_text()
checks=[]
def add(n,ok,d): checks.append({'name':n,'ok':bool(ok),'detail':d})
add('display_balanced',s.count('\\[')==s.count('\\]'),f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_balanced',s.count('\\(')==s.count('\\)'),f"{s.count('\\(')} vs {s.count('\\)')}")
add('env_balanced',re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s),str((re.findall(r'\\begin\{([^}]+)\}',s),re.findall(r'\\end\{([^}]+)\}',s))))
for pat in ['maps center cones strictly','follows by the same argument','Your assessment','Final honest','What has been repaired','invalid Lipschitz','false Lipschitz']:
 add('absent_'+pat[:18],pat not in s,pat)
for pat in ['Appendix A. The \\(C^k\\) Banach-bundle cohomological inverse theorem','Appendix B. Strong fibres from a half-line Perron method','Appendix C. Roughness of exponential dichotomies in Banach bundles','Appendix D. A normally attracting Banach-bundle graph transform','Appendix E. Close-base roughness by a linear graph transform','Appendix F. Parameter expansions of invariant sections','Appendix G. Reduction of flows to time maps','N_t:=\\Phi_t^\\varepsilon(M_\\varepsilon)','full-flow invariance','time-map reduction']:
 add('present_'+pat[:22],pat in s,pat)
all_ok=all(c['ok'] for c in checks)
lines=['# Flow Gap Integrity Check','',f'Manuscript: `{p}`','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for c in checks: lines.append(f"- {'✅' if c['ok'] else '❌'} **{c['name']}** — {c['detail']}")
Path('/home/user/flow_gap_integrity_check_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'checks':checks},indent=2))
