from pathlib import Path
import re

p = Path('/home/user/revised_passive_voice.md')
s = p.read_text()

# 1. Expand Section 3 C^k proof.
start = s.find('For \\(C^k\\) regularity, \\(1\\le k\\le r\\), we apply the standard Hirsch–Pugh–Shub difference-quotient theorem [2].')
end = s.find('Parameter dependence follows by applying the same argument uniformly in the parameter. ∎', start)
assert start != -1 and end != -1
end += len('Parameter dependence follows by applying the same argument uniformly in the parameter. ∎')
new = r'''For \(C^k\) regularity, we use the induced jet equations. If the dichotomy projections and invariant splitting have the corresponding regularity, one may differentiate the cohomological equation directly. If the projections are only continuous, the same argument is formulated with transported difference quotients, as in the Hirsch–Pugh–Shub proof. The formal differentiated equations below then describe the limiting difference-quotient equations.

First consider \(k=1\). In local bundle coordinates, differentiating

\[
\zeta(f(m))-B_m\zeta(m)=q(m)
\]

gives

\[
D\zeta(f(m))Df(m)-B_mD\zeta(m)
=
Dq(m)+D_mB(m)\zeta(m).
\]

Writing

\[
J(m):=D\zeta(m),
\]

we obtain

\[
J(f(m))
-
B_mJ(m)Df(m)^{-1}
=
\bigl[Dq(m)+D_mB(m)\zeta(m)\bigr]Df(m)^{-1}.
\]

Thus \(J\) satisfies a cohomological equation over the induced first-jet cocycle

\[
J\mapsto B_mJ\,Df(m)^{-1}.
\]

In a nontrivial bundle, the chosen connection and transported derivatives produce the same principal cocycle; the connection terms are lower-order terms controlled by \(\|\zeta\|_{C^0}\) and the fixed bundle geometry.

Along an orbit \(m_n=f^n(m)\), the homogeneous first-jet equation gives

\[
J_n=\Phi(n,0)J_0Df^{-n}(m).
\]

On the stable component,

\[
\|J_n^s\|
\le
\|\Phi^s(n,0)\|\,\|Df^{-n}(m)\|\,\|J_0^s\|,
\]

and the \(1\)-bunching condition gives exponential contraction. On the unstable component, backward iteration gives

\[
\|J_{-n}^u\|
\le
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|\,\|J_0^u\|,
\]

which also contracts by \(1\)-bunching. Hence the induced first-jet cocycle has an exponential dichotomy. Applying the \(C^0\) Green construction to the first-jet equation gives

\[
\|J\|_{C^0}\le C\|Q_1\|_{C^0},
\]

where \(Q_1\) denotes the right-hand side above. Since \(Q_1\) depends linearly on \(Dq\) and on \(\zeta\), and since

\[
\|\zeta\|_{C^0}\le C\|q\|_{C^0},
\]

we obtain

\[
\|\zeta\|_{C^1}\le C_1\|q\|_{C^1}.
\]

For higher \(k\), proceed by induction. The \(k\)-th derivative of

\[
\zeta\circ f-B\zeta=q
\]

has principal part

\[
D^k\zeta(f(m))\circ Df(m)^{\otimes k}
-
B_mD^k\zeta(m).
\]

All other terms involve derivatives of \(f\) and \(B\) up to order \(k\), derivatives of \(q\) up to order \(k\), and derivatives of \(\zeta\) of order at most \(k-1\). The induction hypothesis controls these lower-order terms. The principal homogeneous \(k\)-jet equation is governed by

\[
J\mapsto B_mJ\circ(Df(m)^{-1})^{\otimes k},
\]

where

\[
J(m)\in\operatorname{Sym}^k(T_m^*M;E_m).
\]

Its stable part is controlled by

\[
\|\Phi^s(n,0)\|\,\|Df^{-n}(m)\|^k,
\]

and its backward unstable part by

\[
\|\Phi^u(-n,0)\|\,\|Df^n(m)\|^k.
\]

The \(k\)-bunching condition gives an exponential dichotomy for this induced \(k\)-jet cocycle. Applying the \(C^0\) Green construction to the induced equation gives

\[
\|D^k\zeta\|_{C^0}\le C_k\|q\|_{C^k}.
\]

Induction yields

\[
\|\mathcal Gq\|_{C^k}\le C_k\|q\|_{C^k}.
\]

When the projections are not differentiable, use transported difference quotients. If \(V\) is a smooth vector field on \(M\) with local flow \(\varphi_t\), define

\[
\zeta_t(m)
=
\frac{
P_{m\leftarrow\varphi_t(m)}\zeta(\varphi_t(m))-\zeta(m)
}{t}.
\]

Applying the cohomological operator to \(\zeta_t\) gives a difference-quotient equation whose commutator terms come from the variation of \(f\), \(B\), and the fibre identifications. These terms converge to the lower-order terms in the formal jet equations above. The uniform Green bounds for the induced difference-quotient cocycles imply convergence of the difference quotients and hence genuine \(C^k\) regularity.

Parameter dependence follows from the same estimates. If the data and dichotomy projections depend continuously on a parameter and the dichotomy constants are uniform, then the Green sums converge uniformly in both the base point and the parameter. Higher parameter regularity follows by differentiating the parameter-dependent cohomological equation, or by using parameter difference quotients, provided the corresponding parameter-bunching estimates hold. ∎'''
s = s[:start] + new + s[end:]

# 2. Expand Section 4 admissible class/cones block.
old = '''Let

\\[
\\mathcal B_{\\rho,L}
=
\\left\\{
h\\in C^0(M,E):
\\|h\\|_{C^0}\\le \\rho,
\\ \\operatorname{Lip}(h)\\le L
\\right\\}.
\\]

Equip \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric. Since \\(M\\) is compact and the Lipschitz bound is uniform, \\(\\mathcal B_{\\rho,L}\\) is complete.

Let \\(\\kappa>0\\). In local coordinates adapted to

\\[
TE|_M \\simeq TM\\oplus E^s\\oplus E^u,
\\]

define center cones by

\\[
\\mathcal C^c_{(m,\\eta)}
=
\\left\\{
(v^c,v^s,v^u):
\\|(v^s,v^u)\\|\\le \\kappa\\|v^c\\|
\\right\\}.
\\]

A \\(C^1\\) section with \\(\\operatorname{Lip}(h)\\le\\kappa\\) has a graph tangent to these center cones; a merely Lipschitz section satisfies the corresponding secant-cone condition. The graph transform preserves this admissible class.'''
new = '''Let

\\[
\\mathcal B_{\\rho,L}
=
\\left\\{
h\\in C^0(M,E):
\\|h\\|_{C^0}\\le \\rho,
\\ \\operatorname{Lip}(h)\\le L
\\right\\}.
\\]

Equip \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric. Since \\(M\\) is compact and the Lipschitz bound is uniform, \\(\\mathcal B_{\\rho,L}\\) is complete.

The constants are chosen in the following order. First choose an iterate or a uniformly equivalent adapted norm, if needed, so that the bunching margins are strict. Then choose the tube radius \\(\\rho>0\\), then the cone or Lipschitz aperture \\(L>0\\), and finally choose the perturbation size \\(\\delta_\\varepsilon\\) small enough. The \\(C^0\\) radius and the Lipschitz or cone aperture play different roles and are controlled separately.

Let \\(\\kappa>0\\). In local coordinates adapted to

\\[
TE|_M \\simeq TM\\oplus E^s\\oplus E^u,
\\]

define center cones by

\\[
\\mathcal C^c_{(m,\\eta)}
=
\\left\\{
(v^c,v^s,v^u):
\\|(v^s,v^u)\\|\\le \\kappa\\|v^c\\|
\\right\\}.
\\]

Similarly define stable and unstable cones by

\\[
\\mathcal C^s_{(m,\\eta)}
=
\\left\\{
(v^c,v^s,v^u):
\\|v^u\\|\\le \\kappa(\\|v^c\\|+\\|v^s\\|)
\\right\\},
\\]

and

\\[
\\mathcal C^u_{(m,\\eta)}
=
\\left\\{
(v^c,v^s,v^u):
\\|v^s\\|\\le \\kappa(\\|v^c\\|+\\|v^u\\|)
\\right\\}.
\\]

A \\(C^1\\) section with \\(\\operatorname{Lip}(h)\\le\\kappa\\) has a graph tangent to the center cones; a merely Lipschitz section satisfies the corresponding secant-cone condition. The center cones control admissible graphs, while the stable and unstable cones control the Hadamard matching used in the graph transform.

For \\(\\rho\\), \\(L\\), and \\(\\delta_\\varepsilon\\) sufficiently small, the exponential dichotomy and bunching inequalities imply the following cone invariance properties: \\(DF_\\varepsilon\\) maps center cones strictly inside center cones; \\(DF_\\varepsilon\\) maps stable cones strictly inside stable cones; \\(DF_\\varepsilon^{-1}\\) maps unstable cones strictly inside unstable cones; stable-cone vectors contract forward relative to center vectors; and unstable-cone vectors contract backward relative to center vectors. These estimates follow from the stable and unstable bounds for \\(B\\), the boundedness of the tangent dynamics \\(Df\\), and the smallness of the nonlinear terms.'''
assert old in s
s = s.replace(old, new)

# 3. Insert D_eta b_epsilon smallness in Theorem 4.1 after D_eta r estimate block.
old = '''   and \\(\\omega(\\rho)\\to0\\) as \\(\\rho\\to0\\).

Then there exist constants \\(\\rho>0\\), \\(L>0\\), and \\(\\delta_0>0\\) such that if \\(\\delta_\\varepsilon<\\delta_0\\), there exists a locally unique section'''
new = '''   and \\(\\omega(\\rho)\\to0\\) as \\(\\rho\\to0\\).

   Assume also that the base nonlinear part satisfies

   \\[
   \\|D_\\eta b_\\varepsilon(m,\\eta)\\|
   \\le
   C\\delta_\\varepsilon+\\omega(\\rho)
   \\]

   on the same tube. This follows from \\(D_\\eta b_0(m,0)=0\\) when \\(F_\\varepsilon\\) is \\(C^1\\)-close to \\(F_0\\).

Then there exist constants \\(\\rho>0\\), \\(L>0\\), and \\(\\delta_0>0\\) such that if \\(\\delta_\\varepsilon<\\delta_0\\), there exists a locally unique section'''
assert old in s
s = s.replace(old, new)

# 4. Replace HPS proof mechanism paragraph.
old = '''In the Hirsch–Pugh–Shub proof, a Hadamard graph transform acting in the \\(C^0\\) metric gives existence, while cone invariance preserves the Lipschitz bound. Lifting the graph transform to jet bundles and applying the bunching assumptions gives higher regularity.'''
new = '''The graph transform acts as a contraction in the \\(C^0\\) graph metric, not in the Lipschitz norm. The Lipschitz bound is preserved separately by cone invariance. Thus the fixed point is obtained in the complete metric space \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric, while the cone estimates ensure that the transform maps \\(\\mathcal B_{\\rho,L}\\) into itself.

The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched forward and unstable components backward; the center coordinate labels the transformed graph. The cone estimates guarantee that the transformed set is again an admissible graph over \\(M\\).

Higher regularity follows by lifting the graph transform to jet bundles. For first jets, the principal fibre part is controlled by

\\[
\\|B_m^s\\|\\,\\|Df(m)^{-1}\\|,
\\qquad
\\|(B_m^u)^{-1}\\|\\,\\|Df(m)\\|.
\\]

The \\(1\\)-bunching assumption makes the corresponding fibre transform contractive. Inductively, the \\(k\\)-jet transform has principal part controlled by

\\[
\\|B_m^s\\|\\,\\|Df(m)^{-1}\\|^k,
\\qquad
\\|(B_m^u)^{-1}\\|\\,\\|Df(m)\\|^k.
\\]

The \\(k\\)-bunching assumption gives contraction on the \\(k\\)-jet fibres, while lower-order terms depend only on previously constructed jets and on derivatives of \\(F_\\varepsilon\\) up to order \\(k\\). The \\(C^0\\) contraction gives the zeroth-order estimate; derivative estimates require these lifted jet contractions.'''
assert old in s
s = s.replace(old, new)

# 5. Section 5: add tube explanatory sentence.
old = '''where \\(U_E^\\rho\\) denotes the tube of radius \\(\\rho\\).

In tubular coordinates,'''
new = '''where \\(U_E^\\rho\\) denotes the tube of radius \\(\\rho\\). This ensures that the graph transform is defined on the chosen class of graphs and that all transported fibre comparisons remain inside the fixed tubular coordinate neighbourhood.

In tubular coordinates,'''
assert old in s
s = s.replace(old, new)

# Add explanation for D_eta b0 after display.
old = '''and the invariant splitting implies

\\[
D_\\eta b_0(m,0)=0.
\\]

The normal linear cocycle is'''
new = '''and the invariant splitting implies

\\[
D_\\eta b_0(m,0)=0.
\\]

Indeed, \\(b_0\\) is the base component of \\(F_0\\) in tubular coordinates. The derivative \\(D_\\eta b_0(m,0)\\) is the base component of \\(DF_0(m)\\) applied to a vertical vector in \\(E_m\\). Since the invariant splitting gives \\(DF_0(m)E_m=E_{f(m)}\\), this derivative has no \\(TM\\)-component.

The normal linear cocycle is'''
assert old in s
s = s.replace(old, new)

# Insert D_eta b epsilon in Section 5 smallness paragraph by replacing sentence.
old = '''satisfies the smallness estimates required in Theorem 4.1, because \\(F_\\varepsilon\\) is \\(C^1\\)-close to \\(F_0\\) and because

\\[
D_\\eta b_0(m,0)=0.
\\]

Therefore Theorem 4.1 applies and yields a section'''
new = '''satisfies the smallness estimates required in Theorem 4.1, because \\(F_\\varepsilon\\) is \\(C^1\\)-close to \\(F_0\\) and because

\\[
D_\\eta b_0(m,0)=0.
\\]

The same argument gives

\\[
\\|D_\\eta b_\\varepsilon(m,\\eta)\\|
\\le
C\\delta_\\varepsilon+\\omega(\\rho)
\\]

on the tube. Therefore Theorem 4.1 applies and yields a section'''
assert old in s
s = s.replace(old, new)

# Quantitative section: insert jet constants and h0=0. Replace expansion paragraph onward to splitting paragraph.
old = '''If the perturbation admits an expansion

\\[
F_\\varepsilon
=
F_0+\\varepsilon F_1+\\cdots+\\varepsilon^k F_k
+O(\\varepsilon^{k+1})
\\]

in the appropriate topology, and if the required parameter-bunching conditions hold, then

\\[
h_\\varepsilon
=
h_0+\\varepsilon h_1+\\cdots+\\varepsilon^k h_k
+O(\\varepsilon^{k+1}).
\\]

Differentiating the invariance equation gives the coefficients \\(h_j\\) recursively. At each order one solves a linear cohomological equation of the form treated in Theorem 3.1.

The persistence of the invariant splitting follows from the roughness theorem for exponential dichotomies; see, for example, Palmer [6]. The perturbed normal cocycle is a small perturbation of the original cocycle, and the cohomological inverse remains bounded under sufficiently small perturbations. Consequently, for every weakened rate compatible with the original strict gap, the perturbed cocycle admits an exponential dichotomy with that rate. We obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original summands.

Theorem 4.1 gives local uniqueness. ∎'''
new = '''These \\(C^r\\) estimates require uniform contraction estimates for the lifted jet graph transforms. They do not follow from the \\(C^0\\) graph-transform contraction alone.

If the perturbation admits an expansion

\\[
F_\\varepsilon
=
F_0+\\varepsilon F_1+\\cdots+\\varepsilon^k F_k
+O(\\varepsilon^{k+1})
\\]

in the appropriate topology, and if the required parameter-bunching conditions hold, then, in the chosen tubular coordinates,

\\[
h_\\varepsilon
=
h_0+\\varepsilon h_1+\\cdots+\\varepsilon^k h_k
+O(\\varepsilon^{k+1}),
\\qquad h_0=0.
\\]

Differentiating the invariance equation gives the coefficients \\(h_j\\) recursively. At each order one solves a linear cohomological equation of the form treated in Theorem 3.1.

We next describe the persistence of the invariant splitting. Straighten \\(M_\\varepsilon\\) by the tubular change of variables

\\[
(m,\\eta)\\mapsto (m,\\eta-h_\\varepsilon(m)).
\\]

In these coordinates, \\(M_\\varepsilon\\) is the zero section. The derivative of \\(F_\\varepsilon\\) along \\(M_\\varepsilon\\) has triangular form

\\[
DF_\\varepsilon|_{M_\\varepsilon}
=
\\begin{pmatrix}
Df_\\varepsilon & *\\\\
0 & B_\\varepsilon
\\end{pmatrix},
\\]

where \\(B_\\varepsilon\\) is the perturbed normal cocycle. The cocycle \\(B_\\varepsilon\\) is \\(C^0\\)-close to \\(B\\), and \\(f_\\varepsilon\\) is \\(C^1\\)-close to \\(f\\). Roughness of exponential dichotomies gives an exponential dichotomy for \\(B_\\varepsilon\\), possibly with weakened rates; see, for example, Palmer [6]. Equivalently, we obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original stable and unstable summands.

More explicitly, if the original estimates involve a strict gap between normal rates and tangent rates, then any slightly weakened rates inside that gap persist. For example, if \\(\\alpha\\) denotes the relevant normal contraction or expansion rate and \\(\\beta\\) denotes the relevant tangent rate, one may choose

\\[
\\alpha'<\\alpha,
\\qquad
\\beta'>\\beta,
\\qquad
\\alpha'>\\beta',
\\]

with the required bunching margins. For sufficiently small \\(\\varepsilon\\), the perturbed splitting satisfies the corresponding estimates with \\(\\alpha'\\) and \\(\\beta'\\).

The bundles \\(E_\\varepsilon^s\\) and \\(E_\\varepsilon^u\\) are generally continuous under the basic hypotheses. Higher regularity of these bundles requires additional bunching assumptions and should not be inferred solely from the \\(C^r\\) regularity of \\(M_\\varepsilon\\).

Theorem 4.1 gives local uniqueness among admissible graphs. If one wants uniqueness among all sufficiently \\(C^1\\)-close invariant manifolds, one must first show that every such manifold lies in the admissible class. This is usually true for manifolds whose tangent spaces remain inside the prescribed center cones in tubular coordinates, but the theorem's intrinsic uniqueness statement is the qualified admissible-graph uniqueness above. ∎'''
assert old in s
s = s.replace(old, new)

# 6. Section 6: add R estimates after R(0) display.
old = '''where

\\[
R_n(0)=0,
\\qquad
DR_n(0)=0.
\\]

Choose \\(\\gamma\\) such that'''
new = '''where

\\[
R_n(0)=0,
\\qquad
DR_n(0)=0.
\\]

Shrinking the coordinate neighbourhood if necessary, the \\(C^{r+1}\\) regularity of \\(F_\\varepsilon\\) gives uniform estimates

\\[
\\|R_n(\\xi)\\|\\le C\\|\\xi\\|^2,
\\qquad
\\|DR_n(\\xi)\\|\\le C\\|\\xi\\|
\\]

for small \\(\\xi\\), uniformly in \\(n\\) and \\(p\\in M_\\varepsilon\\).

Choose \\(\\gamma\\) such that'''
assert old in s
s = s.replace(old, new)

# Add center not frozen after Perron definitions.
old = '''and

\\[
(\\mathcal P_a\\xi)_n^{cu}
=
-
\\sum_{k=n}^{\\infty}
\\Phi_\\varepsilon^{cu}(n,k+1)
P^{cu}_{k+1}R_k(\\xi_k).
\\]

Let

\\[
B_r:=\\{\\xi\\in\\ell_\\gamma^+:\\|\\xi\\|_\\gamma\\le r\\}.
\\]'''
new = '''and

\\[
(\\mathcal P_a\\xi)_n^{cu}
=
-
\\sum_{k=n}^{\\infty}
\\Phi_\\varepsilon^{cu}(n,k+1)
P^{cu}_{k+1}R_k(\\xi_k).
\\]

The center component is not frozen in this construction. It belongs to \\(\\xi_n^{cu}\\), and the future boundary condition determines it together with the unstable component. Thus the Perron operator solves simultaneously for the stable displacement, the center displacement, and the unstable displacement relative to the reference orbit.

Let

\\[
B_r:=\\{\\xi\\in\\ell_\\gamma^+:\\|\\xi\\|_\\gamma\\le r\\}.
\\]'''
assert old in s
s = s.replace(old, new)

# Replace stable invariance statement.
old = '''If \\(F_\\varepsilon\\) is a diffeomorphism, then

\\[
F_\\varepsilon(W^s(M_\\varepsilon))
=
W^s(M_\\varepsilon)
\\]

on the locally defined stable manifold. The unstable manifold \\(W^u(M_\\varepsilon)\\) is defined analogously using backward iteration.'''
new = '''The invariance property is

\\[
F_\\varepsilon(W^s(M_\\varepsilon))
\\subset
W^s(M_\\varepsilon).
\\]

If \\(F_\\varepsilon\\) is a diffeomorphism and the relevant inverse iterates remain in the domain where the stable manifold is defined, this inclusion becomes equality on the corresponding global stable set. The unstable manifold \\(W^u(M_\\varepsilon)\\) is defined analogously using backward iteration.'''
assert old in s
s = s.replace(old, new)

# Replace regularity section body with fuller distinction.
old = '''We obtain internal regularity of the stable leaves by differentiating the Perron operator with respect to the fibre coordinate \\(a\\). For \\(C^\\ell\\) internal regularity, one requires the strong stable bunching condition

\\[
\\alpha_s>\\ell\\,\\beta_{cu},
\\]

or the corresponding invariant product inequality.

Transverse regularity of the family of leaves, and regularity of the asymptotic phase projection

\\[
\\pi^s:W^s_{\\mathrm{loc}}(M_\\varepsilon)\\to M_\\varepsilon,
\\]

require separate bunching assumptions. In particular, the full stable foliation is not automatically \\(C^r\\) transversely.'''
new = '''We distinguish four regularity questions:

1. regularity of each stable leaf in its internal coordinate;
2. regularity of the leaf as a function of the base point \\(p\\in M_\\varepsilon\\);
3. regularity of the asymptotic phase projection

   \\[
   \\pi^s:W^s_{\\mathrm{loc}}(M_\\varepsilon)\\to M_\\varepsilon;
   \\]

4. regularity of the total lamination.

We obtain internal regularity of the stable leaves by differentiating the Perron operator with respect to the fibre coordinate \\(a\\). For \\(C^\\ell\\) internal regularity, one requires the strong stable bunching condition

\\[
\\alpha_s>\\ell\\,\\beta_{cu},
\\]

or, more invariantly, contractivity of the induced \\(\\ell\\)-jet Perron operator. The nonlinear Faà di Bruno terms are controlled by lower-order derivatives in the induction.

The dependence on \\(p\\) is generally weaker because the reference orbit \\(p_n=F_\\varepsilon^n(p)\\) enters the Perron operator. Under basic normal hyperbolicity the stable foliation is typically continuous, and often Hölder, transversely. Higher transverse regularity and regularity of \\(\\pi^s\\) require separate bunching assumptions. In particular, the full stable foliation is not automatically \\(C^r\\) transversely.'''
assert old in s
s = s.replace(old, new)

# 7. Flow section: replace admissibility sentence.
old = '''Thus \\(N_t\\) is invariant under the time-\\(T\\) map. For sufficiently small \\(\\varepsilon\\), \\(N_t\\) remains in the same admissible class uniformly for \\(t\\in[0,T]\\). By local uniqueness,'''
new = '''Thus \\(N_t\\) is invariant under the time-\\(T\\) map. For sufficiently small \\(\\varepsilon\\), and uniformly for \\(t\\in[0,T]\\), the manifold \\(N_t\\) remains in the same admissible tube and satisfies the same Lipschitz and cone bounds. This follows from the continuity of the flow in \\(t\\) and the \\(C^1\\)-closeness of \\(\\Phi_t^\\varepsilon\\) to \\(\\Phi_t^0\\) on compact time intervals. By local uniqueness,'''
assert old in s
s = s.replace(old, new)

# Replace final flow caveat with fuller warning.
old = '''If \\(M\\) is invariant only under a single time-\\(T\\) map of the unperturbed flow, the above uniqueness argument is not valid. In that case one must either assume full-flow invariance or construct the invariant manifold directly by a continuous-time Perron method.'''
new = '''If one only knows that \\(\\Phi_T^0(M)=M\\), but not that \\(\\Phi_t^0(M)=M\\) for all \\(t\\), then \\(\\Phi_t^0(M)\\) for \\(0<t<T\\) need not remain close to \\(M\\). In that case \\(N_t=\\Phi_t^\\varepsilon(M_\\varepsilon)\\) may fail to lie in the admissible tube around \\(M\\), so the uniqueness argument for the time-\\(T\\) graph transform cannot be applied. Thus the time-map reduction requires full-flow invariance, unless one constructs the invariant manifold directly by a continuous-time Lyapunov--Perron method.'''
assert old in s
s = s.replace(old, new)

# 8. Singular perturbation approximation formula.
old = '''Approximate reduced equations arise only after expanding \\(h_\\varepsilon\\) in powers of \\(\\varepsilon\\).

---

### 8.2. Parabolic semiflows'''
new = '''Approximate reduced equations arise only after expanding \\(h_\\varepsilon\\) in powers of \\(\\varepsilon\\). For example, if \\(h_\\varepsilon=h_0+O(\\varepsilon)\\), then

\\[
\\dot y
=
\\varepsilon g(h_0(y),y,0)+O(\\varepsilon^2).
\\]

---

### 8.2. Parabolic semiflows'''
assert old in s
s = s.replace(old, new)

# Clean a few style terms that might remain from insertions.
s = s.replace("the theorem's", "the theorem’s")

out = Path('/home/user/final_manuscript.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
