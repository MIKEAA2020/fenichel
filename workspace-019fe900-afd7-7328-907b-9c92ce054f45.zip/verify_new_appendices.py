from pathlib import Path
import json, math
import numpy as np
import sympy as sp

rng=np.random.default_rng(987654)
results=[]
def add(name, ok, detail): results.append({'check':name,'ok':bool(ok),'detail':detail})

# ---------------- Appendix D + F: normally attracting graph transform and parameter expansion ----------------
# Periodic base f(i)=i+shift mod N, scalar Banach fibre model.
N=101; shift=17
assert math.gcd(N,shift)==1
x=2*np.pi*np.arange(N)/N
B=0.42+0.05*np.sin(3*x)   # attracting multipliers
q=np.sin(x)+0.3*np.cos(2*x)
mu=0.11
# A h = h_f - B h
A=np.zeros((N,N))
for i in range(N):
    A[i,(i+shift)%N]=1.0
    A[i,i]-=B[i]
Ainv=np.linalg.inv(A)

def solve_graph(eps, maxit=100):
    h=np.zeros(N)
    for k in range(maxit):
        rhs=eps*q + mu*h*h
        hn=Ainv@rhs
        if np.max(np.abs(hn-h))<1e-14:
            return hn,k+1
        h=hn
    return h,maxit

eps=0.015
h,it=solve_graph(eps)
res=np.zeros(N)
for i in range(N):
    res[i]=h[(i+shift)%N]-B[i]*h[i]-eps*q[i]-mu*h[i]**2
add('appendix_D_attracting_graph_equation_residual', np.max(np.abs(res))<1e-13,
    f"max residual={np.max(np.abs(res)):.3e}, fixed point iterations={it}, ||h||inf={np.max(np.abs(h)):.3e}")
# empirical contraction derivative around small ball: T(h)=A^{-1}(eps q + mu h^2); derivative norm in sup <= ||A^-1|| * 2 mu r, sample.
ratios=[]
for _ in range(50):
    u=rng.normal(size=N)*0.02
    v=rng.normal(size=N)*0.02
    Tu=Ainv@(eps*q+mu*u*u)
    Tv=Ainv@(eps*q+mu*v*v)
    ratios.append(np.max(np.abs(Tu-Tv))/np.max(np.abs(u-v)))
add('appendix_D_attracting_empirical_contraction', max(ratios)<0.05,
    f"max sampled ratio={max(ratios):.3e}, median={np.median(ratios):.3e}")
# O(eps) scaling across eps values.
scales=[]
for e in [0.002,0.004,0.008,0.016,0.032]:
    he,_=solve_graph(e)
    scales.append(np.max(np.abs(he))/e)
add('appendix_D_attracting_solution_O_epsilon', max(scales)/min(scales)<1.08,
    f"||h_eps||/eps values={scales}")
# Appendix F expansion: h1=A^-1 q, h2=A^-1(mu*h1^2). Compare h(eps)=eps h1+eps^2 h2+O(eps^3)
h1=Ainv@q
h2=Ainv@(mu*h1*h1)
errs=[]
for e in [0.002,0.004,0.008,0.016]:
    he,_=solve_graph(e)
    err=np.max(np.abs(he - (e*h1 + e*e*h2)))
    errs.append((e,err,err/(e**3)))
add('appendix_F_parameter_expansion_second_order', max(v[2] for v in errs)<5,
    f"(eps, error, error/eps^3)={errs}")
# First derivative finite difference check
for e in [1e-3,5e-4,2.5e-4]:
    hp,_=solve_graph(e); hm,_=solve_graph(-e)
    fd=(hp-hm)/(2*e)
    fd_err=np.max(np.abs(fd-h1))
    last=(e,fd_err)
add('appendix_F_first_derivative_finite_difference', last[1]<1e-7,
    f"last eps={last[0]}, max |central diff - h1|={last[1]:.3e}")

# Symbolic parameter witness: scalar h - a h = eps q + mu h^2.
e,a,qsy,msy=sp.symbols('e a q mu')
h1s=qsy/(1-a)
h2s=msy*h1s**2/(1-a)
expr=(e*h1s+e**2*h2s)-a*(e*h1s+e**2*h2s)-e*qsy-msy*(e*h1s+e**2*h2s)**2
series=sp.series(expr,e,0,3).removeO().expand()
add('appendix_F_symbolic_coefficient_recursion', sp.simplify(series)==0,
    f"residual through order eps^2 = {series}")

# ---------------- Appendix E: close-base roughness graph transform ----------------
# Scalar stable/unstable blocks over periodic base. Random transported block estimates.
def close_base_trial(N=43,shift=11,delta=0.035):
    alpha=0.52+0.04*rng.random(N)   # Ass
    buu=2.15+0.25*rng.random(N)     # Auu expanding; inverse beta < .47
    Asu=delta*rng.uniform(-1,1,size=N)
    Aus=delta*rng.uniform(-1,1,size=N)
    L=np.zeros(N)
    for it in range(10000):
        X=np.zeros(N)
        # solve implicit scalar equation X = (L_f*(Ass+Asu*X)-Aus)/Auu exactly
        for i in range(N):
            fi=(i+shift)%N
            denom=buu[i]-L[fi]*Asu[i]
            X[i]=(L[fi]*alpha[i]-Aus[i])/denom
        if np.max(np.abs(X-L))<1e-14:
            L=X; break
        L=X
    # invariance residual A_us + A_uu L_i = L_f (A_ss + A_su L_i)
    resid=[]
    for i in range(N):
        fi=(i+shift)%N
        resid.append(abs(Aus[i]+buu[i]*L[i]-L[fi]*(alpha[i]+Asu[i]*L[i])))
    # stable coordinate contraction alpha+Asu*L
    rate=max(abs(alpha[i]+Asu[i]*L[i]) for i in range(N))
    return max(resid), max(abs(L)), rate, it+1, max(1/buu)
trials=[]
for _ in range(100):
    trials.append(close_base_trial(delta=float(rng.uniform(0.005,0.06))))
max_res=max(t[0] for t in trials); max_L=max(t[1] for t in trials); max_rate=max(t[2] for t in trials)
add('appendix_E_close_base_stable_graph_invariance_random', max_res<1e-12 and max_rate<0.65,
    f"100 trials: max invariance residual={max_res:.3e}, max ||L||={max_L:.3e}, max stable rate={max_rate:.3f}")
# Contraction factor formula witness
alpha=0.55; beta=0.43; R=0.08; delta=0.04
factor=beta*(alpha+delta*R)/(1-beta*R*delta)
add('appendix_E_contraction_factor_witness', factor<1,
    f"beta(alpha+delta R)/(1-beta R delta)={factor:.6f}")
# Invalid roughness: no domination alpha>=1 can fail contraction.
alpha_bad=1.20; beta=0.99; R=0.1; delta=0.02
factor_bad=beta*(alpha_bad+delta*R)/(1-beta*R*delta)
add('appendix_E_bad_constants_fail_domination', factor_bad>1,
    f"bad factor={factor_bad:.6f} > 1")

# ---------------- Appendix G: flow reduction witness ----------------
# Positive case: linear flow on cylinder (x mod 1, y), Phi_t(x,y)=(x+t mod1, exp(-t)y), M={y=0}.
def flow(t, pts):
    out=pts.copy()
    out[:,0]=(out[:,0]+t)%1.0
    out[:,1]=np.exp(-t)*out[:,1]
    return out
Mpts=np.column_stack([np.linspace(0,1,200,endpoint=False), np.zeros(200)])
T=1.0
N_t=flow(0.37,Mpts)
F_N_t=flow(T,N_t)
add('appendix_G_full_flow_invariant_positive_witness', np.max(np.abs(N_t[:,1]))<1e-15 and np.max(np.abs(F_N_t[:,1]))<1e-15,
    "Flow Phi_t(x,y)=(x+t,e^{-t}y) keeps M={y=0} invariant for all t; N_t=M in sampled representation")
# Necessity counterexample: circle flow theta->theta+t, M={0}, T=2pi time map fixes M but intermediate leaves.
theta0=0.0; T=2*math.pi; t=math.pi/2
image=(theta0+t)%(2*math.pi)
add('appendix_G_time_T_only_invariance_counterexample', abs(image-theta0)>1.0,
    f"circle flow: Phi_T^0({theta0})={theta0} for T=2pi, but Phi_{t}^0({theta0})={image:.3f} not in M")

# ---------------- Appendix C fixed-base roughness extra check ----------------
# Compare stable graph from Appendix C (Perron) vs Appendix E scalar block when base fixed; already similar. Check graph size O(delta).
deltas=[0.005,0.01,0.02,0.04]
rat=[]
for d in deltas:
    res,Lnorm,rate,_,_=close_base_trial(delta=d)
    rat.append(Lnorm/d)
add('roughness_graph_size_linear_in_delta', max(rat)/min(rat)<2.5,
    f"||L||/delta values={rat}")

all_ok=all(r['ok'] for r in results)
lines=['# Deep Verification of New Appendices D–G','', 'This report computationally stress-tests the newly added normally attracting graph transform, close-base roughness graph transform, parameter expansion recursion, and flow time-map reduction.', '', f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for r in results:
    lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['check']}** — {r['detail']}")
lines += ['', '## Interpretation', '',
'- Appendix D is tested by a nonlinear attracting graph equation over a periodic base; the computed invariant graph has residual at roundoff and scales like O(epsilon).',
'- Appendix F is tested by comparing the exact nonlinear graph with the recursively computed first and second expansion coefficients.',
'- Appendix E is tested by 100 randomized close-base transported block models; invariant stable graph residuals are at roundoff and the stable rates remain below one.',
'- Appendix G is tested by a positive full-flow invariant example and by a time-T-only counterexample showing why full-flow invariance is necessary.']
Path('/home/user/new_appendices_deep_verification_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results}, indent=2))
