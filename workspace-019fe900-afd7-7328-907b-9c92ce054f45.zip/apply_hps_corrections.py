from pathlib import Path
p=Path('/home/user/final_manuscript_full_revised.md')
s=p.read_text()

# Replace false cone-invariance paragraph
old='''A \\(C^1\\) section with \\(\\operatorname{Lip}(h)\\le\\kappa\\) has a graph tangent to the center cones; a merely Lipschitz section satisfies the corresponding secant-cone condition. The center cones control admissible graphs, while the stable and unstable cones control the Hadamard matching used in the graph transform.

For \\(\\rho\\), \\(L\\), and \\(\\delta_\\varepsilon\\) sufficiently small, the exponential dichotomy and bunching inequalities imply the following cone invariance properties: \\(DF_\\varepsilon\\) maps center cones strictly inside center cones; \\(DF_\\varepsilon\\) maps stable cones strictly inside stable cones; \\(DF_\\varepsilon^{-1}\\) maps unstable cones strictly inside unstable cones; stable-cone vectors contract forward relative to center vectors; and unstable-cone vectors contract backward relative to center vectors. These estimates follow from the stable and unstable bounds for \\(B\\), the boundedness of the tangent dynamics \\(Df\\), and the smallness of the nonlinear terms.'''
new='''A \\(C^1\\) section with \\(\\operatorname{Lip}(h)\\le\\kappa\\) has a graph tangent to the center cones; a merely Lipschitz section satisfies the corresponding secant-cone condition. The center cones describe admissible graphs, while the stable and unstable cones enter the two-sided Hadamard matching construction.

In the two-sided normally hyperbolic case, we do not assert that \\(DF_\\varepsilon\\) maps center cones forward into center cones; unstable expansion can destroy such a statement. Instead, the graph transform is a two-sided Hadamard transform. It preserves the admissible class of Lipschitz graphs by stable and unstable matching estimates and is a contraction in the transported \\(C^0\\) graph metric. The estimates use the stable and unstable bounds for \\(B\\), the boundedness of the tangent dynamics \\(Df\\), the smallness of the base-normal coupling, and the strengthened remainder estimates below.'''
assert old in s
s=s.replace(old,new)

# Add base derivative smallness after D_eta r estimate before pointwise equivalent.
old='''   and \\(\\omega(\\rho)\\to0\\) as \\(\\rho\\to0\\).

   Equivalently, after reducing the tube if necessary, these estimates imply'''
new='''   and \\(\\omega(\\rho)\\to0\\) as \\(\\rho\\to0\\).

   In adapted bundle charts, assume also the base derivative estimate

   \\[
   \\|D_m r_\\varepsilon(m,\\eta)\\|
   \\le
   C\\delta_\\varepsilon+\\omega(\\rho).
   \\]

   In the present NHIM setting this follows from \\(g_0(m,0)=0\\), \\(D_\\eta g_0(m,0)=B_m\\), and \\(C^{r+1}\\) regularity after subtracting the transported linear part. This estimate prevents a non-small base-variation term in the Lipschitz preservation argument.

   Equivalently, after reducing the tube if necessary, these estimates imply'''
assert old in s
s=s.replace(old,new)

# Change Theorem 4.1 conclusion block
old='''and

\\[
F_\\varepsilon(\\operatorname{graph}(h_\\varepsilon))
=
\\operatorname{graph}(h_\\varepsilon).
\\]

More explicitly, defining

\\[
f_\\varepsilon(m):=b_\\varepsilon(m,h_\\varepsilon(m)),
\\]

one has

\\[
F_\\varepsilon(m,h_\\varepsilon(m))
=
\\bigl(f_\\varepsilon(m),h_\\varepsilon(f_\\varepsilon(m))\\bigr).
\\]
'''
new='''Define

\\[
f_\\varepsilon(m):=b_\\varepsilon(m,h_\\varepsilon(m)).
\\]

Then \\(h_\\varepsilon\\) satisfies the graph equation

\\[
h_\\varepsilon(f_\\varepsilon(m))
=
g_\\varepsilon(m,h_\\varepsilon(m)),
\\]

or equivalently

\\[
F_\\varepsilon(m,h_\\varepsilon(m))
=
\\bigl(f_\\varepsilon(m),h_\\varepsilon(f_\\varepsilon(m))\\bigr).
\\]

Moreover, \\(f_\\varepsilon\\) is a \\(C^r\\) local diffeomorphism \\(C^1\\)-close to \\(f\\). Setwise equality

\\[
F_\\varepsilon(\\operatorname{graph}(h_\\varepsilon))
=
\\operatorname{graph}(h_\\varepsilon)
\\]

follows once \\(f_\\varepsilon\\) is known to be onto; in Theorem 5.1 this is proved by the compact local-diffeomorphism argument.
'''
assert old in s
s=s.replace(old,new)

# Parameter dependence statement in Theorem 4.1
old='''If \\(F_\\varepsilon\\) depends smoothly on \\(\\varepsilon\\) and the bunching assumptions hold uniformly, then \\(h_\\varepsilon\\) depends smoothly on \\(\\varepsilon\\), with regularity determined by the parameter-bunching conditions.'''
new='''If \\(F_\\varepsilon\\) depends \\(C^\\ell\\) on \\(\\varepsilon\\) in the appropriate \\(C^{r+1}\\) topology, and if the required mixed base/parameter bunching inequalities hold up to the relevant total order, then \\(h_\\varepsilon\\) depends \\(C^\\ell\\) on \\(\\varepsilon\\), with regularity determined by those mixed bunching conditions. Without such mixed estimates one should only claim the parameter regularity supplied by the available uniform contraction estimates.'''
assert old in s
s=s.replace(old,new)

# Section 4 graph transform paragraph: remove cone guarantees if too strong
old='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched forward and unstable components backward; the center coordinate labels the transformed graph. The cone estimates guarantee that the transformed set is again an admissible graph over \\(M\\).'''
new='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched in one time direction and unstable components in the opposite time direction; the center coordinate labels the transformed graph. The admissible-graph preservation estimate comes from these stable/unstable matching equations, not from forward invariance of center cones.'''
assert old in s
s=s.replace(old,new)

# Section 5 application wording
old='''Therefore Theorem 4.1 applies and yields a section

\\[
h_\\varepsilon\\in\\Gamma^r(E)
\\]

such that its graph is invariant. Define'''
new='''Therefore Theorem 4.1 applies and yields a section

\\[
h_\\varepsilon\\in\\Gamma^r(E)
\\]

satisfying the graph equation. Define'''
assert old in s
s=s.replace(old,new)

old='''The invariance of the graph gives

\\[
F_\\varepsilon(K_\\varepsilon(m))
=
K_\\varepsilon(f_\\varepsilon(m)).
\\]

Hence

\\[
F_\\varepsilon(M_\\varepsilon)\\subset M_\\varepsilon.
\\]

We next prove equality.'''
new='''The graph equation gives

\\[
F_\\varepsilon(K_\\varepsilon(m))
=
K_\\varepsilon(f_\\varepsilon(m)).
\\]

Hence

\\[
F_\\varepsilon(M_\\varepsilon)\\subset M_\\varepsilon.
\\]

We next prove equality by proving invariance under the original map, when an iterate was used, and then proving that \\(f_\\varepsilon\\) is onto.'''
assert old in s
s=s.replace(old,new)

# Tie Theorem 3.1 Ck to Appendix/future path? Maybe update sentence around projections.
old='''When the projections are not differentiable, use transported difference quotients. If \\(V\\) is a smooth vector field on \\(M\\) with local flow \\(\\varphi_t\\), define'''
new='''When the projections are not differentiable, the argument is interpreted in the transported difference-quotient sense rather than by differentiating the splitting. This is the linear version of the HPS topological-jet argument; alternatively, one may assume \\(C^r\\) regularity of the splitting and work with ordinary jet bundles. If \\(V\\) is a smooth vector field on \\(M\\) with local flow \\(\\varphi_t\\), define'''
assert old in s
s=s.replace(old,new)

out=Path('/home/user/final_manuscript_hps_corrected.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
