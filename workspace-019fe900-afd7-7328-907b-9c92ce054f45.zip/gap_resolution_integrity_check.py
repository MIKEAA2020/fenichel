from pathlib import Path
import re,json
p=Path('/home/user/final_manuscript_gap_resolutions.md')
s=p.read_text()
checks=[]
def add(n,ok,d): checks.append({'name':n,'ok':bool(ok),'detail':d})
add('display_math_balanced',s.count('\\[')==s.count('\\]'),f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_math_balanced',s.count('\\(')==s.count('\\)'),f"{s.count('\\(')} vs {s.count('\\)')}")
add('env_balanced',re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s),str((re.findall(r'\\begin\{([^}]+)\}',s),re.findall(r'\\end\{([^}]+)\}',s))))
for pat in ['maps center cones strictly','follows by the same argument','Your assessment','Final honest','What has been repaired','invalid Lipschitz','false Lipschitz']:
 add('absent_'+pat[:20],pat not in s,pat)
for pat in ['Appendix A. The \\(C^k\\) Banach-bundle cohomological inverse theorem','Appendix B. Strong fibres from a half-line Perron method','Appendix C. Roughness of exponential dichotomies in Banach bundles','triangular wave','center-stable and center-unstable','D_m r_\\varepsilon','mixed base/parameter bunching','graph equation','not from forward invariance of center cones','C_3(\\gamma)\\delta<1']:
 add('present_'+pat[:20],pat in s,pat)
# broken math newlines known bad
for pat in ['_\n\\gamma','-\n\\eta','p+\n\\xi','C_2(\n']:
 add('absent_broken_'+pat.replace('\n','N'),pat not in s,pat)
all_ok=all(c['ok'] for c in checks)
lines=['# Gap Resolution Integrity Check','',f'Manuscript: `{p}`','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for c in checks: lines.append(f"- {'✅' if c['ok'] else '❌'} **{c['name']}** — {c['detail']}")
Path('/home/user/gap_resolution_integrity_check_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'checks':checks},indent=2))
