# Fractional Jet Spectra for Banach-Bundle Cohomological Equations

## Abstract

We prove a real-order cohomological inverse theorem for Banach-bundle cocycles over finite-dimensional compact bases. The theorem replaces one-step integer bunching assumptions by a fractional jet spectrum: the exponential growth rate of the exact Green summand operators acting on Hölder jet sections. If this operator radius is strictly smaller than one, then the cohomological operator

\[
\mathcal A\zeta=
\zeta\circ f-B\zeta
\]

is an isomorphism on \(C^{k,\alpha}\) sections. The formulation includes all Hölder distortion terms of the normal cocycle, the base dynamics, the projections, and the bundle transports. We also prove a periodic jet-resonance obstruction: if the full triangular jet return map has a unit resonance at a periodic orbit, then \(\mathcal A\) fails to be onto on the corresponding \(C^k\) space. The result isolates the exact linear regularity threshold for the Green inverse and supplies sharp witnesses for loss of smooth surjectivity.

---

## 1. Introduction

In normally hyperbolic persistence theory, the regularity of invariant graphs is controlled by competition between normal contraction/expansion and tangent distortion. Integer bunching inequalities express this competition at orders \(k=0,1,\ldots,r\). However, applications often require noninteger Hölder spaces \(C^{k,\alpha}\), and the natural threshold is not a one-step norm inequality but an asymptotic spectral condition for the induced jet cocycles.

This note proves a fractional version of the Banach-bundle cohomological inverse theorem. The central object is the growth rate of the exact stable and unstable Green summand operators on Hölder jet sections. This definition includes the Hölder variation of the cocycle products, the derivative iterates of the base map, the dichotomy projections, and the bundle transports. It therefore avoids a common under-assumption: controlling only the pointwise product

\[
\|\Phi(n,0)\|\,\|Df^{-n}\|^k\operatorname{Lip}(f^{-n})^\alpha
\]

does not, by itself, control the full \(C^\alpha\) norm of the induced jet evolution.

The second main result gives a converse obstruction. At a periodic orbit, the full finite jet return map is triangular. If the operator \(I\) minus that return map is not onto, then the cohomological equation is not onto in \(C^k\). This identifies the familiar jet resonance obstruction in an intrinsic Banach-bundle form.

---

## 2. Hölder Banach-bundle setting

Let \(M\) be a compact finite-dimensional \(C^{r+1,\beta}\) manifold without boundary, where \(0<\beta\le1\). Let \(E\to M\) be a \(C^{r+1,\beta}\) Banach bundle. Fix either a \(C^{r,\beta}\) connection or a finite \(C^{r+1,\beta}\) bundle atlas with uniformly controlled transition maps.

Let

\[
f\in\operatorname{Diff}^{r+1,\beta}(M),
\]

and let

\[
B_m:E_m\to E_{f(m)}
\]

be a \(C^{r,\beta}\) bundle automorphism. Assume a \(C^{r,\beta}\) invariant splitting

\[
E=E^s\oplus E^u
\]

with uniformly bounded \(C^{r,\beta}\) projections. Assume that \(B\) has a uniform exponential dichotomy over \(f\).

Let

\[
s=k+\alpha,
\qquad
0<\alpha<1,
\]

where \(k\) is a nonnegative integer and

\[
k+\alpha\le r+\beta.
\]

The space \(C^{k,\alpha}(M,E)\) is defined using the fixed connection or finite atlas. For \(k=0\), this is the usual Hölder section space \(C^\alpha(M,E)\).

---

## 3. Hölder Green summand operators

Let

\[
\mathcal J_k(E):=
\operatorname{Sym}^k(T^*M;E)
\]

be the bundle of symmetric \(k\)-linear covariant tensors with values in \(E\). For \(k=0\), set \(\mathcal J_0(E)=E\).

The principal \(k\)-jet cocycle over \(f\) is

\[
\mathscr B_k(m)J
=
B_m\circ J\circ(Df(m)^{-1})^{\otimes k},
\]

mapping \(\mathcal J_k(E)_m\) to \(\mathcal J_k(E)_{f(m)}\).

The stable Green summand of length \(n\) is the operator

\[
\mathcal S_{k,n}^+:
C^\alpha(M,
\mathcal J_k(E)^s)
\to
C^\alpha(M,
\mathcal J_k(E)^s)
\]

which assigns to a jet-forcing section its stable contribution transported from time \(-n\) to time \(0\). In local notation,

\[
(\mathcal S_{k,n}^+Q)(m)
=
\Phi^s(0,-n;m)
\,Q(f^{-n}m)
\circ
(Df^{-n}(m))^{\otimes k},
\]

with the appropriate bundle transports and projections included. Similarly, the unstable Green summand of length \(n\) is

\[
\mathcal S_{k,n}^-:
C^\alpha(M,
\mathcal J_k(E)^u)
\to
C^\alpha(M,
\mathcal J_k(E)^u),
\]

with local form

\[
(\mathcal S_{k,n}^-Q)(m)
=
\Phi^u(0,n;m)
\,Q(f^n m)
\circ
(Df^{n}(m))^{\otimes k}.
\]

These definitions are invariantly interpreted using the fixed connection or atlas. Their operator norms on \(C^\alpha\) include all Hölder variation of cocycle products, projections, derivative iterates, and transports.

Define the fractional jet radii

\[
\widehat\rho_{k,\alpha}^+
=
\limsup_{n\to\infty}
\|\mathcal S_{k,n}^+\|_{C^\alpha\to C^\alpha}^{1/n},
\]

and

\[
\widehat\rho_{k,\alpha}^-
=
\limsup_{n\to\infty}
\|\mathcal S_{k,n}^-\|_{C^\alpha\to C^\alpha}^{1/n}.
\]

Set

\[
\widehat\rho_{k,\alpha}
=
\max\{
\widehat\rho_{k,\alpha}^+,
\widehat\rho_{k,\alpha}^-
\}.
\]

---

## 4. Fractional cohomological inverse theorem

### Theorem 4.1. Hölder jet-spectrum inverse

Assume the \(C^0\) exponential dichotomy. Let \(k+\alpha\le r+\beta\), with \(0<\alpha<1\). If

\[
\widehat\rho_{k,\alpha}<1,
\]

then

\[
\mathcal A:
C^{k,\alpha}(M,E)
\to
C^{k,\alpha}(M,f^*E),
\qquad
(\mathcal A\zeta)(m)=
\zeta(f(m))-B_m\zeta(m),
\]

is an isomorphism. Moreover,

\[
\|\mathcal A^{-1}q\|_{C^{k,\alpha}}
\le
C_{k,\alpha}
\|q\|_{C^{k,\alpha}}.
\]

The same statement holds on noncompact bounded-geometry bases in \(C_b^{k,\alpha}\) spaces if all geometric and operator-norm estimates are uniform.

---

## 5. Proof of Theorem 4.1

### 5.1. Zeroth-order inverse

The \(C^0\) inverse is the ordinary Green operator. Along an orbit \(m_n=f^n(m)\), write

\[
q_n=q(m_n)\in E_{m_{n+1}}.
\]

Decompose in the target fibre:

\[
q_n^\sigma=P_{m_{n+1}}^\sigma q_n.
\]

The unique bounded solution of

\[
\zeta_{n+1}-B_{m_n}\zeta_n=q_n
\]

is

\[
\zeta_n^s
=
\sum_{j=-\infty}^{n-1}
\Phi^s(n,j+1)q_j^s,
\]

and

\[
\zeta_n^u
=
-
\sum_{j=n}^{\infty}
\Phi^u(n,j+1)q_j^u.
\]

This gives a bounded inverse on \(C^0\), and uniqueness follows from the usual bounded homogeneous-solution argument.

### 5.2. Hölder Green lemma

We use the following abstract observation. Let \(F\to M\) be a \(C^\alpha\) Banach bundle and let \(C_m:F_m\to F_{f(m)}\) be a cocycle with a \(C^0\) exponential dichotomy. Suppose the exact stable and unstable Green summand operators on \(C^\alpha\) sections satisfy

\[
\limsup_{n\to\infty}
\|\mathcal S_n^+\|_{C^\alpha\to C^\alpha}^{1/n}<1,
\]

and

\[
\limsup_{n\to\infty}
\|\mathcal S_n^-\|_{C^\alpha\to C^\alpha}^{1/n}<1.
\]

Then the Green operator is bounded on \(C^\alpha\).

Indeed, choose \(\theta<1\) larger than both limsup values. Then, for all sufficiently large \(n\),

\[
\|\mathcal S_n^\pm\|_{C^\alpha\to C^\alpha}
\le
C\theta^n.
\]

The finitely many small \(n\) terms are harmless, and the Green series is a normally convergent series in the Banach space \(C^\alpha(M,F)\). This proves the bounded \(C^\alpha\) estimate.

### 5.3. Application to the \(k\)-jet equation

For the cohomological equation

\[
\zeta\circ f-B\zeta=q,
\]

the \(k\)-th covariant derivative has principal part

\[
D^k\zeta(f(m))
\circ Df(m)^{\otimes k}
-
B_mD^k\zeta(m).
\]

Equivalently, with \(J=D^k\zeta\),

\[
J(f(m))-\mathscr B_k(m)J(m)=Q_k(m),
\]

where \(Q_k\) contains \(D^kq\) and lower-order terms involving derivatives of \(f\), \(B\), the connection, and \(\zeta\) up to order \(k-1\).

The integer \(C^k\) cohomological inverse theorem gives

\[
\|\zeta\|_{C^k}
\le
C_k\|q\|_{C^k}.
\]

Because \(q\in C^{k,\alpha}\), and because the data have regularity at least \(C^{k,\alpha}\), the lower-order terms satisfy

\[
\|Q_k\|_{C^\alpha}
\le
C_{k,\alpha}\|q\|_{C^{k,\alpha}}.
\]

By definition, the stable and unstable Green summands for the \(k\)-jet equation have radii bounded by \(\widehat\rho_{k,\alpha}<1\). The Hölder Green lemma therefore gives

\[
\|D^k\zeta\|_{C^\alpha}
\le
C_{k,\alpha}\|Q_k\|_{C^\alpha}
\le
C_{k,\alpha}
\|q\|_{C^{k,\alpha}}.
\]

Together with the integer estimate, this yields

\[
\|\zeta\|_{C^{k,\alpha}}
\le
C_{k,\alpha}\|q\|_{C^{k,\alpha}}.
\]

### 5.4. Avoiding circular differentiability

Let \(G_Nq\) denote the Green series truncated at orbit lengths at most \(N\). Since the summands are \(C^{k,\alpha}\), each \(G_Nq\) is \(C^{k,\alpha}\). The argument above applies uniformly to the finite sums and shows that \(G_Nq\) is Cauchy in \(C^{k,\alpha}\). The uniform limit is the \(C^0\) Green solution \(Gq\). Hence \(Gq\in C^{k,\alpha}\), and the estimate follows. This avoids assuming differentiability of the \(C^0\) solution in advance.

Uniqueness in \(C^{k,\alpha}\) follows from uniqueness in \(C^0\). Thus \(\mathcal A\) is an isomorphism on \(C^{k,\alpha}\).

---

## 6. Relation with one-step Hölder bunching

A stronger but more concrete sufficient condition is obtained by estimating the exact operator norms \(\|\mathcal S_{k,n}^\pm\|_{C^\alpha\to C^\alpha}\). If the cocycle products, projections, derivative iterates, and bundle transports have bounded distortion so that

\[
\|\mathcal S_{k,n}^+\|_{C^\alpha\to C^\alpha}
\le
C\theta^n
\]

and

\[
\|\mathcal S_{k,n}^-\|_{C^\alpha\to C^\alpha}
\le
C\theta^n
\]

for some \(\theta<1\), then \(\widehat\rho_{k,\alpha}<1\). In particular, the usual pointwise real-order bunching inequalities imply the theorem when supplemented by the corresponding bounded-distortion estimates for the iterated jet cocycles.

Thus the operator radius is the intrinsic formulation, while one-step norm-bunching is a convenient sufficient condition in adapted settings.

---

## 7. Periodic jet-resonance obstruction

Let \(p\) be a periodic point of prime period \(N\). Let

\[
\mathfrak J_{\le k,p}
=
\bigoplus_{j=0}^{k}
\operatorname{Sym}^j(T_p^*M;E_p)
\]

be the full jet space up to order \(k\). The return map of the cohomological equation on jets is a triangular operator

\[
\mathfrak R_{\le k}(p):
\mathfrak J_{\le k,p}
\to
\mathfrak J_{\le k,p}.
\]

Its diagonal order-\(j\) block is the principal jet return map

\[
\mathscr R_j(p)J
=
\Phi(N,0;p)
\circ J\circ
(Df^N(p)^{-1})^{\otimes j}.
\]

Lower-order jet terms appear in the upper triangular blocks.

### Proposition 7.1. Periodic jet-resonance obstruction

Assume the zeroth-order normal cocycle has an exponential dichotomy, so that \(\mathcal A\) is invertible on \(C^0\). If, for some periodic point \(p\),

\[
I-
\mathfrak R_{\le k}(p)
\]

is not surjective, then

\[
\mathcal A:C^k(M,E)	o C^k(M,f^*E)
\]

is not surjective.

If all lower-order blocks are nonresonant and

\[
I-
\mathscr R_k(p)
\]

is not surjective, the same conclusion follows.

#### Proof

Suppose \(\mathcal A:C^k(M,E)	o C^k(M,f^*E)\) were onto. Choose a finite jet datum for \(q\) along the periodic orbit such that the induced right-hand side in the periodic jet equation lies outside the range of

\[
I-
\mathfrak R_{\le k}(p).
\]

This is possible because the latter operator is not surjective. Since the periodic orbit is finite and \(M\) is finite-dimensional, a \(C^k\) section realizing these finite jets exists by a local bump-function construction in disjoint coordinate charts.

Let \(\zeta\in C^k(M,E)\) solve \(\mathcal A\zeta=q\). Taking jets of order \(\le k\) along the periodic orbit gives a linear periodic system. Iterating around the orbit yields

\[
(I-
\mathfrak R_{\le k}(p))Z=Q,
\]

where \(Z\) is the jet of \(\zeta\) at \(p\), and \(Q\) is the prescribed jet datum of \(q\). This contradicts the choice of \(Q\). Hence \(\mathcal A\) is not onto on \(C^k\).


---

## 8. Compact return maps and Fredholm resonance

The obstruction in Proposition 7.1 is stated as failure of surjectivity of

\[
I-\mathfrak R_{\le k}(p).
\]

In general Banach spaces this is the correct formulation: non-surjectivity need not be caused by an eigenvector. In compact or smoothing settings, however, the obstruction becomes an ordinary eigenvalue resonance.

### Theorem 8.1. Compact jet-return Fredholm alternative

Let \(Y\) be a Banach space and let

\[
K:Y\to Y
\]

be compact. If

\[
I-K
\]

is not surjective, then \(1\) is an eigenvalue of \(K\). Moreover, this eigenvalue has finite algebraic multiplicity.

Consequently, if the periodic jet-return operator

\[
\mathfrak R_{\le k}(p):\mathfrak J_{\le k,p}\to\mathfrak J_{\le k,p}
\]

is compact and if

\[
I-\mathfrak R_{\le k}(p)
\]

is not surjective, then there exists a nonzero jet

\[
J\in\mathfrak J_{\le k,p}
\]

such that

\[
\mathfrak R_{\le k}(p)J=J.
\]

Thus, in compact-return settings, the periodic obstruction is an eigenvalue-one resonance of finite algebraic multiplicity.

#### Proof

For a compact operator \(K\) on a Banach space, the Riesz--Schauder theorem states that every nonzero point of the spectrum of \(K\) is an eigenvalue of finite algebraic multiplicity, and the only possible accumulation point of the spectrum is \(0\). If \(I-K\) is not surjective, then \(I-K\) is not invertible; hence \(1\in\sigma(K)\). Since \(1\ne0\), Riesz--Schauder implies that \(1\) is an eigenvalue of finite algebraic multiplicity. Applying this to \(K=\mathfrak R_{\le k}(p)\) proves the claim. ∎

### Corollary 8.2. Parabolic compact-return case

Assume a parabolic or smoothing setting in which the linear time-return map along a periodic orbit is compact on the chosen normal fibre space, for example because the sectorial generator has compact resolvent and the return time is positive. Since the tangent jet factors are finite-dimensional, the induced finite jet-return map

\[
\mathfrak R_{\le k}(p)
\]

is compact on the Banach jet fibre. Therefore any failure of surjectivity of

\[
I-\mathfrak R_{\le k}(p)
\]

is equivalent to the existence of an eigen-jet with eigenvalue \(1\).

Without compactness, Proposition 7.1 should not be strengthened in this way: the obstruction may lie in point, continuous, or residual spectrum. The correct general statement remains non-surjectivity of \(I-\mathfrak R_{\le k}(p)\).

---

## 9. Witness: first-jet resonance on a two-cycle

Let the base have a two-cycle and consider scalar fibres. Take normal multipliers

\[
B_0=B_1=\frac12
\]

and tangent derivatives

\[
Df_0=Df_1=\frac12.
\]

The \(C^0\) cohomological matrix is

\[
\begin{pmatrix}
-1/2&1\\
1&-1/2
\end{pmatrix},
\]

whose determinant is

\[
-\frac34\ne0.
\]

Thus the \(C^0\) equation is invertible. But the first-jet matrix is

\[
\begin{pmatrix}
-1&1\\
1&-1
\end{pmatrix},
\]

whose determinant is zero. The first-jet return map has eigenvalue one, so the \(C^1\) cohomological equation is not onto. This is the simplest periodic jet-resonance obstruction.

---

## 10. Regularity spectrum

Define

\[
s_*=\sup\{k+\alpha:
\widehat\rho_{k,\alpha}<1\}.
\]

Then the Green inverse is bounded on every noninteger Hölder space \(C^{k,\alpha}\) with

\[
k+\alpha<s_*
\]

for which the data have the required regularity. Periodic jet resonances obstruct surjectivity at resonant integer orders. Thus the fractional jet spectrum describes the linear regularity threshold for the cohomological inverse.


## 11. Model examples

### 10.1. Hyperbolic toral base with scalar attracting normal direction

Let

\[
A=
\begin{pmatrix}
2&1\\
1&1
\end{pmatrix}
\]

act on \(\mathbb T^2\). Its expanding eigenvalue is

\[
\Lambda=
\frac{3+
\sqrt5}{2}>1.
\]

Let \(E=\mathbb T^2\times\mathbb R\), and let the normal cocycle be scalar multiplication by

\[
0<\lambda<1.
\]

Then the cohomological equation is

\[
\zeta(Ax)-\lambda\zeta(x)=q(x).
\]

The stable Green summands at real order \(s=k+\alpha\) have growth rate

\[
\widehat\rho_s=
\lambda\Lambda^s.
\]

Consequently the Green inverse is bounded on every \(C^s\) space with

\[
s<\frac{\log(1/\lambda)}{
\log\Lambda}.
\]

Thus the regularity threshold is

\[
s_*=
\frac{\log(1/\lambda)}{
\log\Lambda}.
\]

If \(\lambda=\Lambda^{-N}\) for an integer \(N\), then the principal order-\(N\) jet return map at the fixed point \(0\in\mathbb T^2\) has eigenvalue one. Hence the periodic jet-resonance obstruction applies at order \(N\). This gives an explicit family where the fractional spectrum predicts the loss of integer-order surjectivity at the threshold.

### 10.2. Isometric base dynamics

If \(f\) is an isometry and the bundle transports, projections, and cocycle products have uniformly bounded Hölder constants, then

\[
\operatorname{Lip}(f^{\pm n})=1.
\]

For a scalar normally attracting cocycle \(B_m=\lambda\), \(0<\lambda<1\), the fractional radius is simply

\[
\widehat\rho_s=\lambda
\]

for all \(s\) allowed by the regularity of the data. Thus the cohomological inverse loses no regularity beyond the regularity already present in the coefficients. This contrasts with the hyperbolic toral example, where tangent distortion creates a finite regularity threshold.

---
---

## References

[1] M. Hirsch, C. Pugh, M. Shub, *Invariant Manifolds*, Lecture Notes in Mathematics 557, Springer, 1977.

[2] K. J. Palmer, *Exponential dichotomies and transversal homoclinic points*, Journal of Differential Equations 38 (1980), 225–256.
