from pathlib import Path
import re, json
p=Path('/home/user/final_manuscript_all_findings.md')
s=p.read_text()
checks=[]
def add(name, ok, detail): checks.append({'name':name,'ok':bool(ok),'detail':detail})
add('display_math_balanced', s.count('\\[')==s.count('\\]'), f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_math_balanced', s.count('\\(')==s.count('\\)'), f"{s.count('\\(')} vs {s.count('\\)')}")
add('latex_env_balanced', re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s), f"begin={re.findall(r'\\begin\{([^}]+)\}',s)}, end={re.findall(r'\\end\{([^}]+)\}',s)}")
for pat in ['Your assessment','Your diagnosis','What has been repaired','Final honest','invalid Lipschitz','false Lipschitz','maps center cones strictly','follows by the same argument']:
    add('absent_'+pat[:20].replace(' ','_'), pat not in s, pat)
for pat in ['Appendix A. The \\(C^k\\) Banach-bundle cohomological inverse theorem','Appendix B. Strong fibres from a half-line Perron method','triangular wave','center-stable and center-unstable','D_m r_\\varepsilon','mixed base/parameter bunching','graph equation','not from forward invariance of center cones']:
    add('present_'+pat[:25].replace(' ','_'), pat in s, pat)
all_ok=all(c['ok'] for c in checks)
lines=['# Final Integrity Check', '', f'Manuscript: `{p}`', '', f'Overall: **{"PASS" if all_ok else "ISSUES"}**', '']
for c in checks: lines.append(f"- {'✅' if c['ok'] else '❌'} **{c['name']}** — {c['detail']}")
Path('/home/user/final_integrity_check_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'checks':checks}, indent=2))
