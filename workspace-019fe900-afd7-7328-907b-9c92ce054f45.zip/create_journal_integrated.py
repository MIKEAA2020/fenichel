from pathlib import Path
src=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
s=src.read_text()
# Replace title/abstract block
idx=s.find('---\n\n## 1. Introduction')
assert idx!=-1
new_start=r'''# Cohomological Inverses and Fractional Jet Spectra in Banach-Space Normally Hyperbolic Persistence

## Abstract

We develop a modular Banach-bundle framework for compact normally hyperbolic persistence in Banach-space dynamics. The framework decomposes the proof into linear cohomological inversion, HPS invariant-section matching, roughness of exponential dichotomies, Perron constructions for strong fibres, and regularity obstructions in induced jet cocycles. The main new analytic contribution is a fractional jet-spectrum theorem for the cohomological operator

\[
\mathcal A\zeta=\zeta\circ f-B\zeta:
\]

bounded invertibility on \(C^{k,\alpha}\) sections follows from a subunit spectral radius of the exact Green summand operators on Hölder jet bundles. We also prove a periodic triangular jet-resonance obstruction to \(C^k\)-surjectivity and a compact-return Fredholm refinement. These linear results are placed within the standard HPS/Banach invariant-section architecture for normally hyperbolic persistence; the full two-sided nonlinear graph transform is used as an external structural input. Supporting modules include Banach-bundle \(C^k\) inversion, Perron strong fibres, dichotomy roughness, parameter expansions, flow reduction, global stable sets, and a noncompact bounded-geometry linear theory. The broader parabolic, random, delay, quasilinear, noncompact nonlinear, and Banach-dimensional settings are presented as conditional extension architectures with their required additional hypotheses.

---

'''
s=new_start+s[idx+len('---\n\n'):]
# Replace intro opening
start=s.find('## 1. Introduction')
end=s.find('### Notation', start)
assert start!=-1 and end!=-1
notation=s[end:]
new_intro=r'''## 1. Introduction

Fenichel theory describes the persistence of normally hyperbolic invariant manifolds under small perturbations, together with the persistence of their stable and unstable laminations. In finite dimensions the theory is classical; see Fenichel [1] and Hirsch, Pugh, and Shub [2]. In Banach spaces the same geometric principle survives, but the proof must be reorganized. Local compactness of the ambient phase space is unavailable; invariant splittings and graph transforms must be controlled by completeness, uniform bundle estimates, Green operators, and Perron contractions rather than by compact neighbourhood arguments.

This paper presents that organization as a modular architecture. The compact persistence theorem itself uses the standard full two-sided HPS invariant-section theorem as a structural input. Around this nonlinear input we prove the linear and semi-linear analytic modules that make the Banach-bundle formulation explicit: cohomological Green inverses, fractional jet spectra, resonance obstructions, roughness of exponential dichotomies, strong-fibre Perron constructions, parameter expansions, flow reduction, and noncompact bounded-geometry linear inverses.

The main new analytic module is the fractional jet-spectrum theorem for the cohomological operator. Instead of measuring regularity only through integer one-step bunching inequalities, we define the exact stable and unstable Green summand operators on Hölder jet sections and use their exponential operator radii to obtain bounded inverse estimates on \(C^{k,\alpha}\). Periodic triangular jet resonances give converse obstructions to \(C^k\)-surjectivity of the linearized cohomological equation. This linear theory does not replace the nonlinear HPS theorem; rather, it sharpens the regularity mechanism that feeds into any HPS or Perron persistence argument in the corresponding Hölder category.

The claims in the paper are organized into four categories.

| Category | Role in the paper |
|---|---|
| Proved modules | Green inverses, fractional jet spectra, resonance obstructions, Perron fibres, roughness estimates, parameter expansions, flow reduction, global stable sets, and noncompact linear inverses. |
| Structural input | The full two-sided HPS/Banach invariant-section theorem used to pass from the linear inverse to the invariant graph. |
| Conditional consequences | Hölder nonlinear regularity and broader extension settings, conditional on the corresponding HPS, semigroup, random, bounded-geometry, or tame estimates. |
| Programmatic extensions | Parabolic, quasilinear, delay, random, noncompact nonlinear, and Banach-dimensional variants, stated with the additional hypotheses they require. |

Section 2 introduces the geometric and dynamical hypotheses. Section 3 proves the linear cohomological inverse theorem and points to the fractional refinement. Section 4 states the HPS invariant-section theorem as a structural input. Section 5 derives compact Fenichel persistence and the conditional nonlinear regularity spectrum. Section 6 constructs stable and unstable fibres. Section 7 treats flows. Section 8 collects the main extension architectures. Appendices A--K provide the supporting proofs and the fractional jet-spectrum theorem.

'''
s=s[:start]+new_intro+notation
# Replace theorem statement via slicing
start=s.find('### Theorem 3.1. Linear cohomological inverse')
end=s.find('---\n\n### Proof', start)
assert start!=-1 and end!=-1
new_theorem=r'''### Theorem 3.1. Linear cohomological inverse

Assume that \(B\) has an exponential dichotomy and satisfies the \(j\)-bunching inequalities for every \(0\le j\le r\). In the self-contained smooth-splitting version, assume moreover that the invariant splitting and the dichotomy projections have the required \(C^r\) regularity with uniformly bounded derivatives in the chosen bundle atlas. Then for every \(0\le k\le r\), the operator

\[
\mathcal A:\Gamma^k(E)\to\Gamma^k(f^*E)
\]

is an isomorphism. Its inverse

\[
\mathcal G:\Gamma^k(f^*E)\to\Gamma^k(E)
\]

is bounded:

\[
\|\mathcal Gq\|_{C^k}
\le
C_k\|q\|_{C^k}.
\]

If the dichotomy projections are only continuous, this differentiable-projection proof should be replaced by the HPS transported difference-quotient theorem. Continuity of the projections alone is not asserted to imply \(C^k\) regularity; the continuous-splitting statement is understood only under the corresponding HPS difference-quotient hypotheses.

If \(q\) depends on a parameter and the dichotomy and bunching estimates are uniform, then parameter regularity follows to the extent supplied by the corresponding mixed base/parameter estimates.

'''
s=s[:start]+new_theorem+s[end:]
# Conservative language replacements
s=s.replace('absolute linear regularity threshold','linear regularity threshold')
s=s.replace('ultimate regularity threshold','linear regularity threshold')
s=s.replace('Persistence at high regularities requires integer bunching inequalities.', 'High-regularity linear solvability is controlled by bunching or, more sharply, by the fractional jet spectrum.')
# write
out=Path('/home/user/journal_manuscript_integrated.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
