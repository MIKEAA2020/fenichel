from pathlib import Path
import re,json
final=Path('/home/user/journal_manuscript_integrated.md')
s=final.read_text()
low=s.lower()
checks=[]
def add(id,desc,patterns,required=True,note=''):
    found=[]; missing=[]
    for pat in patterns:
        if isinstance(pat,tuple) and pat[0]=='re':
            ok=re.search(pat[1],s,re.I|re.S) is not None; label=pat[1]
        else:
            ok=str(pat).lower() in low; label=str(pat)
        (found if ok else missing).append(label)
    checks.append({'id':id,'description':desc,'ok':not missing,'found':found,'missing':missing,'required':required,'note':note})
# Core architecture
add('title_abstract_architecture','Title/abstract integrated architecture and novelty framing',['Cohomological Inverses and Fractional Jet Spectra','modular Banach-bundle framework','main new analytic contribution','external structural input'])
add('claim_hierarchy','Claim hierarchy table retained',['Proved modules','Structural input','Conditional consequences','Programmatic extensions'])
add('notation','Notation section retained',['\\Gamma^k(E)','C_b^k(M,E)','f^*E','E^{cu}'])
# Geometry
add('geometry_setup','Banach tubular setup and transports',['split \\(C^{r+1}\\) tubular neighbourhood','P_{x\\leftarrow y}','\\Delta_y^x h','D_\\eta b_0(m,0)=0'])
add('dichotomy_bunching','Dichotomy and invariant bunching',['continuous invariant exponential dichotomy','coordinate-invariant formulation','adapted norm','uniformly equivalent'])
# Linear
add('green_inverse','C0 Green inverse and target projection',['q_n\\in E_{m_{n+1}}','q_n^\\sigma=P_{m_{n+1}}^\\sigma q_n','\\zeta_n^s','\\zeta_n^u'])
add('ck_caveat','Ck smooth splitting vs continuous projection caveat',['smooth-splitting version','Continuity of the projections alone is not asserted','transported difference-quotient'])
add('jet_equations','First and higher jet equations',['induced first-jet cocycle','principal homogeneous \\(k\\)-jet equation','\\operatorname{Sym}^k'])
# HPS
add('hps_import','HPS imported structural input and component warning',['full two-sided HPS Hadamard graph transform','not the separate stable-forward/unstable-backward','component equations alone do not imply invariance','Appendix J'])
add('admissible_graph','Admissible class and graph metric',['\\mathcal B_{\\rho,L}','maximal transported vertical separation','e^{-\\mathrm{gap}\\,N}','triangular wave'])
add('remainder_estimates','Remainder estimates incl base derivative',['D_m r_\\varepsilon','D_\\eta r_\\varepsilon','D_\\eta b_\\varepsilon','base-variation term'])
# Persistence
add('persistence','Main persistence theorem pieces',['Theorem 5.1','f_\\varepsilon','Local diffeomorphism close to the identity','weakened rates','E_\\varepsilon^s'])
add('parameter_expansion','Parameter expansion and Appendix F',['h_0=0','Appendix F','parameter-expansion recursion','\\mathcal A\\eta_n'])
# Fibres flow
add('strong_fibres','Strong fibres Perron',['Appendix B','half-line Perron','The center component is not frozen','\\ell_\\gamma^+','tangent to \\(E^s'])
add('global_stable','Global stable Appendix H',['Appendix H','W_N^s(M):=F^{-N}','\\pi^s(y):=F^{-N}','immersed lamination'])
add('flow','Flow reduction Appendix G',['Appendix G','N_t:=\\Phi_t^\\varepsilon','full-flow invariance','time-map reduction'])
# Roughness
add('roughness','Roughness appendices C/E',['Appendix C','Appendix E','Close-base roughness','transported block estimates','\\mathfrak T'])
# Fractional K
add('fractional','Fractional jet spectrum Appendix K',['Appendix K','Theorem K.1','\\widehat\\rho_{k,\\alpha}','operator norms on \\(C^\\alpha\\) include all Hölder variation','k+\\alpha\\le r+\\beta'])
add('resonance','Resonance obstruction and Fredholm',['Proposition K.2','full triangular jet return map','Theorem K.3','Compact jet-return Fredholm alternative','Without compactness'])
add('examples','Model examples retained',['Hyperbolic toral base','Isometric base dynamics','\\Lambda=\\frac{3+\\sqrt5}{2}','two-cycle'])
# Extensions
add('extensions','Extension architecture retained',['parabolic semiflows','uniform resolvent estimate','backward well-posed unstable subspace','noncompact finite-dimensional','manifolds with boundary','random and nonautonomous','quasilinear','Delay equations'])
add('noncompact_linear','Noncompact Appendix I',['Appendix I','Uniform cohomological inverses on noncompact bases','bounded geometry','C_b^0'])
add('appendices_all','Appendices A-K present',['Appendix A','Appendix B','Appendix C','Appendix D','Appendix E','Appendix F','Appendix G','Appendix H','Appendix I','Appendix J','Appendix K'])
# References
add('references','References include major sources',['Fenichel','Hirsch','Chow','Bates','Henry','Palmer','Ruelle','Hamilton','Zeng'])
# Forbidden or intentionally absent overclaims
forbidden=['definitive','arbitrary infinite','maps center cones strictly','follows by the same argument','conclusion we interpret','ultimate','persistence fails','complete resolution','sacred cows','geometric rupture']
found_forbidden=[x for x in forbidden if x in low]
checks.append({'id':'forbidden_overclaims','description':'Forbidden overclaims absent','ok':not found_forbidden,'found':found_forbidden,'missing':[],'required':True,'note':'absence check'})
# verification reports exist
reports=['deep_fractional_verification_report.md','fractional_appendix_k_integration_verification.md','compact_fredholm_resonance_verification_report.md','remaining_witness_counterexample_report.md','witness_level_verification_report.md']
present=[r for r in reports if Path('/home/user/'+r).exists()]
checks.append({'id':'verification_reports','description':'Verification reports retained in workspace','ok':len(present)==len(reports),'found':present,'missing':[r for r in reports if r not in present],'required':False,'note':''})
missing_required=[c for c in checks if c['required'] and not c['ok']]
# Source heading heuristic from important files
sources=['/home/user/final_manuscript_external_hps_closed.md','/home/user/fractional_jet_spectrum_research_note.md','/home/user/final_manuscript_noncompact_linear_gap_closed.md','/home/user/uploads/audit of pasive voice.txt','/home/user/uploads/unified_manuscript.md']
headings=[]
for sp in sources:
    p=Path(sp)
    if p.exists():
        for line in p.read_text(errors='ignore').splitlines():
            if re.match(r'#{1,4}\s+',line):
                h=re.sub(r'^#+\s*','',line).strip()
                if h and len(h)<140: headings.append((p.name,h))
stop=set('the a an and or of to in for with by from on under into as is are was were be been this that we now step proof theorem correct final next appendix'.split())
notrep=[]; rep=[]
for fname,h in headings:
    if re.search(r'what has been repaired|final honest|next step|summary of step|completion|recommended insertion|content that should not|active-voice',h,re.I):
        continue
    words=[w.lower() for w in re.findall(r'[A-Za-z][A-Za-z0-9_\-]+',h) if w.lower() not in stop]
    ok=h.lower() in low or any(len(w)>6 and w in low for w in words[:5])
    (rep if ok else notrep).append((fname,h,words[:5]))
report=[]
report.append('# Deep Content-Loss Scan for Integrated Manuscript')
report.append('')
report.append(f'File scanned: `{final}`')
report.append('')
report.append(f'Overall required-content status: **{"PASS" if not missing_required else "POTENTIAL LOSS"}**')
report.append('')
report.append(f'- Required checks: {len([c for c in checks if c["required"]])}')
report.append(f'- Missing/suspect required checks: {len(missing_required)}')
report.append('')
report.append('## Checklist')
for c in checks:
    icon='✅' if c['ok'] else ('⚠️' if not c['required'] else '❌')
    report.append(f"- {icon} **{c['id']}** — {c['description']}")
    if not c['ok']:
        report.append(f"  - Missing: `{c['missing']}`")
        report.append(f"  - Found: `{c['found']}`")
    if c['note']:
        report.append(f"  - Note: {c['note']}")
report.append('')
report.append('## Source-heading heuristic')
report.append(f'- Represented headings/topics: {len(rep)}')
report.append(f'- Not directly represented: {len(notrep)}')
if notrep:
    report.append('Likely omitted headings are listed below; many are duplicate/meta headings or intentionally excluded development material:')
    for fname,h,words in notrep[:100]: report.append(f'- `{fname}`: {h}')
report.append('')
report.append('## Conclusion')
if missing_required:
    report.append('Potential content loss found. Review the failed checklist items.')
else:
    report.append('No required substantive content loss was detected. The integrated manuscript preserves the surviving architecture, proofs, fractional-spectrum novelty, HPS import caveat, extension architecture, and verification trail.')
Path('/home/user/deep_integrated_content_loss_report.md').write_text('\n'.join(report))
Path('/home/user/deep_integrated_content_loss.json').write_text(json.dumps({'missing_required':missing_required,'checks':checks,'not_represented':notrep},indent=2))
print(json.dumps({'overall_ok':not missing_required,'required_checks':len([c for c in checks if c['required']]),'missing_required':len(missing_required),'not_represented_headings':len(notrep)},indent=2))
