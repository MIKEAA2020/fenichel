from pathlib import Path
main=Path('/home/user/final_manuscript_external_hps_closed.md')
s=main.read_text()
frac=Path('/home/user/fractional_jet_spectrum_research_note.md').read_text()

# Add main cross references.
s=s.replace('''One often obtains this one-step form after passing to an iterate and introducing an adapted norm. If adapted norms or iterates are used, one must verify that the adapted norms are uniformly equivalent to the original norms and that the perturbation remains small in the adapted topology. Otherwise the quantitative \\(C^r\\) estimates may not transfer back to the original topology.''',
'''One often obtains this one-step form after passing to an iterate and introducing an adapted norm. If adapted norms or iterates are used, one must verify that the adapted norms are uniformly equivalent to the original norms and that the perturbation remains small in the adapted topology. Otherwise the quantitative \\(C^r\\) estimates may not transfer back to the original topology.

The integer bunching inequalities are convenient sufficient conditions. Appendix K gives a sharper linear formulation in Hölder spaces: the boundedness of the Green inverse on \\(C^{k,\\alpha}\\) is controlled by the exponential growth radius of the exact Green summand operators on Hölder \\(k\\)-jet sections. This fractional jet spectrum includes Hölder distortion of the cocycle, projections, derivative iterates, and bundle transports.''')

s=s.replace('''Appendix A gives a self-contained proof of the \\(C^k\\) cohomological inverse theorem under the clean hypothesis that the splitting and projections have the required \\(C^r\\) regularity. The continuous-projection version used in the HPS setting should be read in the transported difference-quotient sense described above.''',
'''Appendix A gives a self-contained proof of the \\(C^k\\) cohomological inverse theorem under the clean hypothesis that the splitting and projections have the required \\(C^r\\) regularity. The continuous-projection version used in the HPS setting should be read in the transported difference-quotient sense described above. Appendix K sharpens the linear theory in the \\(C^{k,\\alpha}\\) scale by replacing integer bunching with a fractional jet-spectrum condition and by recording periodic jet-resonance obstructions.''')

# Insert conditional nonlinear corollary after Theorem 5.1 proof remark, before Section 6.
marker='''---

## 6. Stable and unstable fibres'''
corollary=r'''
---

### Corollary 5.3. Conditional nonlinear regularity spectrum

Let \(s_*\) be the linear regularity spectrum defined in Appendix K. Suppose that the imported HPS invariant-section theorem is available in the Hölder class \(C^{k,\alpha}\), and that the nonlinear maps \(F_\varepsilon\) have the regularity and tame estimates required by that Hölder invariant-section theorem. Then the invariant section \(h_\varepsilon\) has regularity \(C^{k,\alpha}\) whenever

\[
k+
\alpha<s_*
\]

and the coefficients have the required regularity.

If an integer order \(k\) is obstructed by a periodic jet resonance in the sense of Appendix K, then the linearized cohomological operator is not onto on \(C^k\). In that case one cannot expect a uniform \(C^k\) implicit-function-theorem proof of the invariance equation, although special nonlinear perturbations may still admit special solutions.

'''
corollary=corollary.replace('k+\n\\alpha','k+\\alpha')
assert marker in s
s=s.replace(marker, corollary+marker)

# Update summary appendices sentence.
s=s.replace('''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, Appendix H proves the globalization of local stable fibres under explicit domain assumptions, Appendix I proves the uniform noncompact cohomological inverse theorem, and Appendix J records the external two-sided HPS input and the reduction to the tubular formulation.''',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, Appendix H proves the globalization of local stable fibres under explicit domain assumptions, Appendix I proves the uniform noncompact cohomological inverse theorem, Appendix J records the external two-sided HPS input and the reduction to the tubular formulation, and Appendix K gives the fractional jet-spectrum regularity theorem and periodic resonance obstruction.''')

# Build Appendix K from fractional note sections 2-10, omit standalone references.
start=frac.find('## 2. Hölder Banach-bundle setting')
end=frac.find('---\n\n## References')
assert start!=-1 and end!=-1
body=frac[start:end]
# Demote/rename headings.
body=body.replace('## 2. Hölder Banach-bundle setting','### K.1. Hölder Banach-bundle setting')
body=body.replace('## 3. Hölder Green summand operators','### K.2. Hölder Green summand operators')
body=body.replace('## 4. Fractional cohomological inverse theorem','### K.3. Fractional cohomological inverse theorem')
body=body.replace('### Theorem 4.1. Hölder jet-spectrum inverse','**Theorem K.1. Hölder jet-spectrum inverse.**')
body=body.replace('## 5. Proof of Theorem 4.1','### K.4. Proof of Theorem K.1')
body=body.replace('### 5.1. Zeroth-order inverse','#### K.4.1. Zeroth-order inverse')
body=body.replace('### 5.2. Hölder Green lemma','#### K.4.2. Hölder Green lemma')
body=body.replace('### 5.3. Application to the \\(k\\)-jet equation','#### K.4.3. Application to the \\(k\\)-jet equation')
body=body.replace('### 5.4. Avoiding circular differentiability','#### K.4.4. Avoiding circular differentiability')
body=body.replace('## 6. Relation with one-step Hölder bunching','### K.5. Relation with one-step Hölder bunching')
body=body.replace('## 7. Periodic jet-resonance obstruction','### K.6. Periodic jet-resonance obstruction')
body=body.replace('### Proposition 7.1. Periodic jet-resonance obstruction','**Proposition K.2. Periodic jet-resonance obstruction.**')
body=body.replace('## 8. Witness: first-jet resonance on a two-cycle','### K.7. Witness: first-jet resonance on a two-cycle')
body=body.replace('## 9. Regularity spectrum','### K.8. Regularity spectrum')
body=body.replace('## 10. Model examples','### K.9. Model examples')
body=body.replace('### 10.1. Hyperbolic toral base with scalar attracting normal direction','#### K.9.1. Hyperbolic toral base with scalar attracting normal direction')
body=body.replace('### 10.2. Isometric base dynamics','#### K.9.2. Isometric base dynamics')
appendix_k='''## Appendix K. Fractional jet spectra for Banach-bundle cohomological equations

This appendix sharpens the linear cohomological inverse theorem in the Hölder scale. The result is independent of the nonlinear HPS matching mechanism: it concerns only the Green inverse for \\(\\mathcal A\\). The integer bunching assumptions in the main text are sufficient criteria; the intrinsic condition is the spectral radius of the exact Green summand operators acting on Hölder jet sections.

'''+body+'\n---\n\n'

refmarker='---\n\n## References'
assert refmarker in s
s=s.replace(refmarker, '---\n\n'+appendix_k+'## References')

out=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
