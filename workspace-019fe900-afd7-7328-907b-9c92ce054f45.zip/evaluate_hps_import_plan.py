from pathlib import Path
p=Path('/home/user/final_manuscript_noncompact_linear_gap_closed.md')
s=p.read_text()

# Add a cautious clarification after structural HPS paragraph.
old='''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. A fully self-contained proof must carry out the two-sided Hadamard matching construction, the transported \\(C^0\\) graph contraction, the admissible-graph preservation estimates, and the jet or difference-quotient extension in Banach fibres. The discussion below records the required mechanism and hypotheses; a version with continuous splittings should be read in the HPS transported difference-quotient sense. Appendix D proves the one-sided normally attracting Banach-fibre case completely; the two-sided case requires the additional stable/unstable matching mechanism described here.'''
new='''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. A fully self-contained proof must carry out the two-sided Hadamard matching construction, the transported \\(C^0\\) graph contraction, the admissible-graph preservation estimates, and the jet or difference-quotient extension in Banach fibres. The discussion below records the required mechanism and hypotheses; a version with continuous splittings should be read in the HPS transported difference-quotient sense. Appendix D proves the one-sided normally attracting Banach-fibre case completely; the two-sided case requires the additional stable/unstable matching mechanism described here.

The graph transform used in Theorem 4.1 is the full two-sided HPS Hadamard graph transform. It is not the separate stable-forward/unstable-backward component transform. The component equations alone do not imply invariance; the full HPS admissible matching construction is required. In finite-dimensional fibres this compatibility of the forward and backward base correspondences is part of the HPS graph-transform theorem. In Banach fibres the estimates needed for the same construction are Banach contraction estimates in local bundle charts, with transported differences used to patch the chartwise constructions.'''
assert old in s
s=s.replace(old,new)

# Add a concise remark after Hadamard transform explanation.
old='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched in one time direction and unstable components in the opposite time direction; the center coordinate labels the transformed graph. The admissible-graph preservation estimate comes from these stable/unstable matching equations, not from forward invariance of center cones.'''
new='''The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense. In the normally attracting case, the transform is the forward image of a graph, reparametrized over the base. With both stable and unstable directions present, stable components are matched in one time direction and unstable components in the opposite time direction; the center coordinate labels the transformed graph. The admissible-graph preservation estimate comes from the full simultaneous HPS matching construction, not from forward invariance of center cones.

A naive transform that separately matches only the stable component forward and the unstable component backward is insufficient. Affine examples can satisfy those two separate component equations while failing the full graph equation, because the forward and backward base correspondences need not be inverse to one another. The HPS transform avoids this defect by imposing the simultaneous admissible matching whose fixed points are precisely locally invariant graphs.'''
assert old in s
s=s.replace(old,new)

out=Path('/home/user/final_manuscript_hps_import_verified.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))

# evaluation report
report='''# Evaluation of Proposed HPS Import/Verification Plan

## Verdict

The plan is directionally correct: the failed componentwise matching lemma should not be repaired, and the manuscript should rely on the genuine two-sided HPS Hadamard graph-transform theorem for the full normally hyperbolic case.

However, the proposed “Banach-bundle verification lemma” should not be inserted as a proved theorem in the strong form stated. It still compresses the core HPS matching argument into the sentence that compatibility is part of the HPS construction. That is acceptable as an explanation of the imported theorem, but not as a new self-contained proof.

## What was implemented

I implemented the safe parts:

1. The manuscript now states explicitly that the graph transform in Theorem 4.1 is the full two-sided HPS Hadamard graph transform, not the separate stable-forward/unstable-backward component transform.
2. It states that component equations alone do not imply invariance.
3. It explains that finite-dimensional compatibility of the forward and backward base correspondences is part of the HPS graph-transform theorem.
4. It explains that in Banach fibres the required estimates are Banach contraction estimates in local bundle charts, patched by transported differences.
5. It records that affine examples can satisfy the separate component equations while failing the full graph equation.

## What was not implemented

I did not insert Theorem R.1 and Lemma R.2 as a new proof closing the full two-sided Banach-bundle theorem. That would overstate what has been proved. The manuscript remains honest: Theorem 4.1 is the structural HPS input.

## Current status

The full two-sided Banach-bundle HPS theorem is handled by the HPS structural input and the precise explanatory text now added. Surrounding special and linear cases are proved in Appendices A--I.
'''
Path('/home/user/hps_import_plan_evaluation_report.md').write_text(report)
