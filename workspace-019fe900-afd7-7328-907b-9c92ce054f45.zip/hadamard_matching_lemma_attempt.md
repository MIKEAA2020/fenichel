# Rigorous Attempt at the Two-Sided Hadamard Matching Lemma

## Verdict

I attempted to prove the missing two-sided Hadamard matching lemma. The attempt did **not** produce a complete proof. More importantly, it exposed a precise danger: a natural “separate stable-forward / unstable-backward component transform” can have fixed points that are **not invariant graphs** if one does not use the full HPS admissible matching construction. Thus the lemma cannot be treated as a formal consequence of the two separate component equations.

The remaining lemma must be proved using the genuine HPS matching geometry, or cited. The manuscript should not claim a self-contained proof of the full two-sided Banach-bundle HPS theorem yet.

---

## 1. The desired matching lemma

For a graph \(h=h^s+h^u\), define the forward and backward base maps

\[
\beta_h^+(m)=b_+(m,h(m)),
\qquad
\beta_h^-(m)=b_-(m,h(m)),
\]

where \(F^{-1}(m,\eta)=(b_-(m,\eta),g_-^s(m,\eta),g_-^u(m,\eta))\).

The desired lemma is:

> If \(h\) is a fixed point of the two-sided Hadamard transform in the admissible class, then
> \[
> \beta_h^-\circ\beta_h^+=\operatorname{id}_M,
> \qquad
> \beta_h^+\circ\beta_h^-=\operatorname{id}_M,
> \]
> and hence
> \[
> F(m,h(m))=(\beta_h^+(m),h(\beta_h^+(m))).
> \]

This is the missing HPS matching step.

---

## 2. Why the separate component equations are not enough

A tempting construction is to define a component transform by matching the stable component forward and the unstable component backward. Formally this gives:

\[
g_+^s(m,h(m))=h^s(\beta_h^+(m))
\]

and

\[
g_-^u(y,h(y))=h^u(\beta_h^-(y)).
\]

The first equation matches the stable component of the forward image of the graph. The second matches the unstable component of the backward image of the graph.

However, these two equations alone do not imply

\[
\beta_h^-=(\beta_h^+)^{-1}.
\]

The following exact affine witness shows this.

---

## 3. Exact affine witness

Consider the finite-dimensional map

\[
F(x,s,u)
=
\left(
 x+\varepsilon(s+u),
 \lambda s+a x,
 \mu u+b x
\right),
\]

with

\[
\lambda=\frac12,
\qquad
\mu=2,
\qquad
a=\frac1{10},
\qquad
b=\frac15,
\qquad
\varepsilon=\frac1{10}.
\]

Look for a linear graph

\[
h(x)=(px,qx).
\]

The forward stable matching equation is

\[
p\bigl(1+\varepsilon(p+q)\bigr)=\lambda p+a.
\tag{1}
\]

The backward unstable matching equation is

\[
\frac{1-\varepsilon(p/\lambda+q/\mu)}
{1-\varepsilon(a/\lambda+b/\mu)}
=
\frac{q}{\mu q+b}.
\tag{2}
\]

Take

\[
p=5,
\qquad
q=-\frac{49}{5}.
\]

Then

\[
1+\varepsilon(p+q)=\frac{13}{25}.
\]

Equation (1) holds because

\[
p\frac{13}{25}=\frac{13}{5}
=
\frac12p+a.
\]

Equation (2) also holds because

\[
\frac{1-\varepsilon(p/\lambda+q/\mu)}
{1-\varepsilon(a/\lambda+b/\mu)}
=
\frac{49}{97}
=
\frac{q}{\mu q+b}.
\]

Thus this graph satisfies the separate stable-forward and unstable-backward component matching equations.

But it is not invariant. The unstable component of the true forward graph equation would require

\[
q\bigl(1+\varepsilon(p+q)\bigr)=\mu q+b.
\]

The defect is

\[
q\frac{13}{25}-(\mu q+b)
=
\frac{1788}{125}
\ne0.
\]

Therefore the separate component matching equations can have non-invariant fixed points.

---

## 4. Interpretation of the witness

This witness does not contradict HPS, because the graph has large slope:

\[
|p|+|q|=5+\frac{49}{5}=\frac{74}{5}.
\]

It is not in a small admissible Lipschitz class. The small admissible fixed point for the same example is

\[
p=\frac15,
\qquad
q=-\frac15,
\]

and that one is invariant.

The witness nevertheless proves an important logical point:

> The two-sided matching lemma is not a purely algebraic consequence of separately matching stable and unstable components. The small admissible HPS geometry and the uniqueness of the correct matched intersection are essential.

Thus any proof must use the full HPS matching construction, not merely the two scalar component equations.

---

## 5. What a valid proof must still establish

A genuine Banach-bundle proof must prove the following statement inside the small admissible class:

1. The stable-forward and unstable-backward matching problems define one and the same base correspondence.
2. Equivalently,
   \[
   \beta_h^-\circ\beta_h^+=\operatorname{id}_M.
   \]
3. This compatibility follows from uniqueness of the intersection of the appropriate local stable and unstable plaques, not from separate component contraction alone.
4. The proof must be stable under Banach-fibre chart changes and under transported differences.
5. The jet-extension version must preserve this matching compatibility at the level of difference quotients or jets.

This is the finite-dimensional HPS matching lemma transplanted to Banach fibres.

---

## 6. Conditional statement that remains valid

The following conditional theorem is valid:

> If the two-sided Hadamard component transform is a contraction in the admissible class and if the HPS matching lemma holds in that class, then the fixed point is an invariant graph. Under bunching, the jet-extension argument gives \(C^r\) regularity.

But the matching lemma itself remains the nontrivial input.

---

## Final conclusion

The rigorous attempt sharpened the remaining gap rather than closing it. The full two-sided Banach-bundle HPS theorem still depends on the Hadamard matching lemma. The manuscript should continue to treat Theorem 4.1 as a structural HPS input unless a full proof of that matching lemma is supplied.
