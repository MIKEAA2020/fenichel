from pathlib import Path
import re, json
p=Path('/home/user/journal_manuscript_integrated_v2.md')
s=p.read_text()
checks=[]
def add(name, ok, detail): checks.append({'name':name,'ok':bool(ok),'detail':detail})
# structure
headings=re.findall(r'^(##+\s+.+)$',s,re.M)
main=[h for h in headings if h.startswith('## ') and not h.startswith('###')]
expected=['## 1. Introduction','## 2. Geometric and dynamical framework','## 3. The linear cohomological inverse theorem','## 4. The invariant-section theorem','## 5. Fenichel persistence theorem','## 6. Stable and unstable fibres','## 7. Flows','## 8. Extensions','## 9. Open problems and spectral directions','## 10. Summary']
for e in expected:
    add('has_'+e[:20], e in main, e)
# appendices A-K
for letter in 'ABCDEFGHIJK':
    add(f'appendix_{letter}', f'## Appendix {letter}' in s, f'Appendix {letter}')
# roadmap updated
add('roadmap_mentions_open_and_summary','Section 9 records open problems' in s and 'Section 10 summarizes' in s,'roadmap mentions Section 9 and 10')
# overclaim absence
for pat in ['definitive','arbitrary infinite','complete resolution','ultimate threshold','persistence fails','sacred cows','geometric rupture','operator-algebraic resolution']:
    add('absent_'+pat.replace(' ','_'), pat not in s.lower(), pat)
# conceptual anchors presence
for pat in ['Proved modules','Structural input','Conditional consequences','Programmatic extensions','full two-sided HPS','fractional jet-spectrum theorem','Open problems and spectral directions','does not require reflexivity','Mather, Sacker--Sell']:
    add('present_'+pat[:24].replace(' ','_'), pat in s, pat)
# math balance
add('display_math_balanced',s.count('\\[')==s.count('\\]'),f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_math_balanced',s.count('\\(')==s.count('\\)'),f"{s.count('\\(')} vs {s.count('\\)')}")
add('env_balanced',re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s),str((re.findall(r'\\begin\{([^}]+)\}',s),re.findall(r'\\end\{([^}]+)\}',s))))
# possible flow issues: appendices after summary okay; open problem before summary okay
all_ok=all(c['ok'] for c in checks)
lines=['# Conceptual Clarity and Flow Scan','',f'File scanned: `{p}`','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
lines.append('## Main section flow')
for h in main:
    lines.append(f'- {h}')
lines.append('')
lines.append('## Checks')
for c in checks:
    lines.append(f"- {'✅' if c['ok'] else '❌'} **{c['name']}** — {c['detail']}")
lines.append('')
lines.append('## Qualitative assessment')
lines.append('')
lines.append('The manuscript now has a coherent top-down progression: motivation and claim hierarchy; geometric setup; linear inverse; structural HPS input; persistence; fibres; flows; extension architecture; open problems; summary; and technical appendices. The open-problems section restores the ambitious spectral and transverse-regularity agenda without promoting it to theorem status. The non-reflexive Perron remark clarifies the compactness-free nature of the fibre construction while preserving the warning that transverse regularity is separate.')
Path('/home/user/conceptual_flow_scan_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'main_sections':main,'failed':[c for c in checks if not c['ok']]},indent=2))
