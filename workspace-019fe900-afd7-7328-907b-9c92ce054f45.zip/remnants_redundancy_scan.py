from pathlib import Path
import json
p=Path('/home/user/journal_manuscript_integrated_v2.md')
s=p.read_text()
items=[]
def add(name,severity,status,evidence,recommendation):
    items.append({'name':name,'severity':severity,'status':status,'evidence':evidence,'recommendation':recommendation})
add('Duplicate HPS-import explanation','medium','redundant','Section 4 explains Theorem 4.1 as structural HPS input after the theorem, then later repeats that it is the imported HPS mechanism.','Delete or compress the later “Thus Theorem 4.1...” paragraph; the first paragraph plus Appendix J already carry the point.')
add('Residual fixed-point equation may imply direct contraction','medium','needs qualification','Section 4 states “Thus the fixed-point problem is h=-G N(h)”. This is algebraically correct but can suggest the wrong contraction mechanism.','Change to “The residual equation can be written formally as...” and reiterate that the contraction is the HPS graph transform, not direct Lipschitz contraction of -G N.')
add('Appendix cross-reference density','low','style redundancy','Main text mentions appendices A–K repeatedly; summary has a long one-sentence appendix list.','Keep useful references, but split the summary appendix list into bullets or shorten it.')
add('Section 3 and Appendix A overlap','low','intentional redundancy','Section 3 proves much of the cohomological inverse and Appendix A repeats the smooth-splitting proof.','Acceptable. For streamlining, Section 3 could prove C0 and outline Ck, with full proof in Appendix A.')
add('Extension and open-problem overlap','low','productive redundancy','Section 8 states conditional extensions; Section 9 repeats future directions.','Acceptable. Add a transition from Section 8 to Section 9 if desired.')
forbidden=['Your assessment','Your diagnosis','What has been repaired','Final honest','invalid Lipschitz','false Lipschitz','fatal point','passive voice','audit','wtf','sacred cows','geometric rupture','definitive','ultimate threshold','maps center cones strictly','follows by the same argument','conclusion we interpret']
found=[f for f in forbidden if f in s]
add('Forbidden/remnant meta phrases','high' if found else 'none','pass' if not found else 'problem',str(found),'No action needed.' if not found else 'Remove listed remnants.')
broken=[pat for pat in ['\\delta_\n','h_\n','f_\n','g_\n','b_\n','D_\n','_\n\\gamma','-\n\\eta','p+\n\\xi','\\widehat\\rho_{k,\n'] if pat in s]
add('Broken math line artifacts','high' if broken else 'none','pass' if not broken else 'problem',str(broken),'No action needed.' if not broken else 'Normalize broken math tokens.')
add('External HPS citation lacks theorem number','medium','publication-prep gap','Appendix J cites HPS/Bates–Lu/Bates–Lu–Zeng structurally but does not identify exact theorem numbers.','Before submission, verify bibliographic details and add theorem/proposition numbers if available. Do not invent them.')
add('Title/content alignment','low','good','Title emphasizes cohomological inverses and fractional jet spectra, matching the real novelty.','No action needed.')
report=['# Remnants and Redundancy Scan','',f'File scanned: `{p}`','','## Executive summary','','No severe mathematical remnants were found. The manuscript is clean of meta-audit language and previous false claims. Main remaining issues are editorial redundancy and one wording point around the residual fixed-point equation.','','## Findings']
for it in items:
    icon={'high':'❌','medium':'⚠️','low':'ℹ️','none':'✅'}.get(it['severity'],'ℹ️')
    report += [f"### {icon} {it['name']}",f"- Severity: **{it['severity']}**",f"- Status: {it['status']}",f"- Evidence: {it['evidence']}",f"- Recommendation: {it['recommendation']}",'']
report += ['## Minimal cleanup recommended','','1. Remove or compress the duplicate paragraph beginning “Thus Theorem 4.1 is the imported HPS mechanism...”.','2. Change “Thus the fixed-point problem is” to “The residual equation can be written formally as”.','3. Optionally convert the long appendix list in the summary into bullets or shorten it.','4. Add exact theorem numbers for the imported HPS/Banach theorem before submission, if a precise source match is available.']
Path('/home/user/remnants_redundancy_scan_report.md').write_text('\n'.join(report))
Path('/home/user/remnants_redundancy_scan.json').write_text(json.dumps(items,indent=2))
print(json.dumps({'items':len(items),'found_forbidden':found,'broken':broken},indent=2))
