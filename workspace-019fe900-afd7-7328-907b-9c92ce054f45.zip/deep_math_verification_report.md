# Deep Computational Verification Report

Manuscript checked: `/home/user/final_manuscript_full_revised.md`

These checks do not prove the Banach-space theorems. They test the displayed formulae in finite-dimensional and discretized models, with emphasis on signs, fibre indexing, dichotomy Green formulae, induced jet equations, Perron convolution estimates, and representative nonlinear invariant graphs.

Overall status: **PASS**

- ✅ **display_math_delimiters_balanced** — \[=243, \]=243
- ✅ **inline_math_delimiters_balanced** — \(=446, \)=446
- ✅ **latex_environments_balanced** — begin={'pmatrix': 1, 'aligned': 2}, end={'pmatrix': 1, 'aligned': 2}
- ✅ **no_chat_or_repair_meta_language** — found=[]
- ✅ **no_common_mojibake** — found=[]
- ✅ **variable_bundle_periodic_linear_solve_residual** — max residual=4.441e-16, N=401, shift=73
- ✅ **periodic_model_no_homogeneous_unit_multiplier** — monodromy eigenvalues=[0.00000000e+000 1.53242788e+138], min |lambda-1|=1
- ✅ **variable_bundle_green_formula_matches_exact_solution** — max correct Green-vs-solve error=6.661e-16
- ✅ **target_fibre_projection_indexing_is_material** — wrong source-projection max error=3.808e-01, correct max error=6.661e-16
- ✅ **first_jet_equation_finite_difference_consistency** — max finite-difference jet residual=3.760e-04; grid h=1.567e-02
- ✅ **nonlinear_invariant_graph_toy_residual** — max nonlinear graph residual=5.620e-18, ||h||_inf=2.502e-02, eps=0.018
- ✅ **nonlinear_invariant_graph_smallness_O_epsilon** — ||h||_inf/eps=1.39
- ✅ **nonlinear_fixed_operator_empirical_contraction_small_ball** — max sampled Lipschitz ratio=2.363e-03 on ||h||~1e-2 ball
- ✅ **stable_fibre_weighted_convolutions_uniformly_bounded** — stable sup=2.34, cu sup=1.84, beta<gamma<alpha is True
- ✅ **parabolic_smoothing_convolution_gamma_bound** — sample sup=1.783, gamma-bound=1.783, gamma<alpha=True, rho<1=True
- ✅ **hps_schematic_contraction_and_radius_constants** — q=0.047647, Cdelta+q*rho=0.0052117, rho=0.08

## Deeper findings

1. A variable-splitting finite-dimensional bundle model confirms the corrected Green formula with projections at the target fibre of the forcing term. The same test deliberately using source-fibre projections fails by many orders of magnitude, showing that the manuscript’s target-fibre indexing is not cosmetic.
2. The formal first-jet equation was checked by finite differences in a smooth periodic model. The residual is small at the expected discretization scale.
3. A nonlinear normally hyperbolic graph equation with stable and unstable normal directions was solved by the Green inverse fixed-point formulation. The residual is at roundoff level and the invariant section scales like O(epsilon).
4. The stable-fibre Perron estimates and parabolic smoothing convolution estimates were checked numerically against the rate inequalities stated in the manuscript.
5. Text-level checks found balanced math delimiters/environments and no common chat-history or mojibake artifacts.