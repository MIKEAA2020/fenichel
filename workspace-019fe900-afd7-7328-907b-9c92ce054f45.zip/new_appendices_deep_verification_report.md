# Deep Verification of New Appendices D–G

This report computationally stress-tests the newly added normally attracting graph transform, close-base roughness graph transform, parameter expansion recursion, and flow time-map reduction.

Overall: **PASS**

- ✅ **appendix_D_attracting_graph_equation_residual** — max residual=6.587e-18, fixed point iterations=6, ||h||inf=2.067e-02
- ✅ **appendix_D_attracting_empirical_contraction** — max sampled ratio=9.747e-03, median=4.501e-03
- ✅ **appendix_D_attracting_solution_O_epsilon** — ||h_eps||/eps values=[np.float64(1.3790611086184092), np.float64(1.3789079037904508), np.float64(1.3786014226100949), np.float64(1.3779881711874609), np.float64(1.3767604881130568)]
- ✅ **appendix_F_parameter_expansion_second_order** — (eps, error, error/eps^3)=[(0.002, np.float64(3.5370978048636717e-10), np.float64(0.04421372256079589)), (0.004, np.float64(2.8288965018153506e-09), np.float64(0.04420150784086485)), (0.008, np.float64(2.2618671006481572e-08), np.float64(0.044177091809534316)), (0.016, np.float64(1.807495711610152e-07), np.float64(0.04412831327173222))]
- ✅ **appendix_F_first_derivative_finite_difference** — last eps=0.00025, max |central diff - h1|=2.764e-09
- ✅ **appendix_F_symbolic_coefficient_recursion** — residual through order eps^2 = -a*e**2*mu*q**2/(-a**3 + 3*a**2 - 3*a + 1) - a*e*q/(1 - a) + e**2*mu*q**2/(-a**3 + 3*a**2 - 3*a + 1) - e**2*mu*q**2/(a**2 - 2*a + 1) - e*q + e*q/(1 - a)
- ✅ **appendix_E_close_base_stable_graph_invariance_random** — 100 trials: max invariance residual=5.349e-15, max ||L||=3.039e-02, max stable rate=0.561
- ✅ **appendix_E_contraction_factor_witness** — beta(alpha+delta R)/(1-beta R delta)=0.238204
- ✅ **appendix_E_bad_constants_fail_domination** — bad factor=1.192341 > 1
- ✅ **appendix_G_full_flow_invariant_positive_witness** — Flow Phi_t(x,y)=(x+t,e^{-t}y) keeps M={y=0} invariant for all t; N_t=M in sampled representation
- ✅ **appendix_G_time_T_only_invariance_counterexample** — circle flow: Phi_T^0(0.0)=0.0 for T=2pi, but Phi_1.5707963267948966^0(0.0)=1.571 not in M
- ✅ **roughness_graph_size_linear_in_delta** — ||L||/delta values=[np.float64(0.5204108178888786), np.float64(0.5144344240147151), np.float64(0.4879061410559357), np.float64(0.5008652004364484)]

## Interpretation

- Appendix D is tested by a nonlinear attracting graph equation over a periodic base; the computed invariant graph has residual at roundoff and scales like O(epsilon).
- Appendix F is tested by comparing the exact nonlinear graph with the recursively computed first and second expansion coefficients.
- Appendix E is tested by 100 randomized close-base transported block models; invariant stable graph residuals are at roundoff and the stable rates remain below one.
- Appendix G is tested by a positive full-flow invariant example and by a time-T-only counterexample showing why full-flow invariance is necessary.