from pathlib import Path
import re, json

final_path = Path('/home/user/final_manuscript_full_revised.md')
text = final_path.read_text()
low = text.lower()

checks = []

def add(id, desc, patterns, required=True, note=''):
    found = []
    missing = []
    for pat in patterns:
        if isinstance(pat, tuple) and pat[0] == 're':
            ok = re.search(pat[1], text, flags=re.I|re.S) is not None
            label = pat[1]
        else:
            ok = str(pat).lower() in low
            label = pat
        (found if ok else missing).append(label)
    checks.append({
        'id': id, 'description': desc, 'required': required,
        'ok': len(missing)==0, 'found': found, 'missing': missing, 'note': note
    })

# Audit restoration checklist
add('abstract_active_voice', 'Active-voice abstract/introduction replacements', ['We present a persistence theorem', 'The proof uses three ingredients', 'We include quantitative parameter dependence', 'Our main result'])
add('no_meta_phrases', 'No obvious repair/meta phrasing or corrupted source artifacts', [('re', r'Your assessment|Your diagnosis|What has been repaired|Final honest|Next step|fatal point|invalid Lipschitz|false Lipschitz|ï»¿|â')])
# This is inverted; handle separately below.

# Core framework and linear theorem
add('transported_bundle_differences', 'Transported fibre comparisons and Delta notation', ['P_{x\\leftarrow y}', '\\tau_{y\\leftarrow x}', '\\Delta_y^x h'])
add('invariant_bunching', 'Invariant bunching formulation and one-step sufficient form', ['coordinate-invariant formulation', '\\|\\Phi(n,0)|_{E_m^s}\\|', '\\|\\Phi(-n,0)|_{E_m^u}\\|', 'uniformly equivalent to the original norms'])
add('green_projection_indexing', 'Correct target-fibre projection of q_n', ['q_n\\in E_{m_{n+1}}', 'q_n^\\sigma=P_{m_{n+1}}^\\sigma q_n'])
add('ck_linear_inverse_support', 'C^k cohomological inverse support: first jet, k-jet, transported difference quotient', ['First consider \\(k=1\\)', 'induced first-jet cocycle', 'principal homogeneous \\(k\\)-jet equation', 'transported difference quotients', '\\zeta_t(m)'])
add('linear_parameter_dependence', 'Parameter dependence for Green operator', ['Green sums converge uniformly in both the base point and the parameter', 'parameter-dependent cohomological equation'])

# HPS theorem and graph transform
add('admissible_class_and_constants', 'Admissible class, completeness, and order of constants', ['\\mathcal B_{\\rho,L}', 'complete', 'constants are chosen in the following order', 'tube radius', 'cone or Lipschitz aperture'])
add('cone_definitions', 'Center/stable/unstable cone definitions and invariance', ['\\mathcal C^c_{(m,\\eta)}', '\\mathcal C^s_{(m,\\eta)}', '\\mathcal C^u_{(m,\\eta)}', 'cone invariance properties'])
add('hps_smallness_hypotheses', 'HPS smallness hypotheses including D_eta b and pointwise remainder', ['D_\\eta b_0(m,0)=0', '\\|D_\\eta r_\\varepsilon(m,\\eta)\\|', '\\|D_\\eta b_\\varepsilon(m,\\eta)\\|', '\\|r_\\varepsilon(m,\\eta)\\|'])
add('graph_transform_mechanism', 'C0 graph metric, contraction factor, radius estimate, Lipschitz preservation', ['maximal transported vertical separation', 'e^{-\\mathrm{gap}\\,N}', '\\|\\mathcal H_\\varepsilon h\\|_{C^0}', 'not in the Lipschitz norm', 'Lipschitz bound is preserved separately'])
add('two_sided_hadamard', 'Two-sided Hadamard graph transform description', ['two-sided normally hyperbolic sense', 'stable components are matched forward', 'unstable components backward'])
add('jet_extension_hps', 'Jet extension and quantitative derivative estimates', ['lifting the graph transform to jet bundles', 'first jets', '\\(k\\)-jet transform', 'derivative estimates require these lifted jet contractions'])
add('hps_imported_caveat', 'HPS theorem imported/citation caveat', ['imported HPS mechanism', 'self-contained proof', 'cite a source'])

# Fenichel theorem
add('tubular_verification', 'Tubular-coordinate verification including why D_eta b0=0', ['base component of \\(F_0\\)', 'vertical vector in \\(E_m\\)', 'has no \\(TM\\)-component'])
add('tube_invariance', 'Tube inclusion and graph transform domain', ['F_\\varepsilon(U_E^\\rho)\\subset U_E^{2\\rho}', 'graph transform is defined on the chosen class'])
add('iterate_lemma', 'Iterate invariance lemma/argument', ['F_\\varepsilon^N(M_\\varepsilon)=M_\\varepsilon', 'commutes with \\(F_\\varepsilon^N\\)', 'local uniqueness for \\(F_\\varepsilon^N\\)'])
add('f_epsilon_diffeomorphism', 'Internal dynamics diffeomorphism proof', ['local diffeomorphism close to the identity', 'covering degree is one', 'shows that \\(f_\\varepsilon\\) is a \\(C^r\\) diffeomorphism'])
add('parameter_expansion', 'Parameter expansion and h0=0', ['F_\\varepsilon\n=\nF_0+\\varepsilon F_1', 'h_0=0', 'Differentiating the invariance equation'])
add('splitting_persistence', 'Persistence of splitting with weakened rates and regularity warning', ['triangular form', 'B_\\varepsilon', 'weakened rates', '\\alpha\'<\\alpha', 'generally continuous under the basic hypotheses'])
add('qualified_uniqueness', 'Qualified admissible-graph uniqueness', ['local uniqueness among admissible graphs', 'every such manifold lies in the admissible class', 'center cones'])

# Stable/unstable fibres and flow
add('stable_perron_setup', 'Stable fibre Perron setup and nonlinear remainder estimates', ['E^{cu}_{\\varepsilon,p_n}', '\\ell_\\gamma^+', '\\|R_n(\\xi)\\|\\le C\\|\\xi\\|^2', '\\|DR_n(\\xi)\\|\\le C\\|\\xi\\|'])
add('center_not_frozen', 'Center component not frozen', ['The center component is not frozen', 'solves simultaneously for the stable displacement'])
add('stable_convolutions', 'Stable and center-unstable convolution estimates', ['stable convolution satisfies', 'center-unstable part', '\\beta_{cu}<\\gamma'])
add('global_stable_phase', 'Global stable set, phase projection, tracking estimate', ['W^s(M_\\varepsilon)', 'F_\\varepsilon(W^s(M_\\varepsilon))\n\\subset', '\\pi^s', 'C e^{-\\gamma n}'])
add('foliation_regularities', 'Separate regularities of leaves, base dependence, phase projection, lamination', ['We distinguish four regularity questions', 'total lamination', 'Hölder', 'not automatically \\(C^r\\) transversely'])
add('unstable_negative_time', 'Unstable fibres and explicit negative-time Perron equation', ['E^{cs}_{\\varepsilon,p_n}', '\\xi_{n-1}', '\\widetilde R_n', 'n\\le0'])
add('flow_reduction', 'Flow reduction, continuous-time Perron formula, full-flow caveat', ['N_t:=\\Phi_t^\\varepsilon(M_\\varepsilon)', 'same Lipschitz and cone bounds', '\\dot\\xi(t)=A(t)\\xi(t)+R(t,\\xi(t))', 'full-flow invariance'])

# Extensions
add('extension_scope_table', 'Extension scope list and comparison table', ['Without additional hypotheses', 'noninvertible parabolic semiflows', '| Setting | Linear inverse | Function space | Additional hypothesis |'])
add('finite_dim_singular_perturbation', 'Finite-dimensional singular perturbation example and approximation', ['\\dot x &= f(x,y,\\varepsilon)', 'M_0=\\{(x,y):f(x,y,0)=0\\}', '\\dot y=\\varepsilon g(h_\\varepsilon(y),y,\\varepsilon)', 'O(\\varepsilon^2)'])
add('parabolic_extensions', 'Parabolic extension details', ['sectorial operator', '\\|e^{At}\\|_{\\mathcal L(X_0,X_\\theta)}', 'uniform resolvent estimate', 'C_\\gamma([0,\\infty),X_\\theta)', 'backward well-posed unstable subspace', 'not local Banach-space diffeomorphisms'])
add('noncompact_extensions', 'Noncompact bounded geometry/global invariance/boundary details', ['positive injectivity radius', 'bounded curvature', 'uniform tubular radius', 'global definition and uniform closeness', 'inflowing/overflowing invariance'])
add('boundary_extension', 'Manifolds with boundary subsection', ['local invariance away from the boundary', 'inflowing invariance', 'overflowing invariance', 'boundary-compatible hyperbolicity'])
add('banach_dim_extensions', 'Banach-dimensional NHIM caveats', ['tubular neighbourhood theorem is not automatic', 'split submanifold', 'uniformly equivalent to the original Banach norm', 'lack of local compactness'])
add('random_extensions', 'Random/tempered cocycle details', ['C(\\omega)e^{-\\alpha n}', 'tempered', 'measurability of projections', 'Pathwise regularity', 'L^p'])
add('quasilinear_extensions', 'Quasilinear derivative loss/tame/maximal regularity/Nash-Moser', ['\\|F(h)\\|_s', '\\|\\mathcal Gq\\|_s', 'maximal regularity', 'L^p(0,T;X_1)', 'smoothing operators are inserted'])
add('delay_extension', 'Delay equation extension retained', ['Delay equations', 'history spaces', 'C([-\\tau,0],\\mathbb R^d)'])

# Optional content intentionally not in manuscript but in verification reports
add('optional_lipschitz_counterexample_in_reports', 'Triangular-wave Lipschitz counterexample exists in verification report, not necessarily manuscript', ['triangular wave'], required=False, note='This was intentionally kept out of journal manuscript and recorded in witness/adversarial reports.')
add('witness_reports_exist', 'Verification reports exist in workspace', [], required=False)

# Fix no_meta: ok means pattern absent, currently reversed
for c in checks:
    if c['id']=='no_meta_phrases':
        c['ok'] = (len(c['found'])==0)  # found bad patterns
        c['missing'] = [] if c['ok'] else c['found']
        c['found'] = [] if c['ok'] else c['found']
        c['description'] += ' (absence check)'

# file existence checks
for c in checks:
    if c['id']=='witness_reports_exist':
        paths = ['math_verification_report.md','deep_math_verification_report.md','randomized_counterexample_report.md','adversarial_stress_test_report.md','witness_level_verification_report.md']
        present=[p for p in paths if Path('/home/user/'+p).exists()]
        c['ok']=len(present)==len(paths)
        c['found']=present
        c['missing']=[p for p in paths if p not in present]
    if c['id']=='optional_lipschitz_counterexample_in_reports':
        report_text='\n'.join(Path('/home/user/'+rp).read_text(errors='ignore') for rp in ['adversarial_stress_test_report.md','witness_level_verification_report.md'] if Path('/home/user/'+rp).exists())
        c['ok']='triangular wave' in report_text.lower()
        c['found']=['triangular wave'] if c['ok'] else []
        c['missing']=[] if c['ok'] else ['triangular wave']

required = [c for c in checks if c['required']]
optional = [c for c in checks if not c['required']]
missing_required = [c for c in required if not c['ok']]

# Additional source heading/topic scan for unified/extension notes: extract distinctive headings and see if represented.
sources = ['/home/user/uploads/audit of pasive voice.txt','/home/user/uploads/step 2.txt','/home/user/uploads/step 4.txt','/home/user/uploads/extension.txt','/home/user/uploads/a and b.txt','/home/user/uploads/unified_manuscript.md']
source_headings=[]
for spath in sources:
    p=Path(spath)
    if p.exists():
        for line in p.read_text(errors='ignore').splitlines():
            if re.match(r'#{1,4}\s+', line):
                h=re.sub(r'^#+\s*','',line).strip()
                if h and len(h)<120:
                    source_headings.append((p.name,h))
# crude heading representation: keyword all nontrivial words or key phrase exists
represented=[]; not_represented=[]
stop=set('the a an and or of to in for with by from on under into as is are was were be been this that we now step proof theorem correct final next'.split())
for fname,h in source_headings:
    # ignore meta headings
    if re.search(r'what has been repaired|final honest|next step|summary of step|completion|diagnosis|assessment', h, re.I):
        continue
    words=[w.lower() for w in re.findall(r'[A-Za-z][A-Za-z0-9_\-]+', h) if w.lower() not in stop]
    phrase=h.lower().replace('hps','hirsch')
    if h.lower() in low or any((len(w)>6 and w in low) for w in words[:4]):
        represented.append((fname,h))
    else:
        not_represented.append((fname,h,words[:5]))

# Some not represented are duplicate local headings; report separately not as fail.
report=[]
report.append('# Systematic Accidental Content-Loss Scan')
report.append('')
report.append(f'Final manuscript scanned: `{final_path}`')
report.append('')
report.append('This scan checks whether the substantive items requested or identified across the audit, step files, extension notes, unified manuscript, and later verification turns are present in the final manuscript or intentionally preserved in verification reports.')
report.append('')
report.append(f'Overall required-content status: **{"PASS" if not missing_required else "POTENTIAL LOSS FOUND"}**')
report.append('')
report.append(f'- Required checklist items: {len(required)}')
report.append(f'- Required items missing or suspect: {len(missing_required)}')
report.append(f'- Optional/report-only items checked: {len(optional)}')
report.append('')
report.append('## Required checklist')
report.append('')
for c in required:
    report.append(f"- {'✅' if c['ok'] else '❌'} **{c['id']}** — {c['description']}")
    if not c['ok']:
        report.append(f"  - Missing patterns: `{c['missing']}`")
    if c.get('note'):
        report.append(f"  - Note: {c['note']}")
report.append('')
report.append('## Optional/report-only items')
report.append('')
for c in optional:
    report.append(f"- {'✅' if c['ok'] else '⚠️'} **{c['id']}** — {c['description']}")
    if c['missing']:
        report.append(f"  - Missing: `{c['missing']}`")
    if c.get('note'):
        report.append(f"  - Note: {c['note']}")
report.append('')
report.append('## Source-heading/topic coverage heuristic')
report.append('')
report.append(f'- Source headings/topics represented heuristically: {len(represented)}')
report.append(f'- Source headings/topics not directly represented: {len(not_represented)}')
report.append('')
if not_represented:
    report.append('The following unrepresented headings are mostly duplicate step/meta headings or intentionally omitted development-note material; inspect if desired:')
    for fname,h,words in not_represented[:80]:
        report.append(f'- `{fname}`: {h}')
else:
    report.append('No unrepresented source headings found by the heuristic.')
report.append('')
report.append('## Conclusion')
report.append('')
if missing_required:
    report.append('The scan found potential required content loss. Review the ❌ items above before treating the manuscript as complete.')
else:
    report.append('No required substantive content loss was detected. Items not in the manuscript are either intentionally excluded meta-development material, duplicate step framing, or optional material preserved in verification reports rather than the journal manuscript.')

Path('/home/user/content_loss_scan_report.md').write_text('\n'.join(report))
Path('/home/user/content_loss_scan.json').write_text(json.dumps({'missing_required':missing_required,'checks':checks,'not_represented_headings':not_represented}, indent=2))
print(json.dumps({'overall_required_ok': not missing_required, 'required_count': len(required), 'missing_required_count': len(missing_required), 'optional_count': len(optional), 'not_represented_heading_count': len(not_represented)}, indent=2))
