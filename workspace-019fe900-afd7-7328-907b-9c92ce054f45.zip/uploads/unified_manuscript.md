
\[
\Theta:U_E\to U_X\subset X
\]

be a \(C^{r+1}\) tubular embedding of a Banach bundle

\[
E\to M
\]

onto a neighbourhood of \(M\), with \(\Theta(m,0)=m\). Assume that \(E\) is equipped with a \(C^r\) connection or, equivalently for the estimates, that we work in a finite \(C^{r+1}\) bundle atlas with uniformly controlled transition maps.

For nearby \(x,y\in M\), let

\[
P_{x\leftarrow y}:E_y\to E_x
\]

denote the chosen fibre identification, and set

\[
\tau_{y\leftarrow x}:=P_{x\leftarrow y}^{-1}:E_x\to E_y.
\]

Define the transported difference of a section \(h\) by

\[
\Delta_y^x h
:=
P_{x\leftarrow y}h(y)-h(x)
\in E_x.
\]

All later differences of bundle-valued quantities will be written using \(\Delta\), not by subtracting vectors in different fibres.

Let \(F_\varepsilon:U_X\to X\) be \(C^{r+1}\) local diffeomorphisms defined on a common neighbourhood of \(M\). In tubular coordinates,

\[
\widehat F_\varepsilon
=
\Theta^{-1}\circ F_\varepsilon\circ\Theta,
\]

and

\[
\widehat F_\varepsilon(m,\eta)
=
\bigl(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta)\bigr),
\]

where \(b_\varepsilon(m,\eta)\in M\) and \(g_\varepsilon(m,\eta)\in E_{b_\varepsilon(m,\eta)}\).

Assume for \(\varepsilon=0\),

\[
b_0(m,0)=f(m),
\qquad
g_0(m,0)=0,
\]

where \(f:M\to M\) is a \(C^{r+1}\) diffeomorphism. Assume the full splitting is invariant:

\[
T_mX=T_mM\oplus E_m^s\oplus E_m^u,
\]

and

\[
DF_0(m)T_mM=T_{f(m)}M,
\qquad
DF_0(m)E_m^\sigma=E_{f(m)}^\sigma,
\quad
\sigma=s,u.
\]

In the tubular coordinates this implies

\[
D_\eta b_0(m,0)=0.
\]

Define the normal linear cocycle

\[
B_m:=D_\eta g_0(m,0):E_m\to E_{f(m)}.
\]

Because \(F_0\) is a local diffeomorphism and the splitting is invariant, \(B_m\) is an isomorphism and both

\[
B_m^s:E_m^s\to E_{f(m)}^s,
\qquad
B_m^u:E_m^u\to E_{f(m)}^u
\]

are isomorphisms.

Assume \(B\) has a continuous invariant exponential dichotomy. To write the estimates correctly, let

\[
m_n=f^n(m),
\]

and let

\[
\Phi(n,k):E_{m_k}\to E_{m_n}
\]

be the evolution operator. Then there exist uniformly bounded projections \(P_k^s,P_k^u\) and constants \(C>0\), \(0<\lambda<1\), such that

\[
\|\Phi(n,k)P_k^s\|
\le C\lambda^{n-k},
\qquad n\ge k,
\]

and

\[
\|\Phi(k,n)P_n^u\|
\le C\lambda^{n-k},
\qquad n\ge k.
\]

Equivalently, the unstable evolution backward in time contracts.

The \(r\)-bunching assumptions should be written invariantly. For each \(0\le k\le r\), assume that there are \(C>0\), \(0<\theta<1\), and \(N\in\mathbb N\) such that for all \(m\),

\[
\|\Phi^s(n,m)\|\,\|Df^{-n}(m)\|^k
\le C\theta^n,
\qquad n\ge 0,
\]

and

\[
\|\Phi^u(-n,m)\|\,\|Df^{n}(m)\|^k
\le C\theta^n,
\qquad n\ge 0.
\]

Equivalently, after replacing \(F_0\) by an iterate and using an adapted norm if necessary, one has strict product inequalities

\[
\sup_m \|B_m^s\|\,\|Df(m)^{-1}\|^k<1,
\]

\[
\sup_m \|(B_m^u)^{-1}\|\,\|Df(m)\|^k<1.
\]

The invariant formulation is preferable because it avoids dependence on a particular choice of norm.

---

# 2. The linear cohomological inverse theorem

The first foundational result is the linear theory.

## Theorem A: Linear cohomological inverse

Let \(f\in\mathrm{Diff}^{r+1}(M)\), and let \(E\to M\) be a \(C^{r+1}\) Banach bundle. Let \(B\in\Gamma^r(\operatorname{Aut}(E))\) be a linear cocycle over \(f\). Assume that \(B\) has an exponential dichotomy and that the \(k\)-bunching inequalities hold for every \(0\le k\le r\).

Then for every \(0\le k\le r\), the cohomological operator

\[
\mathcal A:\Gamma^k(E)\to\Gamma^k(f^*E),
\qquad
(\mathcal A\zeta)(m)=\zeta(f(m))-B_m\zeta(m),
\]

is an isomorphism. Its inverse

\[
\mathcal G:\Gamma^k(f^*E)\to\Gamma^k(E)
\]

is bounded:

\[
\|\mathcal G q\|_{C^k}
\le C_k\|q\|_{C^k}.
\]

If the dichotomy projections are only continuous, the statement is interpreted in the standard difference-quotient/topological-jet sense: whenever \(q\in C^k\), the unique bounded solution \(\zeta\) is \(C^k\), and the inverse is bounded in the corresponding difference-quotient norms.

If \(q\) depends \(C^\ell\) on a parameter and the dichotomy and bunching estimates are uniform in that parameter, then \(\zeta=\mathcal G q\) depends smoothly on the parameter, with regularity controlled by the parameter-bunching conditions.

---

## Proof outline of Theorem A

### Step 1: \(C^0\) inverse

Let \(q\in\Gamma^0(f^*E)\). Along the orbit \(m_n=f^n(m)\), write

\[
q_n=q(m_n)\in E_{m_{n+1}}.
\]

The equation

\[
\zeta(f(m))-B_m\zeta(m)=q(m)
\]

becomes

\[
\zeta_{n+1}-B_{m_n}\zeta_n=q_n.
\]

The unique bounded solution is

\[
\zeta_n^s
=
\sum_{j=-\infty}^{n-1}
\Phi^s(n,j+1)P_{j+1}^s q_j,
\]

\[
\zeta_n^u
=
-
\sum_{j=n}^{\infty}
\Phi^u(n,j+1)P_{j+1}^u q_j.
\]

The exponential estimates give

\[
\|\zeta_n\|
\le
C_G\|q\|_{C^0},
\]

with, for example,

\[
C_G
\le
2C\sup_m\|P_m^s\|+2C\sup_m\|P_m^u\|
\sum_{j=0}^\infty \lambda^j.
\]

Thus \(\mathcal A:\Gamma^0(E)\to\Gamma^0(f^*E)\) is invertible.

### Step 2: Jet cocycles

For \(k=1\), the formal first-jet equation is

\[
J(f(m))Df(m)-B_mJ(m)=Q(m),
\]

where

\[
J(m)\in L(T_mM,E_m).
\]

Equivalently,

\[
J(f(m))-B_mJ(m)Df(m)^{-1}
=
Q(m)Df(m)^{-1}.
\]

The induced stable cocycle is

\[
J\longmapsto B_m^sJ\,Df(m)^{-1},
\]

and the induced backward unstable cocycle is

\[
J\longmapsto (B_m^u)^{-1}J\,Df(m).
\]

The \(1\)-bunching inequalities give exponential dichotomies for these induced cocycles.

For general \(k\), the principal \(k\)-jet cocycle is

\[
J\longmapsto
B_mJ\circ (Df(m)^{-1})^{\otimes k}.
\]

The stable norm is controlled by

\[
\|B_m^s\|\,\|Df(m)^{-1}\|^k,
\]

and the backward unstable norm by

\[
\|(B_m^u)^{-1}\|\,\|Df(m)\|^k.
\]

The \(k\)-bunching assumptions give strict contraction.

### Step 3: Difference quotients

If the dichotomy projections are not \(C^k\), one does not differentiate the Green formula directly. Instead one applies the \(C^0\) theory to transported difference quotients. The bunching assumptions give uniform bounds on the difference-quotient equations. Passing to the limit gives genuine derivatives. This is the standard HPS difference-quotient argument.

This proves Theorem A. â

---

# 3. The HPS invariant-section theorem

The second foundational result is the nonlinear invariant-section theorem. This is the hard theorem. It replaces the invalid Lipschitz-norm contraction.

## Theorem B: HPS invariant-section theorem, Banach-bundle version

Let \(E\to M\) be a \(C^{r+1}\) Banach bundle over a compact finite-dimensional \(C^{r+1}\) manifold without boundary. Let \(f:M\to M\) be a \(C^{r+1}\) diffeomorphism. Let \(B\in\Gamma^r(\operatorname{Aut}(E))\) have an exponential dichotomy over \(f\), and assume the \(k\)-bunching inequalities for \(0\le k\le r\).

Let \(F_\varepsilon\) be a family of \(C^{r+1}\) fibre maps defined near the zero section, written in bundle coordinates as

\[
F_\varepsilon(m,\eta)
=
\bigl(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta)\bigr).
\]

Assume:

1. **Base map near \(f\).**  
   \[
   b_\varepsilon(m,0)
   \]
   is \(C^{r+1}\)-close to \(f(m)\).

2. **Zero section approximately invariant.**  
   \[
   g_\varepsilon(m,0)=O(\delta_\varepsilon)
   \]
   in \(C^r\), where \(\delta_\varepsilon\to0\).

3. **Normal linear part close to \(B\).**  
   \[
   D_\eta g_\varepsilon(m,0)
   =
   \tau_{b_\varepsilon(m,0)\leftarrow f(m)}B_m
   +
   O(\delta_\varepsilon).
   \]

4. **No first-order base-normal coupling at the unperturbed level.**  
   \[
   D_\eta b_0(m,0)=0.
   \]

5. **Nonlinear remainder is small near the zero section.**  
   After subtracting the transported linear part, the remainder \(r_\varepsilon\) satisfies, on a tube \(\|\eta\|\le\rho\),

   \[
   \|r_\varepsilon(m,\eta)\|
   \le
   C\delta_\varepsilon
   +
   \omega(\rho)\|\eta\|,
   \]

   and

   \[
   \|D_\eta r_\varepsilon(m,\eta)\|
   \le
   C\delta_\varepsilon+\omega(\rho),
   \]

   where \(\omega(\rho)\to0\) as \(\rho\to0\).

Then there exist constants \(\rho>0\), \(L>0\), and \(\delta_0>0\) such that if \(\delta_\varepsilon<\delta_0\), there is a locally unique invariant section

\[
h_\varepsilon\in\Gamma^r(E)
\]

satisfying

\[
\|h_\varepsilon\|_{C^0}\le\rho,
\qquad
\operatorname{Lip}(h_\varepsilon)\le L,
\]

and

\[
F_\varepsilon(\operatorname{graph}(h_\varepsilon))
=
\operatorname{graph}(h_\varepsilon).
\]

Moreover, if \(F_\varepsilon\) depends \(C^\ell\) on \(\varepsilon\) in the \(C^{r+1}\) topology and the bunching assumptions hold uniformly, then \(h_\varepsilon\) depends smoothly on \(\varepsilon\), with regularity determined by the parameter-bunching conditions.

If

\[
\|F_\varepsilon-F_0\|_{C^k}
\le C|\varepsilon|,
\qquad 0\le k\le r,
\]

then

\[
\|h_\varepsilon\|_{C^k}
\le C_k|\varepsilon|.
\]

Uniqueness holds among invariant sections lying in the same tube and satisfying the same Lipschitz/cone admissibility bounds.

---

## Proof outline of Theorem B

This is the standard HPS proof. The important point is that the contraction is not taken in Lipschitz norm.

### Step 1: Admissible class

Let

\[
\mathcal B_{\rho,L}
=
\left\{
h\in C^0(M,E):
\|h\|_{C^0}\le\rho,
\ \operatorname{Lip}(h)\le L
\right\}.
\]

Equip \(\mathcal B_{\rho,L}\) with the \(C^0\) metric. Because \(M\) is compact and the Lipschitz bound is uniform, \(\mathcal B_{\rho,L}\) is closed in \(C^0\), hence complete.

The constants are chosen in the following order:

1. choose an iterate/adapted norm so that the linear bunching margins are strict;
2. choose the tube radius \(\rho>0\) small;
3. choose the Lipschitz/cone bound \(L>0\) small;
4. choose the perturbation size \(\delta_\varepsilon\) small.

The \(C^0\) radius \(\rho\) and the Lipschitz radius \(L\) are controlled separately.

### Step 2: Cone fields and graph transform

Define center cones in the tangent bundle near the zero section. The invariant splitting and the bunching inequalities imply that \(F_\varepsilon\) preserves these cones in the appropriate forward/backward sense.

Given an admissible graph \(\Gamma_h\), its image \(F_\varepsilon(\Gamma_h)\) is not simply pushed forward and reparametrized by the base. Instead, one uses the stable/unstable cone geometry to define the Hadamard graph transform \(\mathcal H_\varepsilon(h)\). The construction is intrinsic:

- stable directions are matched forward;
- unstable directions are matched backward;
- the center/base coordinate is reparametrized by the unique intersection with the centre cone.

The cone conditions guarantee that \(\mathcal H_\varepsilon(h)\) is again an admissible graph.

### Step 3: \(C^0\) contraction

The graph transform \(\mathcal H_\varepsilon\) is a contraction in the \(C^0\) graph metric. The distance between two graphs is measured by the maximal transported vertical separation after centre matching. The contraction factor is controlled by the normal hyperbolicity gap. Schematically,

\[
d_{C^0}(\mathcal H_\varepsilon h_1,\mathcal H_\varepsilon h_2)
\le
q\, d_{C^0}(h_1,h_2),
\qquad q<1.
\]

This avoids the false Lipschitz-norm estimate for composition.

### Step 4: Lipschitz cone invariance

The Lipschitz bound is preserved separately. Cone invariance implies that if \(\operatorname{Lip}(h)\le L\), then

\[
\operatorname{Lip}(\mathcal H_\varepsilon h)\le L.
\]

This is not proved by contracting in Lipschitz norm. It is proved by the usual tangent-cone estimate: tangent vectors to the graph remain in the prescribed centre cone, and the cone aperture determines the Lipschitz bound.

### Step 5: Existence of a Lipschitz invariant section

Since \(\mathcal H_\varepsilon\) maps \(\mathcal B_{\rho,L}\) into itself and is a contraction in the \(C^0\) metric, Banachâs fixed point theorem gives a unique fixed point

\[
h_\varepsilon\in\mathcal B_{\rho,L}.
\]

This section is Lipschitz and its graph is invariant.

### Step 6: Jet extension and \(C^r\) regularity

For \(k=1,\dots,r\), lift the graph transform to the \(k\)-jet bundle \(J^kE\). The \(k\)-jet transform is a fibre map over the already constructed lower-order jet. Its principal linear part is the induced \(k\)-jet cocycle controlled by the \(k\)-bunching inequalities.

The HPS section-extension theorem says that if the \(k\)-jet transform is a fibre contraction over a base contraction, then the invariant section has a continuous \(k\)-jet. Induction gives

\[
h_\varepsilon\in C^r.
\]

The proof of the fibre contraction uses the linear jet estimates from Theorem A and the smallness of the nonlinear jet remainders. FaÃ  di Bruno terms depend only on lower-order jets and are controlled inductively.

This proves Theorem B. â

---

# 4. Application to Fenichelâs theorem

We now apply Theorem B to the Banach-space map \(F_\varepsilon\).

## 4.1 Verification of the hypotheses

In tubular coordinates,

\[
\widehat F_\varepsilon(m,\eta)
=
\bigl(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta)\bigr).
\]

At \(\varepsilon=0\),

\[
b_0(m,0)=f(m),
\qquad
g_0(m,0)=0,
\]

and the invariant splitting gives

\[
D_\eta b_0(m,0)=0.
\]

The normal linear cocycle is

\[
B_m=D_\eta g_0(m,0).
\]

By assumption, \(B\) has an exponential dichotomy and satisfies the \(r\)-bunching inequalities.

For \(\varepsilon\neq0\), the \(C^1\)-closeness of \(F_\varepsilon\) to \(F_0\) gives the smallness assumptions in Theorem B. The nonlinear remainder is defined using fibre transport:

\[
r_\varepsilon(m,\eta)
=
g_\varepsilon(m,\eta)
-
\tau_{b_\varepsilon(m,\eta)\leftarrow f(m)}
B_m\eta.
\]

Because \(D_\eta b_0(m,0)=0\), the remainder satisfies the required quadratic/smallness estimates near the zero section.

Thus Theorem B applies.

---

## 4.2 Existence of \(M_\varepsilon\)

Theorem B gives a unique \(C^r\) section

\[
h_\varepsilon\in\Gamma^r(E)
\]

such that its graph is invariant. Define

\[
K_\varepsilon(m)=\Theta(m,h_\varepsilon(m)),
\]

and

\[
M_\varepsilon=K_\varepsilon(M).
\]

Define the internal dynamics

\[
f_\varepsilon(m)
=
b_\varepsilon(m,h_\varepsilon(m)).
\]

Then

\[
F_\varepsilon(K_\varepsilon(m))
=
K_\varepsilon(f_\varepsilon(m)).
\]

Hence

\[
F_\varepsilon(M_\varepsilon)\subset M_\varepsilon.
\]

We next prove equality.

---

## 4.3 The internal dynamics is a diffeomorphism

Because \(h_\varepsilon\) is \(C^1\)-small and \(F_\varepsilon\) is \(C^1\)-close to \(F_0\), the map \(f_\varepsilon\) is \(C^1\)-close to \(f\). Therefore

\[
f^{-1}\circ f_\varepsilon:M\to M
\]

is a \(C^1\) local diffeomorphism \(C^1\)-close to the identity.

Since \(M\) is compact without boundary, a local diffeomorphism sufficiently \(C^1\)-close to the identity is a global diffeomorphism. Equivalently, it is a covering map of degree one componentwise. Hence \(f_\varepsilon\) is a \(C^r\) diffeomorphism.

Therefore

\[
F_\varepsilon(M_\varepsilon)
=
K_\varepsilon(f_\varepsilon(M))
=
K_\varepsilon(M)
=
M_\varepsilon.
\]

---

## 4.4 Iterate lemma

If the bunching inequalities were obtained by replacing \(F_0\) with an iterate \(F_0^N\), Theorem B gives a manifold invariant under \(F_\varepsilon^N\). To obtain invariance under \(F_\varepsilon\), use the following lemma.

### Lemma: iterate invariance

Suppose \(M_\varepsilon\) is locally unique among admissible invariant graphs for \(F_\varepsilon^N\). Then \(M_\varepsilon\) is invariant under \(F_\varepsilon\).

### Proof

Since \(M_\varepsilon\) is invariant under \(F_\varepsilon^N\),

\[
F_\varepsilon^N(M_\varepsilon)=M_\varepsilon.
\]

Consider

\[
F_\varepsilon(M_\varepsilon).
\]

Because \(F_\varepsilon\) commutes with \(F_\varepsilon^N\),

\[
F_\varepsilon^N(F_\varepsilon(M_\varepsilon))
=
F_\varepsilon(F_\varepsilon^N(M_\varepsilon))
=
F_\varepsilon(M_\varepsilon).
\]

For small \(\varepsilon\), \(F_\varepsilon(M_\varepsilon)\) remains in the same admissible tube and satisfies the same Lipschitz/cone bounds. By local uniqueness for \(F_\varepsilon^N\),

\[
F_\varepsilon(M_\varepsilon)=M_\varepsilon.
\]

â

This completes the proof of invariance under the original map.

---

# 5. Quantitative \(O(\varepsilon)\) estimates

Assume now that

\[
\|F_\varepsilon-F_0\|_{C^r}
\le C|\varepsilon|
\]

on the fixed tube, with uniform \(C^r\) bounds.

The parameterized version of Theorem B gives

\[
\|h_\varepsilon\|_{C^k}
\le C_k|\varepsilon|,
\qquad
0\le k\le r.
\]

Since

\[
f_\varepsilon(m)=b_\varepsilon(m,h_\varepsilon(m)),
\]

the chain rule gives

\[
\|f_\varepsilon-f\|_{C^k}
\le C_k|\varepsilon|.
\]

Thus

\[
\|K_\varepsilon-i_M\|_{C^r}
+
\|f_\varepsilon-f\|_{C^r}
=
O(|\varepsilon|).
\]

This conclusion uses the uniform jet estimates supplied by Theorem B, not merely the \(C^0\) contraction.

---

# 6. Persistence of the invariant splitting

After constructing \(M_\varepsilon\), straighten it by the change of variables

\[
(m,\eta)\mapsto (m,\eta-h_\varepsilon(m)).
\]

In these coordinates, \(M_\varepsilon\) is the zero section. The derivative along \(M_\varepsilon\) is a small perturbation of the original block operator

\[
Df\oplus B^s\oplus B^u.
\]

The perturbed stable and unstable bundles are constructed as invariant graphs of linear maps between the original summands. The graph transforms for those linear maps are contractions because the bunching inequalities remain valid with slightly weakened constants.

Thus there exist invariant bundles

\[
T M_\varepsilon\oplus E_\varepsilon^s\oplus E_\varepsilon^u
\]

with exponential estimates. The correct rate statement is:

> For every weakened rate compatible with the original strict gap, sufficiently small perturbations admit exponential estimates with those weakened rates.

The perturbed bundles are generally continuous. Higher bundle regularity requires additional bunching assumptions and is not automatic from the regularity of \(M_\varepsilon\).

---

# 7. Correct stable-fibre theorem

The stable-fibre construction must be stated separately and requires explicit rate-gap assumptions.

Assume that along \(M_\varepsilon\) we have a splitting

\[
T_{p}X
=
E^s_{\varepsilon,p}
\oplus
E^{cu}_{\varepsilon,p},
\]

where

\[
E^{cu}_{\varepsilon,p}
=
T_pM_\varepsilon\oplus E^u_{\varepsilon,p}.
\]

Assume there are constants \(C>0\), \(\alpha_s>0\), and \(\beta_{cu}\ge0\) such that for the evolution \(DF_\varepsilon\),

\[
\|\Phi_\varepsilon^s(n,k)\|
\le C e^{-\alpha_s(n-k)},
\qquad n\ge k,
\]

and for the backward evolution on the center-unstable complement,

\[
\|\Phi_\varepsilon^{cu}(n,k)\|
\le C e^{\beta_{cu}(k-n)},
\qquad n\le k.
\]

Assume the strong stable gap

\[
\beta_{cu}<\alpha_s.
\]

Fix \(p_0\in M_\varepsilon\) and let

\[
p_n=F_\varepsilon^n(p_0).
\]

In moving coordinates along \(p_n\), write a nearby orbit as

\[
p_n+\xi_n,
\]

with

\[
\xi_n=\xi_n^s+\xi_n^{cu}.
\]

The nonlinear variational equation is

\[
\xi_{n+1}
=
A_n\xi_n+R_n(\xi_n),
\]

where

\[
R_n(0)=0,
\qquad
DR_n(0)=0.
\]

Choose \(\gamma\) such that

\[
\beta_{cu}<\gamma<\alpha_s.
\]

For \(a\in E^s_{\varepsilon,p_0}\), define the Perron operator on sequences \(\xi=(\xi_n)_{n\ge0}\) in the weighted norm

\[
\|\xi\|_\gamma
=
\sup_{n\ge0}e^{\gamma n}\|\xi_n\|
\]

by

\[
\xi_n^s
=
\Phi_\varepsilon^s(n,0)a
+
\sum_{k=0}^{n-1}
\Phi_\varepsilon^s(n,k+1)
P_{k+1}^sR_k(\xi_k),
\]

and

\[
\xi_n^{cu}
=
-
\sum_{k=n}^{\infty}
\Phi_\varepsilon^{cu}(n,k+1)
P_{k+1}^{cu}R_k(\xi_k).
\]

Because \(R_k(\xi_k)=O(\|\xi_k\|^2)\), and because

\[
\beta_{cu}<\gamma<\alpha_s,
\]

the operator is a contraction on a small ball in the weighted space. Its fixed point gives the local strong stable fibre through \(p_0\).

The unstable fibre is obtained by applying the same construction to \(F_\varepsilon^{-1}\).

---

## 7.1 Regularity of fibres

Internal regularity of stable/unstable leaves follows from differentiating the Perron operator, but requires stronger strong-stable/strong-unstable bunching. For \(C^\ell\) internal regularity one needs inequalities of the form

\[
\ell\beta_{cu}<\alpha_s
\]

or the corresponding product bunching conditions.

Transverse regularity of the family of leaves, and regularity of the asymptotic phase projection, requires still stronger assumptions. These must be stated separately. The correct conclusion is not automatically that the full foliation is \(C^r\) in all directions.

---

# 8. Flow version

Let \(\Phi_t^\varepsilon\) be a genuine \(C^{r+1}\) local flow defined for positive and negative time near \(M\). Assume that \(M\) is invariant under the full unperturbed flow:

\[
\Phi_t^0(M)=M
\]

for all relevant \(t\). This assumption is necessary for the uniqueness argument below.

Choose \(T>0\) large enough that the time-\(T\) map

\[
F_\varepsilon=\Phi_T^\varepsilon
\]

satisfies the map hypotheses. The map theorem gives \(M_\varepsilon\) invariant under \(F_\varepsilon\).

For \(0\le t\le T\), define

\[
N_t=\Phi_t^\varepsilon(M_\varepsilon).
\]

Because the flow maps commute,

\[
F_\varepsilon(N_t)
=
\Phi_T^\varepsilon\Phi_t^\varepsilon(M_\varepsilon)
=
\Phi_t^\varepsilon\Phi_T^\varepsilon(M_\varepsilon)
=
N_t.
\]

For small \(\varepsilon\), \(N_t\) remains in the same admissible class uniformly for \(t\in[0,T]\). By local uniqueness,

\[
N_t=M_\varepsilon.
\]

Thus \(M_\varepsilon\) is invariant under the full flow.

If \(M\) is only invariant under the time-\(T\) map of the unperturbed flow, this argument is not valid. One must either assume full flow invariance or use a continuous-time Perron construction.

---

# 9. Parameter dependence

The parameterized version of Theorem B gives smooth dependence on \(\varepsilon\). Suppose

\[
\varepsilon\mapsto F_\varepsilon
\]

is \(C^\ell\) as a map into \(C^{r+1}\) local diffeomorphisms, and suppose the bunching assumptions hold uniformly. Then

\[
\varepsilon\mapsto h_\varepsilon
\]

is \(C^{\ell'}\), where \(\ell'\) is determined by the parameter-bunching conditions. In many standard situations one obtains parameter regularity up to the available bunching order.

This is one of the main advantages of formulating the proof through the HPS invariant-section theorem.

---

# 10. What has been repaired

This presentation adopts the following changes:

1. The invariant splitting is assumed geometrically:

   \[
   T_mX=T_mM\oplus E_m^s\oplus E_m^u
   \]

   is \(DF_0\)-invariant, and \(D_\eta b_0(m,0)=0\).

2. The cohomological operator is correctly viewed as

   \[
   \mathcal A:\Gamma(E)\to\Gamma(f^*E),
   \]

   with fibre identifications made explicit.

3. The Green inverse is isolated as Theorem A, with the \(C^k\) bounds either obtained from \(C^k\) dichotomy projections or from the standard difference-quotient theorem.

4. The nonlinear fixed-point equation is written using transported differences:

   \[
   \Psi_\varepsilon(h)(m)
   =
   \Delta_{b_{\varepsilon,h}(m)}^{f(m)}h
   -
   P_{f(m)\leftarrow b_{\varepsilon,h}(m)}
   r_\varepsilon(m,h(m)).
   \]

5. The false Lipschitz-norm contraction is abandoned. Existence is obtained from the HPS graph-transform theorem: \(C^0\) contraction plus separate Lipschitz/cone invariance.

6. Higher regularity is obtained from the HPS jet-extension/section-extension theorem, not by formal differentiation.

7. The iterate argument is stated explicitly.

8. The flow argument assumes full unperturbed flow invariance.

9. Stable fibres are constructed using the splitting

   \[
   E^s\oplus (TM_\varepsilon\oplus E^u_\varepsilon),
   \]

   not by freezing the center orbit.

10. The stable/unstable foliation regularity is separated from NHIM persistence and tied to explicit strong bunching assumptions.

---

# 11. Final honest assessment

The equation

\[
h=-\mathcal G\mathcal N_\varepsilon(h)
\]

is still the correct nonlinear residual formulation of the invariant graph equation. But it is not the right contraction problem in the Lipschitz category. The rigorous existence mechanism is the HPS invariant-section theorem, or equivalently the HadamardâPerron graph transform on admissible sections with cone invariance.

With Theorem A and Theorem B stated as above, the proof of the compact invertible Banach-space Fenichel theorem is complete modulo the standard HPS invariant-section theorem. If one requires a proof of Theorem B itself with all difference-quotient and jet-bundle details, that is precisely the content of the monograph proofs of HirschâPughâShub, Fenichel, ChowâLinâLu, and related Banach-space extensions.Your assessment is correct. The proof given in Steps 14 is complete only for the **compact, invertible Banach-space model case**. To reach the genuinely infinite-dimensional settings that matter in PDEs, delay equations, random dynamics, and noncompact geometric problems, one needs separate extensions. The architecture is the same, but the function spaces, Perron operators, and regularity machinery must be changed.

The extensions are developed as for the five major extensions you listed:

1. sectorial semigroups / parabolic PDEs via analytic-scale Perron;
2. noncompact NHIMs via uniform exponential tracking;
3. Banach-dimensional NHIMs via adapted metrics and bounded geometry;
4. random/nonautonomous cocycles via multiplicative ergodic theory and random Perron operators;
5. quasilinear PDEs and derivative loss via topological jets or tame scale methods.

This is best viewed as **Step 5** of the extended proof program.

---

# 1. Parabolic semiflows and sectorial generators

The compact invertible theorem does not cover equations of the form

\[
u_t=Au+f(u,v),
\]

where \(A\) is an unbounded sectorial operator. The correct setting is a Banach scale.

## 1.1. Banach scale

Let

\[
X_1 \hookrightarrow X_\theta \hookrightarrow X_0
\]

be an interpolation scale of Banach spaces, with \(X_1=D(A)\). Typically \(X_0\) is the phase space, \(X_1\) the domain of the sectorial operator, and \(X_\theta\) an intermediate space.

Assume \(A\) is sectorial on \(X_0\), so that it generates an analytic semigroup \(e^{At}\). The smoothing estimate has the form

\[
\|e^{At}\|_{\mathcal L(X_0,X_\theta)}
\le
C t^{-\theta}e^{at},
\qquad t>0,
\]

for appropriate \(\theta\ge0\).

## 1.2. Fast-slow parabolic model

A typical fast-slow parabolic system is

\[
\begin{aligned}
u_t &= Au+f(u,v,\varepsilon),\\
v_t &= \varepsilon g(u,v,\varepsilon),
\end{aligned}
\]

where \(u\in X_0\) is the fast variable and \(v\in Y\) is the slow variable. The slow variable may be finite-dimensional or infinite-dimensional. In the cleanest theorem, take \(Y\) finite-dimensional or a complete manifold with bounded geometry.

The critical manifold is assumed to be a graph

\[
M_0=\{(h_0(v),v):v\in Y_0\}.
\]

The fast linearization along \(M_0\) is

\[
L_v
=
A+D_u f(h_0(v),v,0).
\]

## 1.3. Uniform exponential dichotomy, not spectral separation

Pointwise spectral separation

\[
\sigma(L_v)\cap i\mathbb R=\varnothing
\]

is not enough. One must assume a **uniform exponential dichotomy** for the semigroup generated by \(L_v\).

A correct hypothesis is:

There exist uniformly bounded projections \(P_v^s,P_v^u\) and constants \(C>0\), \(\alpha>0\), \(\beta\ge0\), such that

\[
\|e^{L_v t}P_v^s\|_{\mathcal L(X_0)}
\le
C e^{-\alpha t},
\qquad t\ge0,
\]

and, on the unstable subspace,

\[
\|e^{L_v(-t)}P_v^u\|_{\mathcal L(X_0)}
\le
C e^{-\alpha t},
\qquad t\ge0.
\]

For parabolic regularity, one also needs smoothing estimates such as

\[
\|e^{L_v t}P_v^s\|_{\mathcal L(X_0,X_\theta)}
\le
C t^{-\rho}e^{-\alpha t},
\qquad t>0,
\]

for some \(\rho<1\).

A convenient sufficient condition is a uniform resolvent estimate:

\[
\sup_{v\in Y_0}
\sup_{\Re\lambda\ge -\eta}
\|(\lambda-L_v)^{-1}\|_{\mathcal L(X_0)}
<\infty,
\]

together with uniform bounds on the spectral projections.

## 1.4. Analytic-scale Perron operator

The invariant manifold is obtained by solving a Perron equation for the fast deviation

\[
\eta(t)=u(t)-h_\varepsilon(v(t)).
\]

In mild form, the deviation equation is

\[
\eta(t)
=
e^{L_{v(t)}t}\eta(0)
+
\int_0^t
e^{L_{v(t)}(t-s)}
R(s,\eta(s))\,ds.
\]

Decompose into stable and unstable parts. For a prescribed stable coordinate \(a\in X^s\), the Perron operator is

\[
\boxed{
\eta^s(t)
=
e^{L^s t}a
+
\int_0^t
e^{L^s(t-s)}
P^s R(s,\eta(s))\,ds,
}
\]

and

\[
\boxed{
\eta^u(t)
=
-
\int_t^\infty
e^{L^u(t-s)}
P^u R(s,\eta(s))\,ds.
}
\]

The unstable integral is only meaningful if the unstable cocycle is backward well-posed. In many parabolic problems the unstable subspace is finite-dimensional, and this is manageable.

For purely normally attracting critical manifolds, the unstable part is absent, and the construction is significantly simpler.

## 1.5. Weighted spaces

Choose a decay weight \(\gamma>0\) satisfying the appropriate gap condition. Work in

\[
C_\gamma([0,\infty),X_\theta)
:=
\left\{
\eta:
\|\eta\|_\gamma
=
\sup_{t\ge0}e^{\gamma t}\|\eta(t)\|_{X_\theta}
<\infty
\right\}.
\]

The analytic smoothing estimate gives convolution bounds of the form

\[
\sup_{t\ge0}
e^{\gamma t}
\int_0^t
(t-s)^{-\rho}
e^{-\alpha(t-s)}
e^{-\gamma s}\,ds
<\infty,
\]

provided

\[
\gamma<\alpha,
\qquad
\rho<1.
\]

This is the parabolic analogue of the discrete Green estimate.

## 1.6. Regularity and slow manifold

The Perron fixed point gives a map

\[
h_\varepsilon:Y_0\to X_\theta
\]

such that

\[
M_\varepsilon=\{(h_\varepsilon(v),v):v\in Y_0\}
\]

is positively invariant under the parabolic semiflow.

If the data are \(C^r\) and the dichotomy satisfies the appropriate bunching conditions, then \(h_\varepsilon\in C^r\) as a map into \(X_\theta\). The reduced equation on \(M_\varepsilon\) is exactly

\[
v_t
=
\varepsilon g(h_\varepsilon(v),v,\varepsilon).
\]

Approximations arise only after expanding \(h_\varepsilon\).

## 1.7. What replaces Step 1?

The linear cohomological inverse from Step 1 is replaced by the **semigroup Perron inverse**. The Green sums become convolution integrals against the analytic semigroup. The bunching conditions become rate-gap conditions involving the stable decay rate, the center/slow growth rate, and the parabolic smoothing exponent.

---

# 2. Noncompact finite-dimensional NHIMs

The compactness of \(M\) was used to obtain uniform constants, compact tube control, and global degree arguments. For noncompact \(M\), one must replace compactness by uniformity.

## 2.1. Bounded geometry

Assume \(M\) is a complete finite-dimensional \(C^{r+1}\) manifold with bounded geometry:

1. positive injectivity radius;
2. bounded curvature and covariant derivatives up to order \(r+1\);
3. a finite or uniformly controlled bundle atlas;
4. uniform tubular radius;
5. uniformly bounded bundle projections;
6. uniformly bounded derivatives of \(f\), \(B\), and the nonlinear terms.

The base map

\[
f:M\to M
\]

should be a \(C^{r+1}\) diffeomorphism with uniformly bounded derivative and inverse.

## 2.2. Function spaces

Replace \(C^k(M,E)\) by bounded uniformly continuous jet spaces:

\[
C_b^k(M,E).
\]

For example,

\[
C_b^0(M,E)
=
\{h:\|h\|_{C^0}:=\sup_m\|h(m)\|<\infty\}.
\]

The admissible class is

\[
\mathcal B_{\rho,L}
=
\left\{
h\in C_b^0(M,E):
\|h\|_{C^0}\le\rho,
\ \operatorname{Lip}(h)\le L
\right\}.
\]

This space is complete in the \(C^0\) metric even when \(M\) is noncompact.

## 2.3. Uniform exponential dichotomy

Assume the normal cocycle \(B\) has a uniform exponential dichotomy over all of \(M\):

\[
\|\Phi^s(n,k)\|\le C\lambda^{n-k},
\qquad n\ge k,
\]

and

\[
\|\Phi^u(k,n)\|\le C\lambda^{n-k},
\qquad n\ge k,
\]

with constants independent of the base point.

The bunching assumptions must also be uniform:

\[
\sup_m
\|\Phi^s(n,m)\|\,\|Df^{-n}(m)\|^k
\le
C\theta^n,
\]

and similarly for the unstable part.

## 2.4. Uniform graph transform

The HPS graph transform is now defined globally using the uniform tube and uniform cones. The contraction estimate becomes

\[
d(\mathcal H_\varepsilon h_1,\mathcal H_\varepsilon h_2)
\le
q d(h_1,h_2),
\]

with \(q<1\) independent of the base point.

The proof is the same as in the compact case, except that all constants are uniform.

## 2.5. Global invariance and tracking

For global invariance, one needs to ensure that orbits do not leave the tube. There are several common ways to guarantee this:

1. assume the perturbed dynamics is globally defined and uniformly close on the relevant region;
2. use a cutoff to make the vector field globally controlled outside a neighbourhood;
3. prove a local theorem and then use continuation/tracking while the orbit remains in the tube;
4. assume overflowing/inflowing invariance if \(M\) has boundary.

For noncompact manifolds without boundary, if the tube and constants are global, the fixed-point theorem gives a globally invariant section.

## 2.6. Manifolds with boundary

If \(M\) has boundary, ordinary invariance may fail at the boundary. One must use:

- inflowing invariance;
- overflowing invariance;
- local invariance with cutoff;
- boundary-normal hyperbolicity conditions.

This is essential in many singular perturbation problems where the critical manifold is only normally hyperbolic on a restricted region.

---

# 3. Banach-dimensional NHIMs

If the invariant manifold \(M\) itself is infinite-dimensional, the compact finite-dimensional proof no longer applies. One needs a Banach-manifold version with adapted geometry.

## 3.1. Split Banach manifolds

Let \(M\) be a \(C^{r+1}\) Banach manifold. Assume the tangent bundle is split:

\[
T_mX=T_mM\oplus N_m,
\]

with \(N_m\) a complemented Banach subspace. One needs a \(C^r\) tubular neighbourhood theorem for Banach manifolds. This is not automatic in arbitrary Banach spaces. It is safest to assume:

1. \(M\) is a split submanifold of \(X\);
2. the normal bundle is complemented;
3. there exists a \(C^r\) tubular chart;
4. the chart and its inverse have uniformly bounded derivatives up to order \(r\).

In Hilbert spaces this is much easier because orthogonal complements are available.

## 3.2. Bounded geometry for Banach bases

Since compactness is unavailable, one must assume bounded geometry:

1. uniform charts;
2. uniformly bounded transition maps and their derivatives;
3. uniformly bounded connection coefficients, if using a connection;
4. uniformly bounded projections onto tangent and normal bundles;
5. uniform tube radius.

The admissible sections are again bounded Lipschitz sections:

\[
h\in C_b^0(M,N),
\qquad
\|h\|_{C^0}\le\rho,
\qquad
\operatorname{Lip}(h)\le L.
\]

## 3.3. Uniform dichotomy over a Banach base

The normal cocycle

\[
B_m:N_m\to N_{f(m)}
\]

must have a uniform exponential dichotomy over the possibly infinite-dimensional base \(M\). The projections

\[
P_m^s,P_m^u:N_m\to N_m
\]

must be uniformly bounded. If higher regularity is desired, the projections must have the corresponding regularity, or one must use the difference-quotient theorem.

## 3.4. Adapted metrics

On noncompact or Banach bases, the bunching conditions should be formulated in adapted metrics. One often constructs a Lyapunov metric or Finsler metric such that

\[
\|B_m^s\|\,\|Df(m)^{-1}\|^k
\le q_k<1,
\]

and

\[
\|(B_m^u)^{-1}\|\,\|Df(m)\|^k
\le \widetilde q_k<1,
\]

uniformly in \(m\).

The adapted metric must be equivalent to the original Banach norm with uniform constants, or else one must track the equivalence constants carefully.

## 3.5. Jet theory on Banach manifolds

For \(C^r\) regularity, one needs a jet-bundle or covariant-difference theorem on Banach manifolds. The issues are:

1. lack of local compactness;
2. possible failure of smooth partitions of unity;
3. derivative loss in composition operators;
4. need for uniform control of transition maps.

The cleanest approach is again the HPS section-extension theorem, formulated for Banach bundles with bounded geometry.

---

# 4. Random and nonautonomous cocycles

For random dynamical systems, the base is no longer a single map \(f:M\to M\), but a driving system

\[
(\Omega,\mathcal F,\mathbb P,\theta),
\]

where \(\theta\) is a measurable or metric dynamical system.

A random map has the form

\[
F_\varepsilon(\omega,\cdot):X\to X,
\]

and satisfies the cocycle property

\[
F_\varepsilon(\theta^n\omega)
\circ
\cdots
\circ
F_\varepsilon(\omega)
=
F_\varepsilon^{(n)}(\omega).
\]

## 4.1. Random linear cocycle

The normal linear cocycle is

\[
B(\omega):E(\omega)\to E(\theta\omega).
\]

One assumes a random exponential dichotomy:

\[
\|\Phi^s(\omega,n)\|
\le
C(\omega)e^{-\alpha n},
\]

\[
\|\Phi^u(\omega,-n)\|
\le
C(\omega)e^{-\alpha n},
\]

where \(C(\omega)\) is tempered, or uniform if one wants a deterministic-style theorem.

## 4.2. Multiplicative ergodic theorem

If the base is ergodic and the cocycle satisfies appropriate compactness or quasi-compactness assumptions, the multiplicative ergodic theorem can provide Lyapunov splittings. In Banach spaces this is subtle and usually requires:

1. compact embeddings;
2. quasi-compactness;
3. measurability of projections;
4. integrability of logarithmic growth.

In many applications, one assumes the random dichotomy directly and uses the multiplicative ergodic theorem only to verify it.

## 4.3. Random Perron operator

The Perron operator is defined pathwise. For each \(\omega\), one solves

\[
\xi_{n+1}
=
A_n(\omega)\xi_n
+
R_n(\omega,\xi_n).
\]

The Green operator is random:

\[
\mathcal G(\omega)
=
\mathcal A(\omega)^{-1}.
\]

If the dichotomy is tempered rather than uniform, one works in tempered weighted spaces:

\[
\|\xi\|_{\gamma,\omega}
=
\sup_n e^{\gamma |n|}\|\xi_n\|,
\]

with \(\gamma\) chosen between the tempered center rates and the stable/unstable rates.

## 4.4. Random invariant manifolds

The fixed point gives a random section

\[
h_\varepsilon(\omega,\cdot):M\to E(\omega).
\]

It satisfies the cocycle invariance equation

\[
F_\varepsilon
\left(
\omega,
\operatorname{graph}(h_\varepsilon(\omega))
\right)
=
\operatorname{graph}
\left(
h_\varepsilon(\theta\omega)
\right).
\]

Measurability of \(h_\varepsilon\) follows from measurable selection or from the fact that the fixed point is obtained as a limit of measurable iterates.

## 4.5. Regularity

Pathwise regularity follows from the same jet-extension argument, provided the bunching inequalities hold pathwise or in a tempered sense. Measurable or \(L^p\) dependence on \(\omega\) requires additional estimates.

---

# 5. Quasilinear PDEs and derivative loss

Quasilinear problems are harder because the linearized operator depends on the solution and may lose derivatives.

A schematic quasilinear equation is

\[
u_t
=
A(u)u+f(u).
\]

The linearization at a solution involves coefficients depending on \(u\), and the associated evolution family may not be smoothing enough to recover all derivatives.

## 5.1. Scales of Banach spaces

Work in a scale

\[
\{X_s\}_{s\ge0},
\]

with

\[
X_{s+\sigma}\hookrightarrow X_s.
\]

The invariant graph is sought in a stronger space \(X_{s+\sigma}\), while the residual is estimated in \(X_s\).

The nonlinear map is assumed to be tame:

\[
\|F(h)\|_s
\le
C_s\bigl(\|h\|_{s+\sigma}+1\bigr).
\]

The linear inverse may lose derivatives:

\[
\|\mathcal G q\|_s
\le
C_s\|q\|_{s+\sigma}.
\]

If the loss can be recovered by parabolic smoothing, the standard Perron method still works. If not, one may need a NashMoser scheme.

## 5.2. Parabolic quasilinear equations

For quasilinear parabolic equations, maximal regularity often replaces the simple analytic semigroup estimate. One works in spaces such as

\[
L^p(0,T;X_1)\cap W^{1,p}(0,T;X_0),
\]

or Hölder spaces

\[
C^\alpha([0,T];X_0)\cap C([0,T];X_\alpha).
\]

The linearized equation has a solution operator with smoothing:

\[
\|\eta\|_{\text{high}}
\le
C\|q\|_{\text{low}}.
\]

This smoothing can compensate for the derivative loss in the quasilinear terms.

## 5.3. Topological jets

For finite differentiability with derivative loss, ordinary derivatives may be inconvenient. One can use topological jets or difference quotients.

A topological \(k\)-jet records the Taylor-like behaviour of a section without requiring classical derivatives at every stage. The cohomological inverse is then proved on spaces of continuous jets. This is the appropriate infinite-dimensional analogue of the difference-quotient method used in Step 1.

The jet cocycle has principal part

\[
J\mapsto B_mJ\circ(Df_m^{-1})^{\otimes k},
\]

and the bunching conditions control it. Lower-order terms are handled inductively.

## 5.4. NashMoser recovery

If the inverse loses derivatives and no smoothing is available, a Banach fixed-point argument may fail. A NashMoser implicit function theorem can sometimes be used instead.

The structure is:

1. linearized operator has a tame inverse with derivative loss;
2. nonlinear remainder is tame;
3. smoothing operators are inserted at each Newton step;
4. tame estimates control the loss;
5. convergence is obtained in a lower regularity category.

This is common in fully nonlinear PDE and KAM-type problems.

---

# 6. Unified architecture of all extensions

Despite the differences, all extensions follow the same conceptual pattern.

## Step A: Choose the correct trajectory or section space

- Compact maps: \(C^k(M,E)\).
- Noncompact maps: \(C_b^k(M,E)\).
- Parabolic semiflows: weighted mild-solution spaces \(C_\gamma([0,\infty),X_\theta)\).
- Random systems: pathwise tempered weighted spaces.
- Quasilinear problems: tame scales \(X_s\).

## Step B: Prove the linear inverse

The linear inverse is one of the following:

1. discrete Green operator for exponential dichotomies;
2. continuous Perron operator for flows;
3. analytic semigroup convolution operator for parabolic equations;
4. random Green operator for random dichotomies;
5. tame inverse for quasilinear problems.

The key requirement is a uniform or tempered exponential dichotomy with appropriate smoothing or recovery.

## Step C: Define the nonlinear residual or graph transform

The invariant object is characterized by one of:

\[
\Psi_\varepsilon(h)=0,
\]

or

\[
h=\mathcal H_\varepsilon(h),
\]

or

\[
\xi=\mathcal P_\varepsilon(\xi).
\]

The choice depends on whether one uses sections, graphs, or trajectories.

## Step D: Prove existence

Existence is obtained by:

1. \(C^0\) contraction plus cone invariance;
2. fibre contraction;
3. Schauder or LyapunovPerron fixed point;
4. NashMoser in loss-of-derivative settings.

The contraction is never taken naively in Lipschitz norm.

## Step E: Prove regularity

Regularity is obtained by:

1. jet extension;
2. difference quotients;
3. topological jets;
4. covariant derivatives;
5. tame estimates.

The required bunching conditions depend on the desired regularity and on whether one wants internal, transverse, or phase regularity.

## Step F: Prove persistence of splittings and fibres

Once the invariant manifold is constructed, stable and unstable fibres are obtained by half-line Perron operators with the correct complementary bundles:

\[
E^s\oplus(TM_\varepsilon\oplus E^u_\varepsilon),
\]

and

\[
E^u\oplus(TM_\varepsilon\oplus E^s_\varepsilon).
\]

The rate-gap assumptions must be stated separately for stable and unstable fibres.

---

# 7. Corrected scope of the original theorem

The theorem proved in Steps 14 should be stated as follows:

> **Theorem.** Let \(M\) be a compact finite-dimensional \(C^{r+1}\) manifold without boundary, embedded with a split \(C^{r+1}\) tubular neighbourhood in a Banach space \(X\). Let \(F_\varepsilon\) be \(C^{r+1}\) local diffeomorphisms, \(C^1\)-close to \(F_0\), with \(F_0(M)=M\). Assume the normal cocycle has an exponential dichotomy and satisfies the \(r\)-bunching inequalities. Then there exists a locally unique \(C^r\) invariant manifold \(M_\varepsilon\) near \(M\). If the perturbation is \(O(\varepsilon)\) in \(C^r\), then \(M_\varepsilon\) is \(O(\varepsilon)\) in \(C^r\). Stable and unstable fibres exist under additional strong bunching assumptions, with regularity stated separately.

The following are **not** consequences of this theorem without additional hypotheses:

1. parabolic semiflows;
2. unbounded generators;
3. noncompact NHIMs;
4. Banach-dimensional NHIMs;
5. delay equations;
6. random cocycles;
7. quasilinear PDEs;
8. derivative-loss problems;
9. manifolds with boundary;
10. transverse \(C^r\) foliation regularity without extra bunching.

---

# 8. Final conclusion

The compact invertible proof is the model case. The profound extensions are obtained by replacing the basic ingredients as follows:

| Setting | Replace discrete Green operator by | Function space | Main extra hypothesis |
|---|---:|---:|---|
| Compact invertible map | discrete Green sum | \(C^k(M,E)\) | bunching |
| Noncompact finite-dimensional | discrete Green sum, uniform constants | \(C_b^k(M,E)\) | bounded geometry |
| Banach-dimensional NHIM | discrete Green sum on Banach bundles | \(C_b^k(M,E)\) | split tubular neighbourhood, adapted metric |
| Parabolic semiflow | analytic semigroup Perron integral | weighted mild-solution spaces | sectorial dichotomy, smoothing |
| Random cocycle | random Green operator | tempered weighted spaces | random/tempered dichotomy |
| Quasilinear PDE | tame or maximal-regularity inverse | scales \(X_s\) | derivative recovery or NashMoser |

The conceptual core remains:

\[
\text{exponential dichotomy}
\quad\Longrightarrow\quad
\text{linear Perron/Green inverse}
\quad\Longrightarrow\quad
\text{nonlinear fixed point}
\quad\Longrightarrow\quad
\text{jet regularity}
\quad\Longrightarrow\quad
\text{Fenichel persistence}.
\]

That is the correct extended architecture for infinite-dimensional Fenichel theory beyond the compact invertible case.ï»¿## Step 2: The nonlinear HPS invariant-section theorem

We now prove the nonlinear core of the argument. This is the step that replaces the invalid Lipschitz-norm contraction from earlier.

The theorem below is the Banach-bundle form of the HirschâPughâShub invariant-section theorem. It is the precise nonlinear mechanism that produces an invariant section from a normally hyperbolic linear cocycle.

---

# 1. Statement of the invariant-section theorem

Let \(M\) be a compact finite-dimensional \(C^{r+1}\) manifold without boundary. Let

\[
E\to M
\]

be a \(C^{r+1}\) Banach bundle. Let \(f:M\to M\) be a \(C^{r+1}\) diffeomorphism.

Let \(F_\varepsilon\) be a family of \(C^{r+1}\) maps defined on a neighbourhood of the zero section of \(E\), written in bundle coordinates as

\[
F_\varepsilon(m,\eta)
=
\bigl(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta)\bigr),
\]

where

\[
b_\varepsilon(m,\eta)\in M,
\qquad
g_\varepsilon(m,\eta)\in E_{b_\varepsilon(m,\eta)}.
\]

Assume the following.

### Hypothesis 2.1: Unperturbed zero section

For \(\varepsilon=0\),

\[
b_0(m,0)=f(m),
\qquad
g_0(m,0)=0.
\]

Thus the zero section is invariant under \(F_0\).

### Hypothesis 2.2: Normal linear cocycle

Define

\[
B_m:=D_\eta g_0(m,0):E_m\to E_{f(m)}.
\]

Assume \(B\) is a \(C^r\) linear cocycle over \(f\), and that each \(B_m\) is an isomorphism.

Assume there is a continuous invariant exponential dichotomy

\[
E=E^s\oplus E^u
\]

for \(B\), with uniformly bounded projections, satisfying the usual stable/unstable estimates.

### Hypothesis 2.3: No first-order base-normal coupling at the zero section

Assume

\[
D_\eta b_0(m,0)=0.
\]

Geometrically, this says that the tangent space to the zero section, i.e. the center direction, is invariant under \(DF_0\). In the ambient Fenichel setting this follows from the invariant splitting

\[
T_mX=T_mM\oplus E_m^s\oplus E_m^u.
\]

### Hypothesis 2.4: Bunching

Assume the \(k\)-bunching inequalities for every \(0\le k\le r\). Equivalently, after replacing \(f,B\) by an iterate and using an adapted norm if necessary, assume that for \(0\le k\le r\),

\[
\sup_m
\|B_m^s\|\,\|Df(m)^{-1}\|^k<1,
\]

and

\[
\sup_m
\|(B_m^u)^{-1}\|\,\|Df(m)\|^k<1.
\]

### Hypothesis 2.5: Small nonlinear remainder

Choose a \(C^r\) connection on \(E\), or equivalently work in a finite \(C^{r+1}\) bundle atlas with uniformly controlled transition maps. Let

\[
P_{x\leftarrow y}:E_y\to E_x
\]

denote the local fibre identification, and let

\[
\tau_{y\leftarrow x}=P_{x\leftarrow y}^{-1}.
\]

Define the nonlinear remainder \(r_\varepsilon\) by

\[
r_\varepsilon(m,\eta)
:=
g_\varepsilon(m,\eta)
-
\tau_{b_\varepsilon(m,\eta)\leftarrow f(m)}
B_m\eta.
\]

Assume that on a tube \(\|\eta\|\le\rho\),

\[
\|r_\varepsilon(m,0)\|
\le C\delta_\varepsilon,
\]

and

\[
\|D_\eta r_\varepsilon(m,\eta)\|
\le
C\delta_\varepsilon+\omega(\rho),
\]

where

\[
\delta_\varepsilon:=\|F_\varepsilon-F_0\|_{C^1}
\]

and \(\omega(\rho)\to0\) as \(\rho\to0\).

Assume also that the base nonlinear part is small in the sense that

\[
\|D_\eta b_\varepsilon(m,\eta)\|
\le
C\delta_\varepsilon+\omega(\rho).
\]

This is possible because \(D_\eta b_0(m,0)=0\).

---

## Theorem: HPS invariant-section theorem

Under the hypotheses above, there exist constants

\[
\rho>0,\qquad L>0,\qquad \delta_0>0
\]

such that if \(\delta_\varepsilon<\delta_0\), then there exists a unique section

\[
h_\varepsilon\in C^r(M,E)
\]

satisfying

\[
\|h_\varepsilon\|_{C^0}\le\rho,
\qquad
\operatorname{Lip}(h_\varepsilon)\le L,
\]

and

\[
F_\varepsilon(\operatorname{graph}(h_\varepsilon))
=
\operatorname{graph}(h_\varepsilon).
\]

More explicitly, if

\[
f_\varepsilon(m):=b_\varepsilon(m,h_\varepsilon(m)),
\]

then

\[
F_\varepsilon(m,h_\varepsilon(m))
=
\bigl(f_\varepsilon(m),h_\varepsilon(f_\varepsilon(m))\bigr).
\]

Moreover, if

\[
\|F_\varepsilon-F_0\|_{C^k}
\le C|\varepsilon|,
\qquad
0\le k\le r,
\]

with uniform \(C^k\) bounds on a common tube, then

\[
\|h_\varepsilon\|_{C^k}
\le C_k|\varepsilon|.
\]

If \(F_\varepsilon\) depends smoothly on \(\varepsilon\) and the bunching assumptions hold uniformly, then \(h_\varepsilon\) depends smoothly on \(\varepsilon\), with regularity determined by the parameter-bunching conditions.

Uniqueness holds inside the admissible class of sections lying in the chosen tube and satisfying the prescribed Lipschitz/cone bound.

---

# 2. Preparations: transported differences and the invariant equation

Before proving the theorem, we write the invariant graph equation in a geometrically correct form.

For a section \(h:M\to E\), define

\[
b_{\varepsilon,h}(m)
:=
b_\varepsilon(m,h(m)).
\]

The graph of \(h\) is invariant if and only if

\[
h(b_{\varepsilon,h}(m))
=
g_\varepsilon(m,h(m)).
\]

Both sides lie in the fibre over \(b_{\varepsilon,h}(m)\). Transport both sides to the fibre over \(f(m)\). Define the transported residual

\[
\Psi_\varepsilon(h)(m)
:=
P_{f(m)\leftarrow b_{\varepsilon,h}(m)}
\left[
h(b_{\varepsilon,h}(m))
-
g_\varepsilon(m,h(m))
\right].
\]

Then

\[
\Psi_\varepsilon(h)\in\Gamma(f^*E),
\]

and the invariant graph equation is

\[
\Psi_\varepsilon(h)=0.
\]

Using the remainder \(r_\varepsilon\), we have

\[
P_{f\leftarrow b_h}g_\varepsilon(m,h)
=
B_mh(m)
+
P_{f\leftarrow b_h}r_\varepsilon(m,h).
\]

Therefore

\[
\Psi_\varepsilon(h)
=
P_{f\leftarrow b_h}h(b_h)
-
Bh
-
P_{f\leftarrow b_h}r_\varepsilon(\cdot,h).
\]

Recall the linear cohomological operator

\[
\mathcal A h
=
h\circ f-Bh.
\]

Thus

\[
\Psi_\varepsilon(h)
=
\mathcal Ah
+
\mathcal N_\varepsilon(h),
\]

where

\[
\mathcal N_\varepsilon(h)
:=
P_{f\leftarrow b_h}h(b_h)
-
h\circ f
-
P_{f\leftarrow b_h}r_\varepsilon(\cdot,h).
\]

This identity is useful for estimates and for the jet induction, but it is not the contraction problem in the Lipschitz category. The contraction is obtained through the Hadamard graph transform.

---

# 3. The admissible class

Choose a Riemannian metric on \(M\) and a bundle metric on \(E\). Define the admissible class

\[
\mathcal B_{\rho,L}
:=
\left\{
h\in C^0(M,E):
\|h\|_{C^0}\le\rho,
\ \operatorname{Lip}(h)\le L
\right\}.
\]

We equip \(\mathcal B_{\rho,L}\) with the \(C^0\) metric

\[
d(h_1,h_2):=\|h_1-h_2\|_{C^0}.
\]

Because \(M\) is compact, \(\mathcal B_{\rho,L}\) is complete in this metric. Indeed, a uniform limit of sections with Lipschitz constant at most \(L\) again has Lipschitz constant at most \(L\).

The constants are chosen in the following order:

1. choose an iterate and/or adapted norm so that the bunching margins are strict;
2. choose the tube radius \(\rho>0\) small;
3. choose the Lipschitz/cone bound \(L>0\) small;
4. choose the perturbation size \(\delta_\varepsilon\) small.

The important point is that the \(C^0\) radius \(\rho\) and the Lipschitz radius \(L\) are controlled separately.

---

# 4. Cone fields

The graph transform is built using invariant cone fields.

Near the zero section, the tangent bundle of \(E\) splits as

\[
TE \cong TM\oplus E^s\oplus E^u.
\]

The zero section has tangent bundle \(TM\). A section \(h\) with small Lipschitz constant has a graph whose tangent spaces lie close to \(TM\). This is expressed using center cones.

Choose a small number \(\kappa>0\). Define the center cone at a point \((m,\eta)\) by

\[
\mathcal C^c_{(m,\eta)}
:=
\left\{
(v^c,v^s,v^u):
\|(v^s,v^u)\|\le \kappa\|v^c\|
\right\}.
\]

A graph with Lipschitz constant \(L\le\kappa\) is tangent to these cones.

Similarly, define stable and unstable cones by

\[
\mathcal C^s_{(m,\eta)}
:=
\left\{
(v^c,v^s,v^u):
\|v^u\|\le \kappa(\|v^c\|+\|v^s\|)
\right\},
\]

and

\[
\mathcal C^u_{(m,\eta)}
:=
\left\{
(v^c,v^s,v^u):
\|v^s\|\le \kappa(\|v^c\|+\|v^u\|)
\right\}.
\]

The exponential dichotomy and the bunching inequalities imply the following cone invariance properties for \(\varepsilon\) small.

### Cone invariance lemma

For \(\rho,L,\delta_\varepsilon\) sufficiently small:

1. \(DF_\varepsilon\) maps center cones strictly inside center cones;
2. \(DF_\varepsilon\) maps stable cones strictly inside stable cones;
3. \(DF_\varepsilon^{-1}\) maps unstable cones strictly inside unstable cones;
4. vectors in stable cones contract forward relative to the center direction;
5. vectors in unstable cones contract backward relative to the center direction.

Quantitatively, there exists \(0<q<1\) such that, after an iterate if necessary,

\[
\|DF_\varepsilon v^s\|
\le q\|DF_\varepsilon v^c\|
\]

for stable-dominated vectors, and similarly for unstable vectors under \(DF_\varepsilon^{-1}\).

The proof is a direct consequence of the linear estimates for \(B^s,B^u\), the boundedness of the tangent part \(Df\), and the smallness of the nonlinear terms. The bunching inequalities ensure that the normal contraction/expansion dominates the tangential motion.

---

# 5. The Hadamard graph transform

We now define the graph transform.

Let \(h\in\mathcal B_{\rho,L}\), and let

\[
\Gamma_h:=\{(m,h(m)):m\in M\}.
\]

Because \(h\) is Lipschitz and \(L\) is small, \(\Gamma_h\) is a Lipschitz graph tangent to the center cones.

The Hadamard graph transform \(\mathcal H_\varepsilon\) is defined as follows.

Given \(\Gamma_h\), consider its image

\[
F_\varepsilon(\Gamma_h).
\]

Because of the cone invariance properties, \(F_\varepsilon(\Gamma_h)\) is again a Lipschitz graph over \(M\), after the appropriate stable/unstable reparametrization. More precisely:

- the stable component is matched forward along stable cones;
- the unstable component is matched backward along unstable cones;
- the center coordinate is used to label the resulting graph.

The result is a new section

\[
\mathcal H_\varepsilon(h)
\]

whose graph is the transformed graph.

This is the point where the two-sided nature of the dynamics is used. One does not simply push the graph forward and project to \(M\). The stable and unstable directions are matched in opposite time directions. This is the Hadamard graph transform.

In the simplest normally attracting case, the transform is just the forward image reparametrized by the base. In the full normally hyperbolic case, the transform is the two-sided version described above.

---

# 6. The \(C^0\) contraction estimate

The key estimate is that \(\mathcal H_\varepsilon\) is a contraction in the \(C^0\) graph metric.

## Lemma: \(C^0\) contraction

There exists \(0<q<1\) such that for all \(h_1,h_2\in\mathcal B_{\rho,L}\),

\[
d(\mathcal H_\varepsilon h_1,\mathcal H_\varepsilon h_2)
\le
q\, d(h_1,h_2).
\]

### Proof outline

Let

\[
\Gamma_i=\Gamma_{h_i},
\qquad i=1,2.
\]

Take a point \(p_1\in\Gamma_1\) and let \(p_2\in\Gamma_2\) be the point matched to it by the center coordinate after the graph transform. Let

\[
\Delta:=p_1-p_2
\]

after transporting to a common fibre. Decompose

\[
\Delta=\Delta^c+\Delta^s+\Delta^u.
\]

The graph transform matching eliminates the center component as the labeling variable. The remaining normal components satisfy a linear variational equation with a nonlinear forcing. The stable component is propagated forward, and the unstable component backward.

Using the Green operator from Step 1, the normal separation after transformation can be written schematically as

\[
\Delta_{\mathrm{new}}
=
\mathcal G
\left[
\text{nonlinear terms depending on }\Delta
\right].
\]

The linear part of this equation is controlled by the normal dichotomy. The nonlinear terms are small because the graphs lie in a small tube and the perturbation is small. The contraction factor is of the form

\[
q
\le
C\left(
e^{-(\alpha-\beta)N}
+
\delta_\varepsilon
+
\omega(\rho)
+
L
\right),
\]

where \(N\) is the iterate used to obtain strict bunching. Choosing \(N\) large, then \(\rho,L,\delta_\varepsilon\) small, gives \(q<1\).

This is the standard HadamardâPerron contraction estimate. It is a \(C^0\) estimate. It does not require Lipschitz continuity of the composition operator in Lipschitz norm.

â

---

# 7. Preservation of the Lipschitz bound

The contraction estimate alone gives a fixed point in \(C^0\). We must also preserve the Lipschitz bound.

## Lemma: Lipschitz preservation

For \(\rho,L,\delta_\varepsilon\) sufficiently small,

\[
h\in\mathcal B_{\rho,L}
\implies
\mathcal H_\varepsilon(h)\in\mathcal B_{\rho,L}.
\]

In particular,

\[
\operatorname{Lip}(\mathcal H_\varepsilon h)\le L.
\]

### Proof

This is proved using cone invariance, not by estimating the Lipschitz norm of the composition.

If \(h\in\mathcal B_{\rho,L}\), then \(\Gamma_h\) is tangent to the center cone of aperture \(L\). The graph transform is constructed using the stable/unstable cone geometry. The cone invariance lemma implies that the transformed graph is again tangent to the same center cone. Since the center cone aperture corresponds exactly to the Lipschitz bound, the new section satisfies

\[
\operatorname{Lip}(\mathcal H_\varepsilon h)\le L.
\]

The \(C^0\) radius is preserved because the perturbation is small and the zero section is approximately invariant. More precisely,

\[
\|\mathcal H_\varepsilon h\|_{C^0}
\le
C\delta_\varepsilon
+
q\rho.
\]

Choosing \(\delta_\varepsilon\) small enough gives

\[
\|\mathcal H_\varepsilon h\|_{C^0}\le\rho.
\]

Thus \(\mathcal H_\varepsilon\) maps \(\mathcal B_{\rho,L}\) into itself.

â

---

# 8. Existence of a Lipschitz invariant section

We now apply the Banach fixed point theorem.

The space \(\mathcal B_{\rho,L}\) is complete in the \(C^0\) metric. The graph transform satisfies

\[
\mathcal H_\varepsilon:\mathcal B_{\rho,L}\to\mathcal B_{\rho,L},
\]

and

\[
d(\mathcal H_\varepsilon h_1,\mathcal H_\varepsilon h_2)
\le
q d(h_1,h_2),
\qquad q<1.
\]

Therefore there exists a unique fixed point

\[
h_\varepsilon\in\mathcal B_{\rho,L}
\]

such that

\[
\mathcal H_\varepsilon(h_\varepsilon)=h_\varepsilon.
\]

By construction of the graph transform, the graph of \(h_\varepsilon\) is invariant:

\[
F_\varepsilon(\operatorname{graph}(h_\varepsilon))
=
\operatorname{graph}(h_\varepsilon).
\]

At this stage, \(h_\varepsilon\) is Lipschitz.

---

# 9. Upgrade to \(C^1\)

We now prove that \(h_\varepsilon\) is \(C^1\).

The fixed point equation can be written in residual form as

\[
\Psi_\varepsilon(h_\varepsilon)=0.
\]

Equivalently,

\[
\mathcal A h_\varepsilon
+
\mathcal N_\varepsilon(h_\varepsilon)
=
0.
\]

The linear operator \(\mathcal A\) is invertible on \(C^0\), and its inverse is the Green operator \(\mathcal G\). However, to get \(C^1\) regularity, we use the first-jet extension of the graph transform.

Let \(J^1E\) be the first jet bundle of \(E\). The graph transform \(\mathcal H_\varepsilon\) lifts to a transform

\[
\mathcal H_\varepsilon^{(1)}
\]

on first jets. Over a fixed section \(h\), the fibre of \(J^1E\) consists of possible first derivatives \(Dh\).

The linear part of \(\mathcal H_\varepsilon^{(1)}\) in the fibre direction is precisely the induced first-jet cocycle studied in Step 1. Its stable part is controlled by

\[
\|B_m^s\|\,\|Df(m)^{-1}\|,
\]

and its backward unstable part by

\[
\|(B_m^u)^{-1}\|\,\|Df(m)\|.
\]

By the \(1\)-bunching assumption, both are strictly less than one.

The nonlinear first-jet terms depend on \(h_\varepsilon\) and on \(DF_\varepsilon\). Since \(h_\varepsilon\) is small and \(F_\varepsilon\) is \(C^1\)-close to \(F_0\), these terms are small. Hence the lifted first-jet transform is a fibre contraction over the base fixed point \(h_\varepsilon\).

The HPS fibre contraction theorem implies that the fixed section \(h_\varepsilon\) has a continuous first jet. Therefore

\[
h_\varepsilon\in C^1.
\]

Moreover, the first derivative satisfies the differentiated invariance equation

\[
\mathcal A_1(Dh_\varepsilon)
=
Q_{\varepsilon,1}(h_\varepsilon),
\]

where \(\mathcal A_1\) is the first-jet cohomological operator and \(Q_{\varepsilon,1}\) depends continuously on \(h_\varepsilon\) and \(DF_\varepsilon\). By Step 1,

\[
\|Dh_\varepsilon\|_{C^0}
\le
C_1\|Q_{\varepsilon,1}(h_\varepsilon)\|_{C^0}.
\]

This gives the \(C^1\) bound.

---

# 10. Higher regularity by jet extension

We now prove by induction that \(h_\varepsilon\in C^r\).

Assume \(h_\varepsilon\in C^{k-1}\) for some \(1\le k\le r\). Consider the \(k\)-jet bundle \(J^kE\). The graph transform lifts to

\[
\mathcal H_\varepsilon^{(k)}
\]

on \(k\)-jets. The fibre variable is the \(k\)-th derivative \(D^k h\).

The principal linear part of the lifted transform is the induced \(k\)-jet cocycle. Its stable norm is controlled by

\[
\|B_m^s\|\,\|Df(m)^{-1}\|^k,
\]

and its backward unstable norm by

\[
\|(B_m^u)^{-1}\|\,\|Df(m)\|^k.
\]

The \(k\)-bunching assumptions make both strictly less than one.

The remaining terms in the \(k\)-jet equation depend on:

- derivatives of \(F_\varepsilon\) up to order \(k\);
- jets of \(h_\varepsilon\) of order at most \(k-1\);
- transition functions of the bundle atlas or connection coefficients.

By the induction hypothesis, the lower-order jets are already known and bounded. Therefore the \(k\)-jet transform is a fibre contraction over the already constructed \((k-1)\)-jet.

The section-extension theorem gives a continuous \(k\)-jet section. Hence

\[
h_\varepsilon\in C^k.
\]

Induction gives

\[
h_\varepsilon\in C^r.
\]

This proves the regularity part of the invariant-section theorem.

---

# 11. Quantitative \(O(\varepsilon)\) estimates

Assume now that

\[
\|F_\varepsilon-F_0\|_{C^k}
\le
C|\varepsilon|,
\qquad
0\le k\le r,
\]

with uniform bounds on the common tube.

At the zero section,

\[
\mathcal N_\varepsilon(0)
=
O(|\varepsilon|)
\]

in \(C^r\). The graph-transform fixed point satisfies

\[
h_\varepsilon
=
\mathcal H_\varepsilon(h_\varepsilon).
\]

The \(C^0\) contraction gives

\[
\|h_\varepsilon\|_{C^0}
\le
\frac{1}{1-q}\|\mathcal H_\varepsilon(0)\|_{C^0}
\le
C_0|\varepsilon|.
\]

The jet-extension argument gives the corresponding estimates for derivatives. At order \(k\), the \(k\)-jet fixed point is obtained by a fibre contraction whose inhomogeneous term is \(O(|\varepsilon|)\) once the lower-order jets are known to be \(O(|\varepsilon|)\). Therefore

\[
\|h_\varepsilon\|_{C^k}
\le
C_k|\varepsilon|,
\qquad
0\le k\le r.
\]

Thus

\[
\|h_\varepsilon\|_{C^r}
=
O(|\varepsilon|).
\]

This quantitative estimate uses the uniform jet contraction constants. It does not follow from the \(C^0\) contraction alone.

---

# 12. Parameter dependence

Suppose \(\varepsilon\mapsto F_\varepsilon\) is \(C^\ell\) as a map into the space of \(C^{r+1}\) maps, and suppose the bunching estimates hold uniformly in \(\varepsilon\).

The graph transform \(\mathcal H_\varepsilon\) depends \(C^\ell\) on \(\varepsilon\) in the appropriate topology. The fixed point theorem with parameters gives

\[
\varepsilon\mapsto h_\varepsilon
\]

with regularity determined by the parameter-bunching conditions. In the standard case, one obtains parameter regularity up to the same order allowed by the bunching.

This is essential for singular perturbation applications, where one often needs expansions

\[
h_\varepsilon
=
h_0+\varepsilon h_1+\cdots+\varepsilon^k h_k+O(\varepsilon^{k+1}).
\]

Those expansions are obtained by differentiating the invariant-section equation with respect to \(\varepsilon\).

---

# 13. Summary of Step 2

We have established the nonlinear invariant-section theorem.

The key points are:

1. The fixed point is not taken in Lipschitz norm.
2. The admissible class is a \(C^0\)-complete space of Lipschitz sections.
3. The graph transform is a contraction in the \(C^0\) metric.
4. The Lipschitz bound is preserved separately by cone invariance.
5. Higher regularity is obtained by lifting the graph transform to jet bundles and using the bunching assumptions.
6. Quantitative \(O(\varepsilon)\) estimates follow from uniform jet contraction estimates.
7. Parameter dependence follows from the parameterized version of the same theorem.

This completes the nonlinear core of Fenichel theory.

---

# Next step

The next step is **Step 3: Derivation of Fenichelâs theorem**.

In Step 3, I will:

1. apply the invariant-section theorem to the tubular-coordinate map \(F_\varepsilon\);
2. construct \(M_\varepsilon\), \(K_\varepsilon\), and \(f_\varepsilon\);
3. prove invariance under the original map, including the iterate lemma;
4. prove that \(f_\varepsilon\) is a diffeomorphism;
5. prove persistence of the normal splitting;
6. state and prove the correct quantitative \(C^r\) closeness estimates.## Step 4: Stable/unstable fibres, foliations, and flow reduction

This is the final step in the compact invertible Banach-space proof. We now construct the strong stable and strong unstable fibres, state their regularity correctly, and then reduce flows to time-\(T\) maps.

---

# 1. Setup after persistence

From Step 3, we have a persisted \(C^r\) normally hyperbolic manifold

\[
M_\varepsilon
\]

and a persisted invariant splitting along \(M_\varepsilon\):

\[
T_{p}X
=
T_{p}M_\varepsilon
\oplus
E^s_{\varepsilon,p}
\oplus
E^u_{\varepsilon,p}.
\]

The linearized dynamics along \(M_\varepsilon\) satisfies exponential estimates. To construct strong stable and unstable fibres, we need explicit rate-gap assumptions.

For \(p\in M_\varepsilon\), write

\[
p_n=F_\varepsilon^n(p).
\]

Let

\[
A_n:=DF_\varepsilon(p_n).
\]

The linear cocycle \(A_n\) preserves the splitting

\[
T_{p_n}X
=
T_{p_n}M_\varepsilon
\oplus
E^s_{\varepsilon,p_n}
\oplus
E^u_{\varepsilon,p_n}.
\]

---

# 2. Strong stable fibres

To construct the strong stable fibre through \(p\in M_\varepsilon\), group the tangent directions as

\[
T_{p_n}X
=
E^s_{\varepsilon,p_n}
\oplus
E^{cu}_{\varepsilon,p_n},
\]

where

\[
E^{cu}_{\varepsilon,p_n}
:=
T_{p_n}M_\varepsilon
\oplus
E^u_{\varepsilon,p_n}.
\]

This is the center-unstable complement.

Assume there are constants \(C>0\), \(\alpha_s>0\), and \(\beta_{cu}\ge0\) such that the linear evolution satisfies

\[
\|\Phi_\varepsilon^s(n,k)\|
\le
C e^{-\alpha_s(n-k)},
\qquad
n\ge k,
\]

and

\[
\|\Phi_\varepsilon^{cu}(n,k)\|
\le
C e^{\beta_{cu}(k-n)},
\qquad
n\le k.
\]

Here:

- \(\Phi_\varepsilon^s(n,k)\) is the stable evolution from time \(k\) to time \(n\);
- \(\Phi_\varepsilon^{cu}(n,k)\) is the backward center-unstable evolution from time \(k\) to time \(n\), defined for \(n\le k\).

The crucial strong stable gap assumption is

\[
\beta_{cu}<\alpha_s.
\]

This says that stable contraction forward in time dominates the possible backward growth of the center-unstable complement.

---

## 2.1. Moving coordinates

Work in a tubular neighbourhood of \(M_\varepsilon\), straightened so that \(M_\varepsilon\) is the zero section. Along the orbit \(p_n\), choose moving coordinates so that a nearby point is written as

\[
p_n+\xi_n,
\]

with

\[
\xi_n\in T_{p_n}X.
\]

Decompose

\[
\xi_n
=
\xi_n^s+\xi_n^{cu},
\]

with

\[
\xi_n^s\in E^s_{\varepsilon,p_n},
\qquad
\xi_n^{cu}\in E^{cu}_{\varepsilon,p_n}.
\]

The nonlinear variational equation has the form

\[
\xi_{n+1}
=
A_n\xi_n+R_n(\xi_n),
\]

where

\[
R_n(0)=0,
\qquad
DR_n(0)=0.
\]

Because \(F_\varepsilon\) is \(C^r\), the remainder satisfies, for small \(\xi\),

\[
\|R_n(\xi)\|
\le
C\|\xi\|^2,
\]

and

\[
\|DR_n(\xi)\|
\le
C\|\xi\|.
\]

---

## 2.2. Weighted sequence space

Choose a weight exponent \(\gamma\) such that

\[
\beta_{cu}<\gamma<\alpha_s.
\]

Define the weighted space

\[
\ell_\gamma^+
:=
\left\{
(\xi_n)_{n\ge0}:
\|\xi\|_\gamma
:=
\sup_{n\ge0} e^{\gamma n}\|\xi_n\|
<\infty
\right\}.
\]

This space is a Banach space.

The weight \(e^{\gamma n}\) encodes the requirement that \(\xi_n\) decays at least like \(e^{-\gamma n}\).

---

# 3. Perron operator for the strong stable fibre

Fix a stable coordinate

\[
a\in E^s_{\varepsilon,p_0}.
\]

We will construct the unique forward orbit with asymptotic phase \(p_0\) and stable coordinate \(a\).

Define the Perron operator \(\mathcal P_a\) on sequences \(\xi=(\xi_n)_{n\ge0}\) by

\[
(\mathcal P_a\xi)_n
=
(\mathcal P_a\xi)_n^s
+
(\mathcal P_a\xi)_n^{cu},
\]

where

\[
\boxed{
(\mathcal P_a\xi)_n^s
=
\Phi_\varepsilon^s(n,0)a
+
\sum_{k=0}^{n-1}
\Phi_\varepsilon^s(n,k+1)
P^s_{k+1}
R_k(\xi_k),
}
\]

and

\[
\boxed{
(\mathcal P_a\xi)_n^{cu}
=
-
\sum_{k=n}^{\infty}
\Phi_\varepsilon^{cu}(n,k+1)
P^{cu}_{k+1}
R_k(\xi_k).
}
\]

Here \(P^s_{k+1}\) and \(P^{cu}_{k+1}\) are the projections onto \(E^s_{\varepsilon,p_{k+1}}\) and \(E^{cu}_{\varepsilon,p_{k+1}}\).

This operator simultaneously solves for:

- the stable displacement;
- the center displacement;
- the unstable displacement.

It does not freeze the center orbit. The center component is part of \(\xi_n^{cu}\), and the future boundary condition determines it.

---

# 4. Contraction estimate

We show that \(\mathcal P_a\) is a contraction on a small ball in \(\ell_\gamma^+\).

Let

\[
B_r
:=
\{\xi\in\ell_\gamma^+:\|\xi\|_\gamma\le r\}.
\]

Assume \(\|a\|\) is small. We estimate \(\|\mathcal P_a\xi\|_\gamma\).

## 4.1. Stable homogeneous term

For the first term,

\[
e^{\gamma n}
\|\Phi_\varepsilon^s(n,0)a\|
\le
C e^{\gamma n}e^{-\alpha_s n}\|a\|
=
C e^{-(\alpha_s-\gamma)n}\|a\|.
\]

Since \(\gamma<\alpha_s\),

\[
\sup_{n\ge0}
e^{\gamma n}
\|\Phi_\varepsilon^s(n,0)a\|
\le
C\|a\|.
\]

## 4.2. Stable nonlinear sum

Suppose \(\|\xi\|_\gamma\le r\). Then

\[
\|\xi_k\|
\le
r e^{-\gamma k}.
\]

Because \(R_k(\xi_k)=O(\|\xi_k\|^2)\),

\[
\|R_k(\xi_k)\|
\le
C r^2 e^{-2\gamma k}.
\]

Therefore,

\[
e^{\gamma n}
\left\|
\sum_{k=0}^{n-1}
\Phi_\varepsilon^s(n,k+1)
P^s_{k+1}R_k(\xi_k)
\right\|
\]

is bounded by

\[
C r^2
e^{\gamma n}
\sum_{k=0}^{n-1}
e^{-\alpha_s(n-k-1)}
e^{-2\gamma k}.
\]

Factor out \(e^{-\gamma n}\). Since \(\gamma<\alpha_s\), the remaining convolution sum is uniformly bounded. Hence

\[
\left\|
\sum_{k=0}^{n-1}
\Phi_\varepsilon^s(n,k+1)
P^s_{k+1}R_k(\xi_k)
\right\|_\gamma
\le
C r^2.
\]

## 4.3. Center-unstable nonlinear sum

For the center-unstable part,

\[
e^{\gamma n}
\left\|
\sum_{k=n}^{\infty}
\Phi_\varepsilon^{cu}(n,k+1)
P^{cu}_{k+1}R_k(\xi_k)
\right\|
\]

is bounded by

\[
C r^2
e^{\gamma n}
\sum_{k=n}^{\infty}
e^{\beta_{cu}(k+1-n)}
e^{-2\gamma k}.
\]

Write \(k=n+j\). Then the sum becomes

\[
C r^2
e^{\gamma n}
\sum_{j=0}^{\infty}
e^{\beta_{cu}(j+1)}
e^{-2\gamma(n+j)}.
\]

This equals

\[
C r^2
e^{-\gamma n}
\sum_{j=0}^{\infty}
e^{(\beta_{cu}-2\gamma)j}.
\]

Because \(\beta_{cu}<\gamma\), we have \(\beta_{cu}-2\gamma<0\). Hence the sum converges uniformly, and

\[
\left\|
(\mathcal P_a\xi)^{cu}
\right\|_\gamma
\le
C r^2.
\]

Thus,

\[
\|\mathcal P_a\xi\|_\gamma
\le
C\|a\|+C r^2.
\]

Choosing \(r\) small and \(\|a\|\le c r\) with \(c\) small, we get

\[
\mathcal P_a(B_r)\subset B_r.
\]

## 4.4. Lipschitz contraction

For \(\xi,\eta\in B_r\),

\[
R_k(\xi_k)-R_k(\eta_k)
=
O(r)\|\xi_k-\eta_k\|.
\]

Repeating the same convolution estimates gives

\[
\|\mathcal P_a\xi-\mathcal P_a\eta\|_\gamma
\le
C r\|\xi-\eta\|_\gamma.
\]

Choosing \(r\) small enough gives

\[
C r<1.
\]

Thus \(\mathcal P_a\) is a contraction on \(B_r\).

By the Banach fixed point theorem, there is a unique fixed point

\[
\xi(a)\in B_r
\]

such that

\[
\mathcal P_a\xi(a)=\xi(a).
\]

---

# 5. Definition of the local strong stable fibre

The local strong stable fibre through \(p_0\in M_\varepsilon\) is defined by

\[
W^s_{\mathrm{loc}}(p_0)
:=
\left\{
p_0+\xi_0(a):
a\in E^s_{\varepsilon,p_0},
\ \|a\|\text{ sufficiently small}
\right\}.
\]

The map

\[
a\mapsto p_0+\xi_0(a)
\]

parametrizes the fibre.

By construction, if \(y\in W^s_{\mathrm{loc}}(p_0)\), then the forward orbit of \(y\) remains near the orbit of \(p_0\) and converges to it at an exponential rate determined by \(\gamma\).

The fibre is tangent to \(E^s_{\varepsilon,p_0}\) at \(p_0\).

---

# 6. Regularity of strong stable leaves

The internal regularity of the stable leaf is obtained by differentiating the Perron operator with respect to the fibre coordinate \(a\).

For \(C^\ell\) internal regularity, one needs stronger bunching assumptions. A typical sufficient condition is

\[
\alpha_s>\ell\,\beta_{cu}.
\]

More invariantly, one requires the induced \(\ell\)-jet Perron operator to be contractive. This is the strong stable bunching condition.

The proof proceeds by induction:

1. the zeroth-order Perron operator gives continuous leaves;
2. differentiating once gives a linear Perron operator on first variations;
3. the first variation operator is contractive if \(\alpha_s>\beta_{cu}\);
4. higher derivatives require contraction of induced jet operators;
5. the nonlinear Faà di Bruno terms are controlled by lower-order derivatives.

Thus, under the appropriate strong stable bunching assumptions, the stable leaves are \(C^\ell\) in their internal fibre coordinate.

---

# 7. Transverse regularity and phase projection

One must distinguish several different regularities:

1. regularity of each stable leaf in its internal coordinate;
2. regularity of the leaf as a function of the base point \(p\in M_\varepsilon\);
3. regularity of the asymptotic phase projection

   \[
   \pi^s:W^s_{\mathrm{loc}}(M_\varepsilon)\to M_\varepsilon;
   \]

4. regularity of the total lamination.

The Perron construction above gives internal leaf regularity under strong stable bunching. Transverse regularity requires additional assumptions because the base point \(p\) enters the Perron operator through the reference orbit \(p_n=F_\varepsilon^n(p)\).

In particular, the stable foliation is not automatically \(C^r\) transversely. The correct statement is:

- stable leaves have the internal regularity allowed by strong stable bunching;
- dependence on the base point is continuous, and often Hölder, under basic normal hyperbolicity;
- higher transverse regularity requires explicit transverse bunching inequalities;
- regularity of the phase map requires its own bunching conditions.

Thus the stable foliation should be stated as a lamination with separately specified regularity.

---

# 8. Global stable manifold

The local stable fibre can be extended globally by iteration, as long as orbits remain in the tubular neighbourhood where the construction is valid.

Define

\[
W^s(M_\varepsilon)
:=
\left\{
y:
F_\varepsilon^n(y)\text{ remains near }M_\varepsilon
\text{ for all }n\ge0,
\text{ and approaches }M_\varepsilon
\right\}.
\]

Locally,

\[
W^s(M_\varepsilon)
=
\bigcup_{p\in M_\varepsilon}
W^s_{\mathrm{loc}}(p).
\]

The invariance property is

\[
F_\varepsilon(W^s(M_\varepsilon))
\subset
W^s(M_\varepsilon).
\]

If \(F_\varepsilon\) is a diffeomorphism, this is usually an equality on the locally defined stable manifold.

---

# 9. Strong unstable fibres

The unstable fibres are obtained by applying the stable construction to the inverse map \(F_\varepsilon^{-1}\).

Along \(M_\varepsilon\), group the tangent directions as

\[
T_{p_n}X
=
E^u_{\varepsilon,p_n}
\oplus
E^{cs}_{\varepsilon,p_n},
\]

where

\[
E^{cs}_{\varepsilon,p_n}
:=
T_{p_n}M_\varepsilon
\oplus
E^s_{\varepsilon,p_n}.
\]

Assume there are constants \(\alpha_u>0\) and \(\beta_{cs}\ge0\) such that the backward unstable evolution contracts with rate \(\alpha_u\), while the forward center-stable complement grows backward at rate at most \(\beta_{cs}\). The strong unstable gap assumption is

\[
\beta_{cs}<\alpha_u.
\]

The Perron operator is defined on negative time sequences. For \(b\in E^u_{\varepsilon,p_0}\), one solves

\[
\xi_{n-1}
=
A_{n-1}^{-1}\xi_n
+
\widetilde R_n(\xi_n),
\qquad
n\le0,
\]

with appropriate weighted estimates as \(n\to-\infty\).

Equivalently, apply the stable Perron construction to \(F_\varepsilon^{-1}\). This gives local strong unstable fibres

\[
W^u_{\mathrm{loc}}(p_0),
\]

tangent to \(E^u_{\varepsilon,p_0}\) at \(p_0\).

The regularity statements are analogous: internal regularity requires strong unstable bunching; transverse regularity requires separate assumptions.

---

# 10. Flow reduction

Now suppose the original object is not a map but a genuine local flow

\[
\Phi_t^\varepsilon,
\qquad
t\in\mathbb R,
\]

of class \(C^{r+1}\), defined on a neighbourhood of \(M\). Assume that the unperturbed flow leaves \(M\) invariant for all time:

\[
\Phi_t^0(M)=M,
\qquad
t\in\mathbb R.
\]

This assumption is important. It is not enough to know that \(M\) is invariant under a single time-\(T\) map.

Choose \(T>0\) large enough that the time-\(T\) map

\[
F_\varepsilon:=\Phi_T^\varepsilon
\]

satisfies the bunching assumptions required in Steps 2 and 3. Applying the map theorem gives a manifold \(M_\varepsilon\) invariant under \(F_\varepsilon\).

We now prove invariance under the full flow.

For \(0\le t\le T\), define

\[
N_t:=\Phi_t^\varepsilon(M_\varepsilon).
\]

Because the flow maps commute,

\[
F_\varepsilon(N_t)
=
\Phi_T^\varepsilon\Phi_t^\varepsilon(M_\varepsilon)
=
\Phi_t^\varepsilon\Phi_T^\varepsilon(M_\varepsilon)
=
\Phi_t^\varepsilon(M_\varepsilon)
=
N_t.
\]

Thus \(N_t\) is invariant under the time-\(T\) map.

For sufficiently small \(\varepsilon\), and uniformly for \(t\in[0,T]\), the manifold \(N_t\) remains in the same admissible tube and satisfies the same Lipschitz/cone bounds. This follows from the continuity of the flow in \(t\) and the \(C^1\)-closeness of \(\Phi_t^\varepsilon\) to \(\Phi_t^0\) on compact time intervals.

By the local uniqueness part of the HPS theorem,

\[
N_t=M_\varepsilon.
\]

Therefore,

\[
\Phi_t^\varepsilon(M_\varepsilon)=M_\varepsilon,
\qquad
0\le t\le T.
\]

By the flow property, invariance extends to all \(t\in\mathbb R\).

This proves the flow version.

---

# 11. Why the full-flow invariance assumption is necessary

Suppose one only knows that

\[
\Phi_T^0(M)=M
\]

for some fixed \(T\), but not that \(M\) is invariant under the full unperturbed flow. Then for \(t\in(0,T)\), the set

\[
\Phi_t^0(M)
\]

may not be close to \(M\). In that case, the uniqueness argument for

\[
N_t=\Phi_t^\varepsilon(M_\varepsilon)
\]

fails, because \(N_t\) may not lie in the admissible tube around \(M\).

Thus, for the time-map reduction, one must assume either:

1. \(M\) is invariant under the full unperturbed flow; or
2. one constructs \(M_\varepsilon\) directly using a continuous-time LyapunovPerron method.

---

# 12. Relation to singular perturbation problems

In singular perturbation applications, one often has a fast-slow system. In finite dimensions, a typical form is

\[
\begin{aligned}
\dot x &= f(x,y,\varepsilon),\\
\dot y &= \varepsilon g(x,y,\varepsilon).
\end{aligned}
\]

The critical manifold is

\[
M_0=\{f(x,y,0)=0\}.
\]

Normal hyperbolicity of \(M_0\) means that the fast linearization

\[
D_x f(x,y,0)
\]

has spectrum bounded away from the imaginary axis. In the infinite-dimensional setting, the analogous condition is that the fast linear operator generates a uniform exponential dichotomy.

The Fenichel theorem then gives a perturbed slow manifold

\[
M_\varepsilon
\]

near \(M_0\). The reduced dynamics on \(M_\varepsilon\) is obtained by restricting the full system to \(M_\varepsilon\). If \(M_\varepsilon\) is written as a graph

\[
x=h_\varepsilon(y),
\]

then the reduced equation is exactly

\[
\dot y
=
\varepsilon g(h_\varepsilon(y),y,\varepsilon).
\]

Approximations such as

\[
\dot y
=
\varepsilon g(h_0(y),y,0)+O(\varepsilon^2)
\]

arise after expanding \(h_\varepsilon\) in \(\varepsilon\). The parameter dependence proved in Step 3 justifies such expansions when the perturbation is smooth in \(\varepsilon\).

---

# 13. What is not covered by this theorem

The proof given in Steps 14 covers the clean compact invertible case:

- compact finite-dimensional NHIM;
- Banach-space local diffeomorphisms;
- genuine flows via time maps;
- infinite-dimensional stable/unstable fibres;
- finite \(C^r\) regularity under explicit bunching.

It does **not** by itself cover:

1. noninvertible parabolic semiflows;
2. unbounded linear generators;
3. quasilinear PDEs;
4. derivative-loss problems;
5. noncompact NHIMs;
6. Banach-dimensional NHIMs;
7. delay equations without an evolution-space formulation;
8. random or nonautonomous cocycles.

Those settings require separate versions of the LyapunovPerron machinery.

---

# 14. The parabolic semiflow case: what changes

For semilinear parabolic equations, one often has an equation of the form

\[
u_t=Au+f(u,v),
\]

where \(A\) is sectorial and unbounded. The associated semiflow is usually smoothing and noninvertible.

In that setting:

- the vector field is not a bounded \(C^r\) vector field on the phase space;
- time-\(t\) maps are not local Banach-space diffeomorphisms;
- unstable directions must be treated through backward solvability of the linear unstable cocycle;
- one needs a Banach scale

  \[
  X_1\hookrightarrow X_\theta\hookrightarrow X_0;
  \]

- exponential dichotomies must be obtained from uniform resolvent or semigroup estimates, not merely from pointwise spectral separation;
- the Perron method is performed in weighted trajectory spaces adapted to the analytic semigroup.

A correct parabolic Fenichel theorem therefore has a different form. The overall strategy remains the same  exponential dichotomy, Perron operator, contraction, jet regularity  but the functional framework is substantially different.

---

# 15. Completion of the proof

We have now completed the four steps of the proof.

## Step 1

We proved the linear cohomological inverse theorem:

\[
\mathcal A\zeta=\zeta\circ f-B\zeta
\]

is invertible on \(C^0\), and under bunching on \(C^k\), using the Green operator associated with the exponential dichotomy.

## Step 2

We proved the nonlinear HPS invariant-section theorem:

- admissible class with \(C^0\) metric;
- Hadamard graph transform;
- \(C^0\) contraction;
- separate Lipschitz cone invariance;
- jet extension giving \(C^r\) regularity;
- parameter dependence and quantitative estimates.

## Step 3

We derived Fenichel persistence:

- construction of \(M_\varepsilon\);
- invariance;
- iterate lemma;
- proof that \(f_\varepsilon\) is a diffeomorphism;
- quantitative \(O(\varepsilon)\) estimates;
- persistence of the splitting;
- local uniqueness.

## Step 4

We constructed stable and unstable fibres:

- strong stable Perron operator;
- correct center-unstable complement;
- weighted contraction estimates;
- internal and transverse regularity stated separately;
- unstable fibres by inversion;
- flow reduction under full-flow invariance.

This completes the rigorous proof of the compact invertible Banach-space Fenichel theorem.

---

# Final statement

The compact invertible infinite-dimensional Fenichel theorem is therefore proved by the following chain:

\[
\text{Exponential dichotomy}
\quad\Longrightarrow\quad
\text{Green inverse}
\quad\Longrightarrow\quad
\text{HPS invariant section}
\quad\Longrightarrow\quad
\text{persisted NHIM}
\quad\Longrightarrow\quad
\text{stable/unstable fibres}.
\]

The essential analytic object is the cohomological operator

\[
\mathcal A\zeta=\zeta\circ f-B\zeta,
\]

and the essential nonlinear mechanism is the HPS graph transform, not a naive contraction in Lipschitz norm.

The proof is infinite-dimensional in the ambient Banach space, but finite-dimensional and compact in the base manifold \(M\). Extensions to noncompact base manifolds, Banach-dimensional manifolds, parabolic semiflows, or unbounded generators require additional uniformity and regularity machinery, but they follow the same conceptual architecture.