from pathlib import Path
p=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
s=p.read_text()
old='''Because \\(D_\\eta b_\\varepsilon\\) is small and \\(h\\) is Lipschitz with small aperture, \\(b_h\\) is a \\(C^1\\) local diffeomorphism close to \\(f\\). By the compact-manifold lemma, \\(b_h\\) is a global diffeomorphism. Define the graph transform by'''
new='''Because \\(h\\) is initially only Lipschitz, \\(b_h\\) should not be called a \\(C^1\\) local diffeomorphism at this stage. Instead, in local charts write \\(b_h=f+e_h\\). The estimates on \\(D_\\eta b_\\varepsilon\\), together with the small Lipschitz aperture of \\(h\\) and the \\(C^1\\)-closeness of \\(b_\\varepsilon(\\cdot,0)\\) to \\(f\\), give

\\[
\\operatorname{Lip}(f^{-1}\\circ b_h-\\operatorname{id})
\\le \\mu(\\rho,L,\\delta_\\varepsilon)<1.
\\]

Thus \\(f^{-1}\\circ b_h\\) is a bi-Lipschitz homeomorphism by the contraction mapping theorem applied to the equation \\(x+(f^{-1}\\circ b_h-\\operatorname{id})(x)=y\\). Hence \\(b_h\\) is a bi-Lipschitz homeomorphism close to \\(f\\), with a uniformly Lipschitz inverse. Once the fixed point has been upgraded to \\(C^r\\), the corresponding map \\(b_{h_\\varepsilon}\\) is a \\(C^r\\) diffeomorphism. Define the graph transform by'''
assert old in s
s=s.replace(old,new)
old2='''Using the base and fibre derivative estimates for the remainder,'''
new2='''Using transported difference estimates for the linear part and the base and fibre derivative estimates for the remainder,'''
s=s.replace(old2,new2)
out=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
