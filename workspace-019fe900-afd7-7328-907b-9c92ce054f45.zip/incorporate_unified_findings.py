from pathlib import Path
src = Path('/home/user/final_manuscript_newly_revised.md')
s = src.read_text()

# 1. Schematic graph-transform contraction factor and radius preservation estimate.
old = '''The graph transform acts as a contraction in the \\(C^0\\) graph metric, not in the Lipschitz norm. The \\(C^0\\) graph distance is measured by the maximal transported vertical separation after the center coordinates have been matched. This is the metric in which the normal hyperbolicity gap gives contraction. The Lipschitz bound is preserved separately by cone invariance. Thus the fixed point is obtained in the complete metric space \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric, while the cone estimates ensure that the transform maps \\(\\mathcal B_{\\rho,L}\\) into itself.

The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense.'''
new = '''The graph transform acts as a contraction in the \\(C^0\\) graph metric, not in the Lipschitz norm. The \\(C^0\\) graph distance is measured by the maximal transported vertical separation after the center coordinates have been matched. This is the metric in which the normal hyperbolicity gap gives contraction. Schematically, after passing to an iterate if necessary, the contraction factor has the form

\\[
q
\\le
C\\left(
e^{-\\mathrm{gap}\,N}
+\\delta_\\varepsilon
+\\omega(\\rho)
+L
\\right),
\\]

where the first term comes from the strict normal-hyperbolicity gap and the remaining terms come from perturbation size, tube radius, and cone aperture. Choosing the constants in the order described above gives \\(q<1\\). The \\(C^0\\) radius is preserved by an estimate of the form

\\[
\\|\\mathcal H_\\varepsilon h\\|_{C^0}
\\le
C\\delta_\\varepsilon+q\\rho.
\\]

After choosing \\(q<1\\), one chooses \\(\\delta_\\varepsilon\\) small enough so that the right-hand side is at most \\(\\rho\\). The Lipschitz bound is preserved separately by cone invariance. Thus the fixed point is obtained in the complete metric space \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric, while the cone estimates ensure that the transform maps \\(\\mathcal B_{\\rho,L}\\) into itself.

The Hadamard graph transform should be understood in the two-sided normally hyperbolic sense.'''
assert old in s
s = s.replace(old, new)

# 2. Negative-time unstable Perron equation.
old = '''The Perron construction on negative time then gives local strong unstable fibres

\\[
W^u_{\\mathrm{loc}}(p),
\\]

tangent to \\(E^u_{\\varepsilon,p}\\) at \\(p\\).'''
new = '''The Perron construction on negative time then gives local strong unstable fibres

\\[
W^u_{\\mathrm{loc}}(p),
\\]

tangent to \\(E^u_{\\varepsilon,p}\\) at \\(p\\). Equivalently, for \\(b\\in E^u_{\\varepsilon,p}\\), one solves a negative-time Perron equation of the form

\\[
\\xi_{n-1}
=
A_{n-1}^{-1}\\xi_n
+
\\widetilde R_n(\\xi_n),
\\qquad n\\le0,
\\]

in a weighted space as \\(n\\to-\\infty\\). Internal and transverse regularity require the unstable analogues of the stable bunching assumptions.'''
assert old in s
s = s.replace(old, new)

# 3. Short parabolic caveat about time maps.
old = '''These smoothing estimates are part of the functional framework and replace the bounded-map estimates used in the compact invertible theorem. Consider a semilinear parabolic fast-slow system of the form'''
new = '''These smoothing estimates are part of the functional framework and replace the bounded-map estimates used in the compact invertible theorem. Unlike the compact invertible map setting, the vector field is typically not a bounded \\(C^r\\) vector field on the base phase space, and the time-\\(t\\) maps are not local Banach-space diffeomorphisms. Unstable directions must therefore be handled through backward solvability of the unstable linear cocycle, not by inverting the full semiflow. Consider a semilinear parabolic fast-slow system of the form'''
assert old in s
s = s.replace(old, new)

# 4. Random pathwise regularity sentence.
old = '''Measurability follows from measurable selection or from convergence of measurable iterates. In infinite-dimensional random settings, the multiplicative ergodic theorem may be used to verify the dichotomy under compactness or quasi-compactness assumptions; see Ruelle [7]. In Banach spaces this typically also requires measurability of projections and integrability of logarithmic growth. In many applications one assumes the random dichotomy directly and uses the multiplicative ergodic theorem only as a verification tool.'''
new = '''Measurability follows from measurable selection or from convergence of measurable iterates. In infinite-dimensional random settings, the multiplicative ergodic theorem may be used to verify the dichotomy under compactness or quasi-compactness assumptions; see Ruelle [7]. In Banach spaces this typically also requires measurability of projections and integrability of logarithmic growth. In many applications one assumes the random dichotomy directly and uses the multiplicative ergodic theorem only as a verification tool. Pathwise regularity follows from the same jet-extension argument, provided the bunching inequalities hold pathwise or in a tempered sense. Measurable or \\(L^p\\) dependence on \\(\\omega\\) requires additional estimates.'''
assert old in s
s = s.replace(old, new)

# 5. Nash-Moser mechanism list.
old = '''or in Hölder spaces adapted to the interpolation scale. If smoothing is unavailable, a Nash–Moser scheme may be required; see Hamilton [8].

An alternative formulation uses topological jets or difference quotients.'''
new = '''or in Hölder spaces adapted to the interpolation scale. If smoothing is unavailable, a Nash–Moser scheme may be required; see Hamilton [8]. In such a scheme, the linearized operator has a tame inverse with derivative loss, the nonlinear remainder is tame, smoothing operators are inserted at each Newton step, tame estimates control the loss, and convergence is obtained in a lower regularity category.

An alternative formulation uses topological jets or difference quotients.'''
assert old in s
s = s.replace(old, new)

out = Path('/home/user/final_manuscript_full_revised.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
