# Remnants and Redundancy Scan

File scanned: `/home/user/journal_manuscript_integrated_v2.md`

## Executive summary

No severe mathematical remnants were found. The manuscript is clean of meta-audit language and previous false claims. Main remaining issues are editorial redundancy and one wording point around the residual fixed-point equation.

## Findings
### ⚠️ Duplicate HPS-import explanation
- Severity: **medium**
- Status: redundant
- Evidence: Section 4 explains Theorem 4.1 as structural HPS input after the theorem, then later repeats that it is the imported HPS mechanism.
- Recommendation: Delete or compress the later “Thus Theorem 4.1...” paragraph; the first paragraph plus Appendix J already carry the point.

### ⚠️ Residual fixed-point equation may imply direct contraction
- Severity: **medium**
- Status: needs qualification
- Evidence: Section 4 states “Thus the fixed-point problem is h=-G N(h)”. This is algebraically correct but can suggest the wrong contraction mechanism.
- Recommendation: Change to “The residual equation can be written formally as...” and reiterate that the contraction is the HPS graph transform, not direct Lipschitz contraction of -G N.

### ℹ️ Appendix cross-reference density
- Severity: **low**
- Status: style redundancy
- Evidence: Main text mentions appendices A–K repeatedly; summary has a long one-sentence appendix list.
- Recommendation: Keep useful references, but split the summary appendix list into bullets or shorten it.

### ℹ️ Section 3 and Appendix A overlap
- Severity: **low**
- Status: intentional redundancy
- Evidence: Section 3 proves much of the cohomological inverse and Appendix A repeats the smooth-splitting proof.
- Recommendation: Acceptable. For streamlining, Section 3 could prove C0 and outline Ck, with full proof in Appendix A.

### ℹ️ Extension and open-problem overlap
- Severity: **low**
- Status: productive redundancy
- Evidence: Section 8 states conditional extensions; Section 9 repeats future directions.
- Recommendation: Acceptable. Add a transition from Section 8 to Section 9 if desired.

### ✅ Forbidden/remnant meta phrases
- Severity: **none**
- Status: pass
- Evidence: []
- Recommendation: No action needed.

### ✅ Broken math line artifacts
- Severity: **none**
- Status: pass
- Evidence: []
- Recommendation: No action needed.

### ⚠️ External HPS citation lacks theorem number
- Severity: **medium**
- Status: publication-prep gap
- Evidence: Appendix J cites HPS/Bates–Lu/Bates–Lu–Zeng structurally but does not identify exact theorem numbers.
- Recommendation: Before submission, verify bibliographic details and add theorem/proposition numbers if available. Do not invent them.

### ℹ️ Title/content alignment
- Severity: **low**
- Status: good
- Evidence: Title emphasizes cohomological inverses and fractional jet spectra, matching the real novelty.
- Recommendation: No action needed.

## Minimal cleanup recommended

1. Remove or compress the duplicate paragraph beginning “Thus Theorem 4.1 is the imported HPS mechanism...”.
2. Change “Thus the fixed-point problem is” to “The residual equation can be written formally as”.
3. Optionally convert the long appendix list in the summary into bullets or shorten it.
4. Add exact theorem numbers for the imported HPS/Banach theorem before submission, if a precise source match is available.