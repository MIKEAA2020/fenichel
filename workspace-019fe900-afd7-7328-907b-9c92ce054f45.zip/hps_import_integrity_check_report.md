# HPS Import Integrity Check

Manuscript: `/home/user/final_manuscript_hps_import_verified.md`

Overall: **PASS**

- ✅ **display_balanced** — 459 vs 459
- ✅ **inline_balanced** — 837 vs 837
- ✅ **env_balanced** — (['pmatrix', 'aligned', 'aligned', 'aligned', 'pmatrix', 'aligned'], ['pmatrix', 'aligned', 'aligned', 'aligned', 'pmatrix', 'aligned'])
- ✅ **absent_maps center cones ** — maps center cones strictly
- ✅ **absent_follows by the sam** — follows by the same argument
- ✅ **absent_Your assessment** — Your assessment
- ✅ **absent_Final honest** — Final honest
- ✅ **absent_What has been repa** — What has been repaired
- ✅ **absent_invalid Lipschitz** — invalid Lipschitz
- ✅ **absent_false Lipschitz** — false Lipschitz
- ✅ **present_full two-sided HPS Had** — full two-sided HPS Hadamard graph transform
- ✅ **present_not the separate stabl** — not the separate stable-forward/unstable-backward component transform
- ✅ **present_component equations al** — component equations alone do not imply invariance
- ✅ **present_Affine examples can sa** — Affine examples can satisfy
- ✅ **present_simultaneous admissibl** — simultaneous admissible matching
- ✅ **present_Appendix I. Uniform co** — Appendix I. Uniform cohomological inverses on noncompact bases