# Evaluation of the Proposed Fractional Jet-Spectrum Upgrade

## Verdict

The proposed direction is promising, but the theorem as stated should **not** be inserted verbatim. It is stronger than what the displayed hypotheses justify. The basic idea—replace integer one-step bunching by a real-order Hölder/jet growth spectrum and add periodic resonance obstructions—is a plausible route to a genuine research contribution. However, the current formulation misses several terms that appear in Hölder estimates for iterated jet cocycles, and the periodic obstruction statement needs a triangular full-jet formulation.

A corrected version is possible, but it should use the **operator norm of the induced jet transfer operators on Hölder sections**, rather than only the pointwise product

\[
\|\Phi(n,0)\|\,\|Df^{-n}\|^k\operatorname{Lip}(f^{-n})^\alpha.
\]

That product controls only the principal Hölder term. It does not by itself control the Hölder variation of the iterated derivative factors, the projections, or the cocycle products.

---

## 1. Main problem with the proposed \(\Xi_s^\pm\)

The proposed stable growth sequence is

\[
\Xi_s^+(n)
=
\sup_m
\|\Phi^s(n,0;m)\|
\|Df^{-n}(f^n m)\|^k
\operatorname{Lip}(f^{-n})^\alpha.
\]

This is the correct principal scaling for the Hölder seminorm of

\[
J\mapsto
\Phi^s(n,0)J\circ(Df^{-n})^{\otimes k}.
\]

But the full \(C^\alpha\) seminorm of that expression also contains terms coming from:

1. Hölder variation of \(\Phi^s(n,0;m)\);
2. Hölder variation of the projections \(P^s_m,P^u_m\);
3. Hölder variation of \((Df^{-n})^{\otimes k}\);
4. lower-order Faà di Bruno terms for the differentiated equation;
5. connection and chart-transport terms.

For example, when \(k=1\), comparing

\[
\Phi^s(n,0;x)J(f^{-n}x)Df^{-n}(x)
\]

with the same expression at \(y\) gives not only

\[
[J]_\alpha\operatorname{Lip}(f^{-n})^\alpha
\|Df^{-n}\|\|\Phi^s(n,0)\|,
\]

but also terms involving

\[
[\Phi^s(n,0)]_\alpha\|J\|_{C^0}\|Df^{-n}\|,
\]

and

\[
\|\Phi^s(n,0)\|\|J\|_{C^0}[Df^{-n}]_\alpha.
\]

These quantities may grow faster than the proposed \(\Xi_s^+(n)\). Therefore \(\rho_s<1\), as currently defined, is not sufficient for the claimed \(C^{k,\alpha}\) boundedness unless additional bounded-distortion estimates are assumed.

---

## 2. Regularity range needs correction

The data are assumed to be \(C^{r+1,\beta}\) for the base and \(C^{r,\beta}\) for the bundle automorphism. If the target space is \(C^{k,\alpha}\), then one needs

\[
k+\alpha\le r+\beta.
\]

In particular, if \(k=r\), then one must require

\[
\alpha\le\beta.
\]

The statement currently allows arbitrary \(0<\alpha<1\) with \(k=r\), which is too strong when \(\beta<\alpha\).

---

## 3. The Hölder Green lemma is under-assumed

Lemma B claims that the Green operator is bounded on \(C^\alpha\) if

\[
\sup_m\|C^s(n,0;m)\|\operatorname{Lip}(f^{-n})^\alpha
\le K\vartheta^n
\]

and similarly backward. This controls the term involving the Hölder seminorm of the forcing. It does not control the Hölder variation of the cocycle evolution itself unless one assumes an additional estimate such as

\[
\|C^s(n,0;\cdot)\|_{C^\alpha}
\operatorname{Lip}(f^{-n})^0
\le K\vartheta^n,
\]

or, more invariantly, that the induced stable Green summand operators are exponentially summable as operators on \(C^\alpha\) sections.

The proof sketches a telescoping product estimate, but the hypotheses do not provide the bounds needed to close that estimate.

---

## 4. Correct way to formulate the fractional radius

A sound formulation should define the fractional jet radius using **operator norms on Hölder section spaces**.

For the stable part, define the order-\(k,\alpha\) stable transfer operator

\[
\mathcal T_{k,n}^+:
C^\alpha(\mathcal J_k^s)	o C^\alpha(\mathcal J_k^s)
\]

by the transported version of

\[
(\mathcal T_{k,n}^+J)(m)
=
\Phi^s(0,-n;m)
\,J(f^{-n}m)
\circ
(Df^{-n}(m))^{\otimes k},
\]

with the appropriate fibre transports and projections. Similarly define \(\mathcal T_{k,n}^-\) for the unstable backward part.

Then define

\[
\widehat\rho_{k,\alpha}^+
=
\limsup_{n\to\infty}
\|\mathcal T_{k,n}^+\|_{C^\alpha\to C^\alpha}^{1/n},
\]

and

\[
\widehat\rho_{k,\alpha}^-
=
\limsup_{n\to\infty}
\|\mathcal T_{k,n}^-\|_{C^\alpha\to C^\alpha}^{1/n}.
\]

If

\[
\widehat\rho_{k,\alpha}
=
\max\{\widehat\rho_{k,\alpha}^+,\widehat\rho_{k,\alpha}^-\}<1,
\]

then the corresponding Green series is bounded on \(C^\alpha\) jet sections. This definition includes the Hölder variation of the cocycle, projections, derivative iterates, and bundle transports.

This is the right “jet spectrum” object.

---

## 5. Corrected theorem

A defensible theorem is the following.

### Corrected Theorem. Hölder jet-spectrum cohomological inverse

Let \(M\), \(E\), \(f\), and \(B\) be as in the compact Banach-bundle setting, with \(C^{r,\beta}\) splitting and projections. Let \(k+\alpha\le r+\beta\), with \(0<\alpha<1\). Assume the \(C^0\) exponential dichotomy. Let \(\mathcal T_{k,n}^\pm\) be the stable and unstable induced order-\(k\) jet Green summand operators on \(C^\alpha\) jet sections. If

\[
\limsup_{n\to\infty}
\|\mathcal T_{k,n}^+\|_{C^\alpha\to C^\alpha}^{1/n}<1
\]

and

\[
\limsup_{n\to\infty}
\|\mathcal T_{k,n}^-\|_{C^\alpha\to C^\alpha}^{1/n}<1,
\]

then

\[
\mathcal A:C^{k,\alpha}(M,E)	o C^{k,\alpha}(M,f^*E)
\]

is an isomorphism and

\[
\|\mathcal A^{-1}q\|_{C^{k,\alpha}}
\le C_{k,\alpha}
\|q\|_{C^{k,\alpha}}.
\]

The noncompact bounded-geometry version holds with the corresponding uniform \(C_b^\alpha\) operator norms.

This theorem is essentially sharp as a linear statement because the assumed operator radii are exactly the radii of the Green summand operators acting on the Hölder jet bundle.

---

## 6. Periodic resonance obstruction needs a full triangular jet map

The proposed Proposition C is close, but it should use the full triangular return map on jets of order \(\le k\), not only the principal order-\(k\) map, unless lower-order nonresonance has already been assumed.

The issue is that lower-order jets enter the order-\(k\) equation through lower-order terms. If a lower-order resonance is present, the obstruction may occur earlier. To state the clean converse, define the full return map

\[
\mathfrak R_{\le k}(p)
\]

on the finite jet space

\[
\bigoplus_{j=0}^k\operatorname{Sym}^j(T_p^*M;E_p).
\]

This map is triangular, with diagonal blocks equal to the principal \(j\)-jet return maps

\[
\mathscr R_j(p).
\]

### Corrected periodic obstruction

If

\[
I-
\mathfrak R_{\le k}(p)
\]

is not surjective for some periodic point \(p\), then

\[
\mathcal A:C^k(M,E)	o C^k(M,f^*E)
\]

is not surjective.

If all lower-order blocks are nonresonant and

\[
I-
\mathscr R_k(p)
\]

is not surjective, then the same conclusion follows.

This corrected statement avoids the unjustified claim that all lower jets vanish automatically.

---

## 7. Witness-level check of the obstruction

The simplest witness is a two-cycle. Let the normal multiplier be

\[
B_0=B_1=\frac12,
\]

and the tangent derivative be

\[
Df_0=Df_1=\frac12.
\]

The \(C^0\) cohomological matrix is

\[
\begin{pmatrix}
-1/2&1\\
1&-1/2
\end{pmatrix},
\]

whose determinant is

\[
-\frac34\ne0.
\]

So the \(C^0\) equation is invertible. But the first-jet matrix is

\[
\begin{pmatrix}
-1&1\\
1&-1
\end{pmatrix},
\]

whose determinant is zero. This is a periodic jet resonance at order one and obstructs \(C^1\) surjectivity.

This exact witness supports the corrected obstruction theorem.

---

## 8. Recommendation

Do not implement the theorem as originally written. It is under-assumed and could be false in systems with large Hölder distortion of derivative iterates or cocycle products.

A revised research-grade version should:

1. define the fractional jet spectrum by induced operator norms on \(C^\alpha\) jet sections;
2. require \(k+\alpha\le r+\beta\);
3. prove the Hölder Green theorem using those operator norms;
4. state the periodic obstruction using the full triangular jet return map;
5. include the two-cycle resonance witness as a sharpness example.

This corrected version could become a genuine novelty upgrade. The original version should not be inserted verbatim.
