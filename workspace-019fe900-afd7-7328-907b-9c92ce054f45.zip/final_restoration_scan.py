from pathlib import Path
import re, json
final=Path('/home/user/journal_manuscript_integrated.md')
s=final.read_text()
low=s.lower()
items=[]
def item(name,status,recommendation,reason,search_terms=None):
    present={t:(t.lower() in low) for t in (search_terms or [])}
    items.append({'name':name,'status':status,'recommendation':recommendation,'reason':reason,'term_presence':present})

item('Explicit limitations/open problems section','worth restoring','Add a short final section before the appendices or before the summary.','The chat repeatedly distinguished proved modules, imported HPS input, conditional extensions, and open problems. The intro has a claim-status table, but there is no consolidated open-problems section. A concise section would preserve ambitious architecture without overclaiming.',['open problem','conjecture','full Banach-bundle HPS','fractional converse'])
item('Non-reflexive-space clarification for stable fibres','worth restoring','Add a remark in Section 6 or Appendix B: the half-line Perron proof uses Banach fixed-point arguments in complete sequence spaces and does not require reflexivity or weak compactness; this concerns internal leaf regularity only.','This was a recurring audit/theme and is mathematically safe. The current manuscript does not mention non-reflexivity or weak compactness.',['non-reflexive','weak compactness','Eberlein'])
item('Mather/Sacker-Sell/evolution-semigroup spectral viewpoint','restore only as future direction','Do not add as theorem. Add one sentence in open problems: relate the fractional Green-summand spectrum to Mather/Sacker-Sell spectra of weighted shift/evolution operators under precise hypotheses.','Ambitious audits introduced this framing; we rejected it as theorem-level, but it is a legitimate research direction if clearly labeled.',['Mather','Sacker','Chicone','Latushkin','operator algebra'])
item('Full fractional-spectrum converse','worth restoring as conjecture/open problem','Add as an open problem: determine conditions under which boundedness of the Green inverse implies the subunit fractional Green-summand radius, or characterize cancellations.','We proved sufficiency and periodic obstructions, but not a full converse. This is the natural next research problem.',['converse','cancellation'])
item('Transverse lamination regularity problem','worth restoring as open problem','Add an open problem: characterize transverse regularity of stable/unstable laminations and phase maps via integer or fractional bunching.','The manuscript warns transverse regularity is not automatic, but an explicit open problem would preserve the bigger-picture theme.',['transverse','phase map','lamination regularity'])
item('Parabolic compact Fredholm resonance refinement','already restored','No action.','Appendix K includes compact return maps and Fredholm resonance.',['Compact jet-return Fredholm','Riesz--Schauder','Parabolic compact-return'])
item('Triangular-wave Lipschitz counterexample','already restored','No action.','The neutral remark appears in Section 4.',['triangular wave'])
item('Alternative center-stable/center-unstable construction','already restored','No action.','The remark appears after Theorem 5.1 proof.',['center-stable and center-unstable','W^{cs}'])
item('Exact HPS source theorem numbers','worth doing before submission, but not a theorem-content restoration','Add TODO/comment or perform bibliographic verification separately; do not invent theorem numbers.','The manuscript cites external HPS/Banach input but does not identify exact theorem numbers. This is a publication-prep gap, not missing mathematical content.',['Theorem','Bates--Lu--Zeng'])
item('Navier-Stokes / concrete PDE application','not restore without new work','Do not add.','Ambitious drafts mentioned turbulence/Navier-Stokes, but no concrete PDE verification is developed. Adding this would overclaim.',['Navier','Kuramoto','Reaction-Diffusion'])
item('Operator-algebraic “resolution of local compactness” rhetoric','do not restore as claim','At most mention as a future spectral viewpoint.','It was repeatedly found too broad and underproved.',['local compactness','operator-algebraic'])
item('Conjecture about residual spectrum in noncompact/noncompact-operator case','optional, but not recommended','If included, phrase as standard spectral caveat, not a conjecture.','General Banach operators can fail surjectivity through non-point spectrum; current Appendix K already warns without compactness.',['residual spectrum','continuous spectrum'])

worth=[i for i in items if i['status'] in ['worth restoring','restore only as future direction']]
report=[]
report.append('# Final Restoration Scan: Entire Chat History')
report.append('')
report.append(f'File scanned: `{final}`')
report.append('')
report.append('## Executive result')
report.append('')
report.append('No major theorem, proof module, or technical correction from the chat history appears accidentally lost. The integrated manuscript preserves the main surviving architecture and Appendices A--K. However, a few high-level orientation items are worth restoring as explicitly labeled remarks/open problems, not as theorem-level claims.')
report.append('')
report.append('## Items worth restoring or checking')
for i in items:
    icon='✅' if i['status']=='already restored' else ('➕' if 'worth' in i['status'] or 'future' in i['status'] else '🚫')
    report.append(f"### {icon} {i['name']}")
    report.append(f"- Status: **{i['status']}**")
    report.append(f"- Recommendation: {i['recommendation']}")
    report.append(f"- Reason: {i['reason']}")
    if i['term_presence']:
        report.append(f"- Search-term presence: `{i['term_presence']}`")
    report.append('')
report.append('## Minimal proposed restoration')
report.append('')
report.append('Add one concise section titled **Open Problems and Spectral Directions** containing:')
report.append('')
report.append('1. full two-sided Banach-bundle HPS matching as a possible self-contained future proof;')
report.append('2. fractional-spectrum converse problem;')
report.append('3. transverse lamination/phase regularity problem;')
report.append('4. relation to Mather/Sacker--Sell/evolution-semigroup spectra;')
report.append('5. note that internal Perron fibre regularity does not require reflexivity, while transverse regularity remains separate.')
report.append('')
report.append('This would restore the remaining ambitious big-picture content without weakening rigor.')
Path('/home/user/final_restoration_scan_report.md').write_text('\n'.join(report))
Path('/home/user/final_restoration_scan.json').write_text(json.dumps(items,indent=2))
print(json.dumps({'items':len(items),'worth_restoring':len(worth),'report':'/home/user/final_restoration_scan_report.md'},indent=2))
