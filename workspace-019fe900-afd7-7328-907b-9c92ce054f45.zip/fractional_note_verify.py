from pathlib import Path
import sympy as sp, json, math
results=[]
def add(n,ok,d): results.append({'name':n,'ok':bool(ok),'detail':d})
# Two-cycle resonance determinant
B=sp.Rational(1,2); Df=sp.Rational(1,2)
A0=sp.Matrix([[-B,1],[1,-B]])
A1=sp.Matrix([[-B/Df,1],[1,-B/Df]])
add('two_cycle_C0_invertible', A0.det()!=0, f'det={A0.det()}')
add('two_cycle_C1_resonant', A1.det()==0, f'det={A1.det()}')
# Fractional scalar threshold for f(x)=lambda_t x, B=lambda_n. radius = |B| |lambda_t|^{-k-alpha} for stable local model.
lam_n=sp.Rational(1,4); lam_t=sp.Rational(1,2); k=1; alpha=sp.Rational(1,2)
radius=lam_n*(1/lam_t)**(k+alpha)
add('fractional_scalar_radius_example_less_than_one', float(radius)<1, f'radius={sp.simplify(radius)} ≈ {float(radius)}')
# If alpha=1, radius = 1; threshold exactly two derivatives in this toy scaling.
alpha2=sp.Rational(1,1); radius2=lam_n*(1/lam_t)**(k+alpha2)
add('fractional_scalar_threshold_witness', radius2==1, f'radius at alpha=1 is {radius2}')
# Text checks
s=Path('/home/user/fractional_jet_spectrum_research_note.md').read_text()
add('display_balanced', s.count('\\[')==s.count('\\]'), f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_balanced', s.count('\\(')==s.count('\\)'), f"{s.count('\\(')} vs {s.count('\\)')}")
for pat in ['operator norms on \\(C^\\alpha\\) include all Hölder variation','full triangular jet return map','k+\\alpha\\le r+\\beta','Periodic jet-resonance obstruction']:
 add('present_'+pat[:20], pat in s, pat)
all_ok=all(r['ok'] for r in results)
lines=['# Fractional Jet-Spectrum Note Verification','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for r in results: lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['name']}** — {r['detail']}")
Path('/home/user/fractional_note_verification_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results},indent=2))
