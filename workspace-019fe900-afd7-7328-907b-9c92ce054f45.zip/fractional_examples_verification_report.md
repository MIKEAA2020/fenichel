# Fractional Examples Verification

Overall: **PASS**

- ✅ **toral_threshold_N_1** — lambda=Lambda^-1, s*=1.0
- ✅ **toral_threshold_N_2** — lambda=Lambda^-2, s*=2.0
- ✅ **toral_threshold_N_3** — lambda=Lambda^-3, s*=2.9999999999999996
- ✅ **toral_radius_below_threshold** — radius s=1.5: 0.6180339887498949
- ✅ **toral_radius_at_threshold** — radius s=2: 1.0
- ✅ **isometry_radius_0.2** — rho_s=0.2 for all allowed s
- ✅ **isometry_radius_0.7** — rho_s=0.7 for all allowed s
- ✅ **isometry_radius_0.95** — rho_s=0.95 for all allowed s
- ✅ **text_has_toral_example** — toral example present
- ✅ **text_has_isometry_example** — isometry example present