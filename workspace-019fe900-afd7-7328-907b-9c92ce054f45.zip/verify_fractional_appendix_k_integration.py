from pathlib import Path
import re, json, math, numpy as np, sympy as sp
p=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
s=p.read_text()
results=[]
def add(n,ok,d): results.append({'name':n,'ok':bool(ok),'detail':d})
add('display_balanced',s.count('\\[')==s.count('\\]'),f"{s.count('\\[')} vs {s.count('\\]')}")
add('inline_balanced',s.count('\\(')==s.count('\\)'),f"{s.count('\\(')} vs {s.count('\\)')}")
add('env_balanced',re.findall(r'\\begin\{([^}]+)\}',s)==re.findall(r'\\end\{([^}]+)\}',s),str((re.findall(r'\\begin\{([^}]+)\}',s),re.findall(r'\\end\{([^}]+)\}',s))))
for pat in ['maps center cones strictly','follows by the same argument','Your assessment','Final honest','What has been repaired','invalid Lipschitz','false Lipschitz']:
 add('absent_'+pat[:18], pat not in s, pat)
for pat in ['Appendix K. Fractional jet spectra','Theorem K.1. Hölder jet-spectrum inverse','Proposition K.2. Periodic jet-resonance obstruction','operator norms on \\(C^\\alpha\\) include all Hölder variation','full triangular jet return map','k+\\alpha\\le r+\\beta','Corollary 5.3. Conditional nonlinear regularity spectrum','Hyperbolic toral base']:
 add('present_'+pat[:22], pat in s, pat)
# math witnesses
Lambda=(3+math.sqrt(5))/2
for N in [1,2,3]:
    lam=Lambda**(-N); sstar=math.log(1/lam)/math.log(Lambda)
    add(f'toral_threshold_N{N}', abs(sstar-N)<1e-12, f's*={sstar}')
B=sp.Rational(1,2); Df=sp.Rational(1,2)
A0=sp.Matrix([[-B,1],[1,-B]]); A1=sp.Matrix([[-B/Df,1],[1,-B/Df]])
add('two_cycle_C0_ok_C1_resonance', A0.det()!=0 and A1.det()==0, f'C0 det={A0.det()}, C1 det={A1.det()}')
# symmetric power resonance quick for k=2 cat map
AinvT=np.array([[1,-1],[-1,2]],float); x,y=sp.symbols('x y')
def sympow(M,k):
    a,b,c,d=M[0,0],M[0,1],M[1,0],M[1,1]
    S=np.zeros((k+1,k+1))
    for j in range(k+1):
        poly=sp.Poly(sp.expand((a*x+b*y)**(k-j)*(c*x+d*y)**j),x,y)
        for l in range(k+1): S[l,j]=float(poly.coeff_monomial(x**(k-l)*y**l))
    return S
for k in [1,2,3]:
    eig=np.linalg.eigvals(sympow(AinvT,k)); scaled=(Lambda**(-k))*eig
    add(f'sym_power_resonance_k{k}', min(abs(v-1) for v in scaled)<1e-8, f'min distance={min(abs(v-1) for v in scaled):.2e}')
all_ok=all(r['ok'] for r in results)
lines=['# Fractional Appendix K Integration Verification','',f'Manuscript: `{p}`','',f'Overall: **{"PASS" if all_ok else "ISSUES"}**','']
for r in results: lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['name']}** — {r['detail']}")
Path('/home/user/fractional_appendix_k_integration_verification.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results},indent=2))
