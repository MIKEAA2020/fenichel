from pathlib import Path

src = Path('/home/user/uploads/passive voice.txt')
text = src.read_text(encoding='utf-8-sig')

# Normalize line endings
text = text.replace('\r\n', '\n')

# Abstract replacement
old_abs = '''## Abstract

This article presents a rigorous persistence theorem for compact normally hyperbolic invariant manifolds in Banach spaces under small perturbations. The ambient phase space is allowed to be infinite-dimensional, while the invariant manifold is assumed finite-dimensional, compact, and split. The proof is organized around three principal ingredients: the inverse of the linear cohomological operator associated with the normal exponential dichotomy; the Hirsch–Pugh–Shub invariant-section theorem; and a Perron construction for stable and unstable fibres. Quantitative dependence on parameters is included. The article also formulates the principal extensions to parabolic semiflows, noncompact manifolds, Banach-dimensional invariant manifolds, random and nonautonomous cocycles, delay equations, and quasilinear problems.'''
new_abs = '''## Abstract

We present a persistence theorem for compact normally hyperbolic invariant manifolds in Banach spaces under small perturbations. The ambient phase space may be infinite-dimensional, while the invariant manifold is finite-dimensional, compact, and split. The proof uses three ingredients: the inverse of the linear cohomological operator associated with the normal exponential dichotomy; the Hirsch–Pugh–Shub invariant-section theorem; and a Perron construction for stable and unstable fibres. We include quantitative parameter dependence and state the principal extensions to parabolic semiflows, noncompact manifolds, Banach-dimensional invariant manifolds, random and nonautonomous cocycles, delay equations, and quasilinear problems.'''
text = text.replace(old_abs, new_abs)

# Introduction replacement paragraphs
old_intro = '''The principal result of this article is a persistence theorem for a compact finite-dimensional normally hyperbolic invariant manifold embedded in a Banach space, under perturbations by local diffeomorphisms. The ambient Banach space may be infinite-dimensional. The stable and unstable fibres may therefore be infinite-dimensional. The theorem is proved in full for the compact invertible case. Extensions to noninvertible parabolic semiflows, noncompact base manifolds, Banach-dimensional invariant manifolds, random cocycles, delay equations, and quasilinear equations are then stated in a form compatible with the same proof architecture.

The article is organized as follows. Section 2 introduces the geometric and dynamical hypotheses. Section 3 proves the linear cohomological inverse theorem. Section 4 states the invariant-section theorem. Section 5 derives the Fenichel persistence theorem. Section 6 constructs stable and unstable fibres. Section 7 treats flows. Section 8 collects the main extensions.'''
new_intro = '''Our principal result is a persistence theorem for a compact finite-dimensional normally hyperbolic invariant manifold embedded in a Banach space, under perturbations by local diffeomorphisms. The ambient Banach space may be infinite-dimensional. The stable and unstable fibres may therefore be infinite-dimensional. We prove the theorem for the compact invertible case. We then state extensions to noninvertible parabolic semiflows, noncompact base manifolds, Banach-dimensional invariant manifolds, random cocycles, delay equations, and quasilinear equations in a form compatible with the same proof architecture.

Section 2 introduces the geometric and dynamical hypotheses. Section 3 proves the linear cohomological inverse theorem. Section 4 states the invariant-section theorem. Section 5 derives the Fenichel persistence theorem. Section 6 constructs stable and unstable fibres. Section 7 treats flows. Section 8 collects the main extensions.'''
text = text.replace(old_intro, new_intro)

# Style replacements throughout
repls = {
    'All comparisons of bundle-valued quantities are understood using these transported differences.': 'We compare bundle-valued quantities using these transported differences.',
    'The principal linear theorem is the following.': 'The linear theorem is the following.',
    'It remains to verify that': 'We verify that',
    'It remains to prove uniqueness of bounded solutions.': 'We prove uniqueness of bounded solutions.',
    'The extension to \\(C^k\\), \\(1\\le k\\le r\\), follows from the standard Hirsch–Pugh–Shub difference-quotient theorem [2].': 'For \\(C^k\\) regularity, \\(1\\le k\\le r\\), we apply the standard Hirsch–Pugh–Shub difference-quotient theorem [2].',
    'The nonlinear core of the persistence theorem is the invariant-section theorem of Hirsch–Pugh–Shub, adapted to Banach bundles. In the present formulation it is stated as a theorem on invariant sections of a Banach bundle over a compact finite-dimensional base.': 'The persistence theorem uses the invariant-section theorem of Hirsch, Pugh, and Shub, adapted to Banach bundles. We state it as a theorem on invariant sections of a Banach bundle over a compact finite-dimensional base.',
    'This theorem is proved in [2] for finite-dimensional bundles. The Banach-fibre extension follows by the same argument, since the proof uses only the Banach-space contraction principle, cone invariance, and the bounded inverse of the linear cohomological operator established in Theorem 3.1.': 'Hirsch, Pugh, and Shub prove this theorem for finite-dimensional bundles [2]. The Banach-fibre extension follows by the same argument when the stated uniform bundle estimates hold, since the proof uses the Banach-space contraction principle, cone invariance, and the bounded inverse of the linear cohomological operator established in Theorem 3.1.',
    'For completeness, we record the invariant graph equation in transported form.': 'The invariant graph equation has the following transported form.',
    'The fixed-point problem may therefore be written formally as': 'Thus the fixed-point problem is',
    'We now derive the principal persistence theorem for Banach-space diffeomorphisms.': 'We now derive the persistence theorem for Banach-space diffeomorphisms.',
    'the tube may be chosen so that': 'we choose the tube so that',
    'It remains to prove equality.': 'We prove equality.',
    'It remains to prove that \\(f_\\varepsilon\\) is a diffeomorphism.': 'We prove that \\(f_\\varepsilon\\) is a diffeomorphism.',
    'The perturbed stable and unstable bundles are obtained as invariant graphs of linear maps between the original summands.': 'We obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original summands.',
    'Local uniqueness is the uniqueness assertion of Theorem 4.1.': 'Theorem 4.1 gives local uniqueness.',
    'The strong unstable fibres are obtained by applying the preceding construction to \\(F_\\varepsilon^{-1}\\).': 'We obtain the strong unstable fibres by applying the preceding construction to \\(F_\\varepsilon^{-1}\\).',
    'The compact invertible theorem above is the model case. The same architecture extends to several broader classes of systems. In each case the discrete Green operator is replaced by the appropriate linear inverse, and the function spaces are adapted to the dynamics.': 'The compact invertible theorem serves as the model case. The same architecture extends to several broader classes of systems. In each case we replace the discrete Green operator by the appropriate linear inverse and adapt the function spaces to the dynamics.',
    'The compact invertible persistence theorem is obtained from the chain': 'The proof of the compact invertible persistence theorem follows the chain',
    'Extensions to parabolic semiflows, noncompact manifolds, Banach-dimensional manifolds, random cocycles, delay equations, and quasilinear problems are obtained by replacing the discrete Green operator with the appropriate Perron or tame inverse and by adapting the function spaces to the dynamics.': 'We obtain extensions to parabolic semiflows, noncompact manifolds, Banach-dimensional manifolds, random cocycles, delay equations, and quasilinear problems by replacing the discrete Green operator with the appropriate Perron or tame inverse and by adapting the function spaces to the dynamics.',
}
for old, new in repls.items():
    text = text.replace(old, new)

# Replace Section 2.2 with invariant bunching + one-step sufficient + warning
old_bunch = '''### 2.2. Bunching assumptions

The persistence of \\(C^r\\) regularity requires bunching inequalities. Assume that for every \\(0\\le j\\le r\\),

\\[
\\sup_{m\\in M}
\\|B_m^s\\|\\,\\|Df(m)^{-1}\\|^j
<1,
\\]

and

\\[
\\sup_{m\\in M}
\\|(B_m^u)^{-1}\\|\\,\\|Df(m)\\|^j
<1.
\\]

Equivalently, after replacing \\(F_0\\) by an iterate and using an adapted norm if necessary, the same strict inequalities hold uniformly. This formulation avoids dependence on a particular choice of norm.'''
new_bunch = '''### 2.2. Bunching assumptions

The persistence of \\(C^r\\) regularity requires bunching inequalities. We use the following coordinate-invariant formulation. For each \\(0\\le j\\le r\\), assume that there exist constants \\(C_j>0\\) and \\(\\theta_j\\in(0,1)\\) such that, along every orbit \\(m_n=f^n(m)\\),

\\[
\\|\\Phi(n,0)|_{E_m^s}\\|\\,
\\|Df^{-n}(m_n)\\|^j
\\le
C_j\\theta_j^n,
\\qquad n\\ge0,
\\]

and

\\[
\\|\\Phi(-n,0)|_{E_m^u}\\|\\,
\\|Df^n(m)\\|^j
\\le
C_j\\theta_j^n,
\\qquad n\\ge0.
\\]

Here \\(\\Phi(-n,0)\\) denotes the inverse unstable evolution from \\(E_m^u\\) to \\(E_{m_{-n}}^u\\). A convenient sufficient one-step form is

\\[
\\sup_{m\\in M}
\\|B_m^s\\|\\,\\|Df(m)^{-1}\\|^j
<1,
\\]

and

\\[
\\sup_{m\\in M}
\\|(B_m^u)^{-1}\\|\\,\\|Df(m)\\|^j
<1.
\\]

One often obtains this one-step form after passing to an iterate and introducing an adapted norm. If adapted norms or iterates are used, one must verify that the adapted norms are uniformly equivalent to the original norms and that the perturbation remains small in the adapted topology. Otherwise the quantitative \\(C^r\\) estimates may not transfer back to the original topology.'''
text = text.replace(old_bunch, new_bunch)

# Fix projection indexing in cohomological theorem
text = text.replace('''Decompose

\\[
q_n=q_n^s+q_n^u,
\\qquad
q_n^\\sigma=P_{m_n}^\\sigma q_n.
\\]''', '''Decompose

\\[
q_n=q_n^s+q_n^u,
\\qquad
q_n^\\sigma=P_{m_{n+1}}^\\sigma q_n,
\\]

since \\(q_n\\in E_{m_{n+1}}\\).''')

# Insert admissible class before Theorem 4.1
marker = '''---

### Theorem 4.1. Hirsch–Pugh–Shub invariant-section theorem'''
admissible = '''---

Let

\\[
\\mathcal B_{\\rho,L}
=
\\left\\{
h\\in C^0(M,E):
\\|h\\|_{C^0}\\le \\rho,
\\ \\operatorname{Lip}(h)\\le L
\\right\\}.
\\]

Equip \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric. Since \\(M\\) is compact and the Lipschitz bound is uniform, \\(\\mathcal B_{\\rho,L}\\) is complete.

Let \\(\\kappa>0\\). In local coordinates adapted to

\\[
TE|_M \\simeq TM\\oplus E^s\\oplus E^u,
\\]

define center cones by

\\[
\\mathcal C^c_{(m,\\eta)}
=
\\left\\{
(v^c,v^s,v^u):
\\|(v^s,v^u)\\|\\le \\kappa\\|v^c\\|
\\right\\}.
\\]

A \\(C^1\\) section with \\(\\operatorname{Lip}(h)\\le\\kappa\\) has a graph tangent to these center cones; a merely Lipschitz section satisfies the corresponding secant-cone condition. The graph transform preserves this admissible class.

---

### Theorem 4.1. Hirsch–Pugh–Shub invariant-section theorem'''
text = text.replace(marker, admissible)

# Insert parameter asymptotic expansions after quantitative estimates in Section 5 proof
old_quant_end = '''Also,

\\[
f_\\varepsilon(m)=b_\\varepsilon(m,h_\\varepsilon(m)),
\\]

so the chain rule gives

\\[
\\|f_\\varepsilon-f\\|_{C^r}
\\le
C_r''|\\varepsilon|.
\\]

The persistence of the invariant splitting follows from the roughness theorem for exponential dichotomies; see, for example, Palmer [6].'''
new_quant_end = '''Also,

\\[
f_\\varepsilon(m)=b_\\varepsilon(m,h_\\varepsilon(m)),
\\]

so the chain rule gives

\\[
\\|f_\\varepsilon-f\\|_{C^r}
\\le
C_r''|\\varepsilon|.
\\]

If the perturbation admits an expansion

\\[
F_\\varepsilon
=
F_0+\\varepsilon F_1+\\cdots+\\varepsilon^k F_k
+O(\\varepsilon^{k+1})
\\]

in the appropriate topology, and if the required parameter-bunching conditions hold, then

\\[
h_\\varepsilon
=
h_0+\\varepsilon h_1+\\cdots+\\varepsilon^k h_k
+O(\\varepsilon^{k+1}).
\\]

The coefficients \\(h_j\\) are obtained recursively by differentiating the invariance equation. At each order one solves a linear cohomological equation of the form treated in Theorem 3.1.

The persistence of the invariant splitting follows from the roughness theorem for exponential dichotomies; see, for example, Palmer [6].'''
text = text.replace(old_quant_end, new_quant_end)

# Insert stable manifold / phase projection; renumber regularity and unstable headings
old_stable_heading = '''### 6.1. Regularity of stable leaves'''
new_stable_sections = '''### 6.1. Stable manifold, phase projection, and tracking

Iteration extends the local stable fibres globally, provided the orbits remain in the tube in which the construction is valid. Define

\\[
W^s(M_\\varepsilon)
=
\\left\\{
y:
F_\\varepsilon^n(y)\\text{ remains near }M_\\varepsilon
\\text{ for all }n\\ge0
\\text{ and approaches }M_\\varepsilon
\\right\\}.
\\]

Locally,

\\[
W^s(M_\\varepsilon)
=
\\bigcup_{p\\in M_\\varepsilon}
W^s_{\\mathrm{loc}}(p).
\\]

If \\(F_\\varepsilon\\) is a diffeomorphism, then

\\[
F_\\varepsilon(W^s(M_\\varepsilon))
=
W^s(M_\\varepsilon)
\\]

on the locally defined stable manifold. The unstable manifold \\(W^u(M_\\varepsilon)\\) is defined analogously using backward iteration.

The stable fibres define an asymptotic phase projection

\\[
\\pi^s:W^s_{\\mathrm{loc}}(M_\\varepsilon)\\to M_\\varepsilon.
\\]

If \\(y\\in W^s_{\\mathrm{loc}}(M_\\varepsilon)\\), then \\(\\pi^s(y)\\) is the unique point in \\(M_\\varepsilon\\) whose orbit is asymptotic to the orbit of \\(y\\). For \\(n\\ge0\\),

\\[
\\operatorname{dist}
\\left(
F_\\varepsilon^n(y),
F_\\varepsilon^n(\\pi^s(y))
\\right)
\\le
C e^{-\\gamma n}
\\operatorname{dist}(y,M_\\varepsilon).
\\]

The regularity of \\(\\pi^s\\) is a separate question and requires its own bunching assumptions.

---

### 6.2. Regularity of stable leaves'''
text = text.replace(old_stable_heading, new_stable_sections)
text = text.replace('### 6.2. Strong unstable fibres', '### 6.3. Strong unstable fibres')

# Insert continuous-time Perron formula in Section 7 before caveat
old_flow_caveat = '''If \\(M\\) is invariant only under a single time-\\(T\\) map of the unperturbed flow, the above uniqueness argument is not valid. In that case one must either assume full-flow invariance or construct the invariant manifold directly by a continuous-time Perron method.'''
new_flow_caveat = '''In continuous time, the strong stable Perron operator for the deviation equation

\\[
\\dot\\xi(t)=A(t)\\xi(t)+R(t,\\xi(t))
\\]

is

\\[
\\xi^s(t)
=
\\Phi^s(t,0)a
+
\\int_0^t
\\Phi^s(t,s)P^s(s)R(s,\\xi(s))\\,ds,
\\]

and

\\[
\\xi^{cu}(t)
=
-
\\int_t^\\infty
\\Phi^{cu}(t,s)P^{cu}(s)R(s,\\xi(s))\\,ds.
\\]

The same rate-gap condition is required: the stable decay rate must dominate the backward growth rate of the center-unstable complement.

If \\(M\\) is invariant only under a single time-\\(T\\) map of the unperturbed flow, the above uniqueness argument is not valid. In that case one must either assume full-flow invariance or construct the invariant manifold directly by a continuous-time Perron method.'''
text = text.replace(old_flow_caveat, new_flow_caveat)

# Section 8 intro expansion: scope list + table + finite-dimensional subsection
old_ext_intro = '''## 8. Extensions

The compact invertible theorem serves as the model case. The same architecture extends to several broader classes of systems. In each case we replace the discrete Green operator by the appropriate linear inverse and adapt the function spaces to the dynamics.

---

### 8.1. Parabolic semiflows'''
new_ext_intro = '''## 8. Extensions

The compact invertible theorem serves as the model case. The same architecture extends to several broader classes of systems. In each case we replace the discrete Green operator by the appropriate linear inverse and adapt the function spaces to the dynamics.

Without additional hypotheses, the compact invertible theorem does not cover:

1. noninvertible parabolic semiflows;
2. unbounded linear generators;
3. noncompact invariant manifolds;
4. Banach-dimensional invariant manifolds;
5. delay equations;
6. random or nonautonomous cocycles;
7. quasilinear equations with derivative loss;
8. manifolds with boundary;
9. transverse \\(C^r\\) regularity of stable or unstable foliations without additional bunching.

The following table summarizes the replacements used in the extension settings.

| Setting | Linear inverse | Function space | Additional hypothesis |
|---|---|---|---|
| Compact invertible map | discrete Green operator | \\(C^k(M,E)\\) | bunching |
| Noncompact finite-dimensional manifold | discrete Green operator with uniform constants | \\(C_b^k(M,E)\\) | bounded geometry |
| Banach-dimensional manifold | discrete Green operator on Banach bundles | \\(C_b^k(M,E)\\) | split tubular neighbourhood, adapted metric |
| Parabolic semiflow | analytic semigroup Perron integral | weighted mild-solution spaces | sectorial dichotomy, smoothing |
| Random cocycle | random Green operator | tempered weighted spaces | random or tempered dichotomy |
| Quasilinear PDE | tame or maximal-regularity inverse | scales \\(X_s\\) | derivative recovery or Nash–Moser |

---

### 8.1. Finite-dimensional singular perturbations

In finite-dimensional singular perturbation problems one often considers

\\[
\\begin{aligned}
\\dot x &= f(x,y,\\varepsilon),\\\\
\\dot y &= \\varepsilon g(x,y,\\varepsilon).
\\end{aligned}
\\]

The critical manifold is

\\[
M_0=\\{(x,y):f(x,y,0)=0\\}.
\\]

Normal hyperbolicity of \\(M_0\\) means that the fast linearization \\(D_xf(x,y,0)\\) has spectrum bounded away from the imaginary axis. If \\(M_\\varepsilon\\) is written as a graph

\\[
x=h_\\varepsilon(y),
\\]

then the reduced equation on \\(M_\\varepsilon\\) is exactly

\\[
\\dot y=\\varepsilon g(h_\\varepsilon(y),y,\\varepsilon).
\\]

Approximate reduced equations arise only after expanding \\(h_\\varepsilon\\) in powers of \\(\\varepsilon\\).

---

### 8.2. Parabolic semiflows'''
text = text.replace(old_ext_intro, new_ext_intro)

# Renumber existing extension headings after inserting 8.1
renum = {
    '### 8.2. Noncompact finite-dimensional manifolds': '### 8.3. Noncompact finite-dimensional manifolds',
    '### 8.3. Banach-dimensional invariant manifolds': '### 8.4. Banach-dimensional invariant manifolds',
    '### 8.4. Random and nonautonomous cocycles': '### 8.5. Random and nonautonomous cocycles',
    '### 8.5. Quasilinear equations and derivative loss': '### 8.6. Quasilinear equations and derivative loss',
    '### 8.6. Delay equations': '### 8.7. Delay equations',
}
for old, new in renum.items():
    text = text.replace(old, new)

# Replace boundary mention with fuller subsection inserted before Banach-dimensional section
old_boundary = '''If \\(M\\) has boundary, one must impose inflowing or overflowing invariance conditions, or introduce a localized cutoff.

---

### 8.4. Banach-dimensional invariant manifolds'''
new_boundary = '''If \\(M\\) has boundary, one must impose inflowing or overflowing invariance conditions, or introduce a localized cutoff.

---

### 8.4. Manifolds with boundary

If \\(M\\) has boundary, ordinary invariance may fail at the boundary. In that case we distinguish several notions:

1. local invariance away from the boundary;
2. inflowing invariance, where trajectories enter the manifold through part of the boundary;
3. overflowing invariance, where trajectories leave the manifold through part of the boundary;
4. invariance after cutting off the vector field outside a prescribed region.

Persistence theorems for manifolds with boundary require boundary-compatible hyperbolicity conditions and a precise choice of one of these invariance notions.

---

### 8.5. Banach-dimensional invariant manifolds'''
text = text.replace(old_boundary, new_boundary)
# Adjust headings that got shifted by boundary insertion
text = text.replace('### 8.5. Random and nonautonomous cocycles', '### 8.6. Random and nonautonomous cocycles')
text = text.replace('### 8.6. Quasilinear equations and derivative loss', '### 8.7. Quasilinear equations and derivative loss')
text = text.replace('### 8.7. Delay equations', '### 8.8. Delay equations')

# Further style cleanup
more = {
    'is assumed finite-dimensional': 'is finite-dimensional',
    'is allowed to be infinite-dimensional': 'may be infinite-dimensional',
    'is equipped with': 'has',
    'Equivalently, one may work': 'Equivalently, we may work',
    'is a small parameter': 'denotes a small parameter',
    'isomorphism, and the restrictions': 'isomorphism; the restrictions',
    'is interpreted in the standard difference-quotient sense': 'we interpret the conclusion in the standard difference-quotient sense',
    'Theorem 5.1 yields a manifold': 'Theorem 5.1 gives a manifold',
    'This is the desired local strong stable fibre.': 'This gives the desired local strong stable fibre.',
}
for old, new in more.items():
    text = text.replace(old, new)

# Write revised manuscript
out = Path('/home/user/revised_passive_voice.md')
out.write_text(text, encoding='utf-8')
print(out, len(text.splitlines()), len(text))
