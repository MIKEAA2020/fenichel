from pathlib import Path
import re, math, json
import numpy as np

manuscript = Path('/home/user/final_manuscript_full_revised.md')
text = manuscript.read_text()
results = []

def add(name, ok, detail):
    results.append({'check': name, 'ok': bool(ok), 'detail': detail})

# 1. Lightweight LaTeX delimiter checks
add('display_math_delimiters', text.count('\\[') == text.count('\\]'),
    f"\\[ count={text.count('\\[')}, \\] count={text.count('\\]')}")
add('inline_math_delimiters', text.count('\\(') == text.count('\\)'),
    f"\\( count={text.count('\\(')}, \\) count={text.count('\\)')}")
begins = re.findall(r'\\begin\{([^}]+)\}', text)
ends = re.findall(r'\\end\{([^}]+)\}', text)
from collections import Counter
add('latex_environment_balance', Counter(begins) == Counter(ends),
    f"begin={dict(Counter(begins))}, end={dict(Counter(ends))}")

# 2. Source hygiene: chat/meta language and mojibake patterns
bad_patterns = ['Your assessment', 'Your diagnosis', 'Final honest', 'What has been repaired',
                'Next step', 'fatal point', 'invalid Lipschitz', 'false Lipschitz', 'Step 1:', 'Step 2:', 'Step 3:', 'Step 4:']
found_bad = [pat for pat in bad_patterns if pat in text]
add('no_chat_repair_meta_language', len(found_bad) == 0, f"found={found_bad}")
mojibake_patterns = ['â', 'ï»¿', '�', 'Nash\x96Moser']
found_mojibake = [pat for pat in mojibake_patterns if pat in text]
add('no_common_mojibake', len(found_mojibake) == 0, f"found={found_mojibake}")

# 3. Green operator identity in a constant finite-dimensional model
# Equation: zeta_{n+1} - B zeta_n = q_n, B=diag(a,b), 0<a<1<b.
a, b = 0.4, 2.5
K = 450
Ntest = 80
def q(n):
    return np.array([math.sin(0.37*n) + 0.3*math.cos(0.11*n),
                     math.cos(0.23*n) - 0.2*math.sin(0.17*n)])

def zeta(n):
    zs = 0.0
    for j in range(-K, n):
        zs += (a ** (n-j-1)) * q(j)[0]
    zu = 0.0
    for j in range(n, K+1):
        zu += -(b ** (n-j-1)) * q(j)[1]  # backward unstable evolution B^{n-(j+1)}
    return np.array([zs, zu])
B = np.diag([a,b])
resids = []
for n in range(-Ntest, Ntest+1):
    resids.append(np.linalg.norm(zeta(n+1) - B @ zeta(n) - q(n), ord=np.inf))
max_resid = max(resids)
add('green_operator_solves_model_equation', max_resid < 1e-12,
    f"constant dichotomy model max residual={max_resid:.3e}; B=diag({a},{b})")

# 4. Green operator bound in same model: compare sampled sup norm to theoretical geometric bound.
qsup = max(np.linalg.norm(q(n), ord=np.inf) for n in range(-K, K+1))
zsup = max(np.linalg.norm(zeta(n), ord=np.inf) for n in range(-Ntest, Ntest+1))
# The model bound with projections norm 1 and C=1, lambda=max(a,1/b).
lam = max(a, 1/b)
bound = 2/(1-lam)*qsup
add('green_operator_geometric_bound_model', zsup <= bound * 1.01,
    f"sample zsup={zsup:.6g}, qsup={qsup:.6g}, bound={bound:.6g}, lambda={lam}")

# 5. Jet cocycle bunching check for representative rates.
df_norm = 1.15
stable_norm = 0.28
unstable_inv_norm = 0.30
r = 4
products = []
for k in range(r+1):
    products.append((k, stable_norm*(df_norm**k), unstable_inv_norm*(df_norm**k)))
max_prod = max(max(x[1], x[2]) for x in products)
add('sample_jet_bunching_products_strict', max_prod < 1,
    'products (k, stable, unstable_back)=' + repr(products))

# 6. Discrete Perron convolution bounds for stable fibres.
alpha_s, beta_cu, gamma = 1.7, 0.35, 0.9
nmax = 250
stable_vals=[]
cu_vals=[]
for n in range(nmax+1):
    stable_sum = sum(math.exp(-alpha_s*(n-k-1))*math.exp(-2*gamma*k) for k in range(0,n))
    stable_vals.append(math.exp(gamma*n)*stable_sum)
    cu_sum = sum(math.exp(beta_cu*(k+1-n))*math.exp(-2*gamma*k) for k in range(n, nmax+800))
    cu_vals.append(math.exp(gamma*n)*cu_sum)
# closed geometric rough denominators finite because gamma<alpha_s and beta_cu<2gamma; manuscript assumes beta_cu<gamma, stronger.
add('stable_perron_convolution_bounded_sample', max(stable_vals) < 10,
    f"max weighted stable convolution={max(stable_vals):.6g}, alpha_s={alpha_s}, gamma={gamma}")
add('center_unstable_perron_convolution_bounded_sample', max(cu_vals) < 10,
    f"max weighted cu convolution={max(cu_vals):.6g}, beta_cu={beta_cu}, gamma={gamma}")
add('stable_gap_assumptions_consistent', beta_cu < gamma < alpha_s,
    f"beta_cu={beta_cu} < gamma={gamma} < alpha_s={alpha_s}")

# 7. HPS schematic contraction/radius estimate with representative small constants.
C = 2.0; gap = 0.8; Nit = 10; delta = 1e-3; omega = 0.01; L = 0.02; rho = 0.1
qfac = C*(math.exp(-gap*Nit)+delta+omega+L)
radius_rhs = C*delta + qfac*rho
add('hps_schematic_constants_can_be_chosen', qfac < 1 and radius_rhs <= rho,
    f"q={qfac:.6g}, radius_rhs={radius_rhs:.6g}, rho={rho}")

# 8. Parabolic convolution bound formula.
rho_exp, alpha, gamma_p = 0.4, 1.3, 0.6
# e^{gamma t} integral_0^t (t-s)^-rho e^{-alpha(t-s)} e^{-gamma s} ds
# = integral_0^t u^-rho e^{-(alpha-gamma)u} du <= Gamma(1-rho)/(alpha-gamma)^(1-rho)
parabolic_bound = math.gamma(1-rho_exp)/((alpha-gamma_p)**(1-rho_exp))
# sample numerical integration with substitution u=x^p to handle singularity roughly
sample_vals=[]
for t in [0.01,0.05,0.1,0.5,1,2,5,10,25,50]:
    xs = np.linspace(0, t, 20001)[1:]  # avoid zero singularity; adequate for sanity check
    vals = (xs**(-rho_exp))*np.exp(-(alpha-gamma_p)*xs)
    sample_vals.append(np.trapz(vals, xs))
max_sample=max(sample_vals)
add('parabolic_convolution_bound_condition', gamma_p < alpha and rho_exp < 1 and max_sample < parabolic_bound*1.05,
    f"sample_sup={max_sample:.6g}, analytic_bound={parabolic_bound:.6g}, gamma={gamma_p}, alpha={alpha}, rho={rho_exp}")

# 9. Remainder estimate implication sanity check.
C = 3.0; delta=1e-4; omega=0.02; tube_rho=0.05
# If |r(0)|<=Cδ and |Dr|<=Cδ+ω then |r(η)| <= Cδ+(Cδ+ω)|η| <= C'δ+ω'|η| with adjusted constants.
eta=tube_rho
raw = C*delta + (C*delta+omega)*eta
absorbed = (C+1)*delta + (omega+C*delta)*eta
add('remainder_mean_value_estimate_consistent', raw <= absorbed + 1e-15,
    f"raw_bound={raw:.6g}, absorbed_bound={absorbed:.6g}, eta={eta}")

# Compose markdown report
all_ok = all(r['ok'] for r in results)
lines = []
lines.append('# Computational Verification Report')
lines.append('')
lines.append(f'Manuscript checked: `{manuscript}`')
lines.append('')
lines.append('Computational checks cannot prove the infinite-dimensional theorems. They can, however, test formula consistency, signs, indexing, delimiter balance, and representative finite-dimensional/rate-model consequences of the displayed estimates.')
lines.append('')
lines.append(f'Overall status: **{"PASS" if all_ok else "ISSUES FOUND"}**')
lines.append('')
for r in results:
    lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['check']}** — {r['detail']}")
lines.append('')
lines.append('## Interpretation')
lines.append('')
lines.append('- The Green-operator sign and indexing were tested in a two-dimensional constant stable/unstable model and solved the cohomological equation to numerical precision.')
lines.append('- The induced jet-cocycle bunching products were checked in a representative model and stayed strictly below one.')
lines.append('- The stable-fibre Perron convolution estimates were tested with rates satisfying `beta_cu < gamma < alpha_s`; the weighted sums stayed uniformly bounded.')
lines.append('- The parabolic smoothing convolution condition `gamma < alpha` and `rho < 1` was checked against the analytic gamma-function bound.')
lines.append('- The HPS schematic contraction and radius-preservation inequalities were checked for one admissible choice of small constants.')

Path('/home/user/math_verification_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok': all_ok, 'results': results}, indent=2))
