from pathlib import Path
p=Path('/home/user/final_manuscript_hps_import_verified.md')
s=p.read_text()

old='''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. A fully self-contained proof must carry out the two-sided Hadamard matching construction, the transported \\(C^0\\) graph contraction, the admissible-graph preservation estimates, and the jet or difference-quotient extension in Banach fibres. The discussion below records the required mechanism and hypotheses; a version with continuous splittings should be read in the HPS transported difference-quotient sense. Appendix D proves the one-sided normally attracting Banach-fibre case completely; the two-sided case requires the additional stable/unstable matching mechanism described here.

The graph transform used in Theorem 4.1 is the full two-sided HPS Hadamard graph transform. It is not the separate stable-forward/unstable-backward component transform. The component equations alone do not imply invariance; the full HPS admissible matching construction is required. In finite-dimensional fibres this compatibility of the forward and backward base correspondences is part of the HPS graph-transform theorem. In Banach fibres the estimates needed for the same construction are Banach contraction estimates in local bundle charts, with transported differences used to patch the chartwise constructions.'''
new='''Hirsch, Pugh, and Shub prove the finite-dimensional version of this theorem [2]. In the present manuscript, Theorem 4.1 is the structural HPS input in the Banach-bundle category. The graph transform used in Theorem 4.1 is the full two-sided HPS Hadamard graph transform, not the separate stable-forward/unstable-backward component transform. The component equations alone do not imply invariance; the full HPS admissible matching construction is required. In finite-dimensional fibres, compatibility of the forward and backward base correspondences is part of the HPS graph-transform theorem. For Banach-space invariant-manifold results using the same graph-transform/Perron architecture, see Bates--Lu [4] and Bates--Lu--Zeng [9]. Appendix J records the precise external structural input and verifies the reduction from the tubular Banach-bundle formulation used here. Appendix D proves the one-sided normally attracting Banach-fibre case completely; the two-sided case is supplied by the imported HPS/Banach-space theorem described in Appendix J.'''
assert old in s
s=s.replace(old,new)

appendix_j=r'''
## Appendix J. External two-sided HPS input and reduction to the manuscript's setting

This appendix records the exact role of the external HPS theorem in the proof. It does not reprove the two-sided Hadamard matching lemma. Instead, it states the structural theorem imported from the HPS/Banach-space invariant-manifold literature and verifies that the hypotheses in the body of the manuscript reduce to that theorem in tubular coordinates.

### J.1. External structural theorem

We use the following structural input.

**External HPS--Banach invariant-section theorem.** Let \(X\) be a Banach space and let \(M\subset X\) be a compact finite-dimensional \(C^{r+1}\) embedded submanifold without boundary. Let \(T\) be a \(C^{r+1}\) local diffeomorphism defined on a neighbourhood of \(M\), with

\[
T(M)=M.
\]

Assume that along \(M\) there is a complemented invariant splitting

\[
T_MX=TM\oplus N^s\oplus N^u
\]

and that the normal cocycle has an exponential dichotomy satisfying the required \(j\)-bunching inequalities for \(0\le j\le r\). Then every sufficiently small \(C^{r+1}\) local diffeomorphism \(\widetilde T\) close to \(T\), with uniform bounds on the relevant neighbourhood, admits a locally unique admissible \(C^r\) invariant graph \(\widetilde M\) near \(M\). In a parametrization \(\widetilde K:M\to X\), there is an internal map \(\widetilde f:M\to M\) such that

\[
\widetilde T\circ \widetilde K
=
\widetilde K\circ \widetilde f.
\]

The fixed point is obtained by the full two-sided admissible Hadamard graph transform. In particular, the compatibility of the forward and backward base correspondences is part of the theorem; it is not derived from separate stable-forward and unstable-backward component equations.

For finite-dimensional fibres this is the graph-transform theorem of Hirsch, Pugh, and Shub [2]. Banach-space versions and the corresponding graph-transform/Perron constructions are developed in Bates--Lu [4] and Bates--Lu--Zeng [9].

### J.2. Reduction from the present tubular-bundle formulation

The setting of the manuscript is a direct tubular-coordinate form of the theorem above. The ambient Banach space is the same \(X\). The compact finite-dimensional invariant manifold is \(M\subset X\). The split tubular embedding

\[
\Theta:U_E\to U_X\subset X
\]

identifies a neighbourhood of \(M\) in \(X\) with a neighbourhood of the zero section of the Banach bundle \(E\to M\). Under this identification the normal bundle is

\[
E=E^s\oplus E^u,
\]

and the invariant splitting

\[
T_mX=T_mM\oplus E_m^s\oplus E_m^u
\]

is precisely the normally hyperbolic splitting in the external theorem.

In tubular coordinates,

\[
\widehat F_\varepsilon(m,\eta)
=
(b_\varepsilon(m,\eta),g_\varepsilon(m,\eta)).
\]

For \(\varepsilon=0\),

\[
b_0(m,0)=f(m),
\qquad
 g_0(m,0)=0,
\]

and

\[
B_m=D_\eta g_0(m,0):E_m\to E_{f(m)}
\]

is the normal cocycle. The exponential dichotomy and the invariant bunching inequalities in Section 2.2 are exactly the normal hyperbolicity and bunching hypotheses of the external theorem.

The hypotheses that \(F_\varepsilon\) is \(C^{r+1}\), locally diffeomorphic, defined on a common tube, and sufficiently close to \(F_0\) provide the perturbation neighbourhood required in the external theorem. The strengthened estimates on

\[
r_\varepsilon(m,\eta)
=
g_\varepsilon(m,\eta)
-
\tau_{b_\varepsilon(m,\eta)\leftarrow f(m)}B_m\eta
\]

are the transported-coordinate form of the usual small nonlinear remainder assumptions used in the graph-transform proof.

Thus the external theorem gives an admissible \(C^r\) graph in tubular coordinates:

\[
M_\varepsilon=
\{(m,h_\varepsilon(m)):m\in M\},
\qquad
h_\varepsilon\in\Gamma^r(E),
\]

with internal map

\[
f_\varepsilon(m)=b_\varepsilon(m,h_\varepsilon(m)),
\]

satisfying the local graph equation

\[
F_\varepsilon(m,h_\varepsilon(m))
=
(f_\varepsilon(m),h_\varepsilon(f_\varepsilon(m))).
\]

This is the conclusion of Theorem 4.1. The global equality

\[
F_\varepsilon(M_\varepsilon)=M_
\varepsilon
\]

used in Theorem 5.1 follows afterward from the compact-manifold argument showing that \(f_\varepsilon\) is a global diffeomorphism.

### J.3. Why the componentwise substitute is excluded

A transform that separately enforces only

\[
g_+^s(m,h(m))=h^s(\beta_h^+(m))
\]

and

\[
g_-^u(m,h(m))=h^u(\beta_h^-(m))
\]

is not the HPS transform. Such component equations do not force

\[
\beta_h^-\circ\beta_h^+=\operatorname{id}_M.
\]

Affine examples can satisfy those separate component equations while failing the full graph equation. The external HPS theorem avoids this defect because the transformed graph is defined by simultaneous admissible stable/unstable matching, and the compatibility of the base correspondences is part of that theorem.

---
'''
# Clean line artifact
appendix_j=appendix_j.replace('M_\n\\varepsilon','M_\\varepsilon')

marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_j+'\n## References')

# Update summary appendices list
s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, Appendix H proves the globalization of local stable fibres under explicit domain assumptions, and Appendix I proves the uniform noncompact cohomological inverse theorem.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, Appendix F proves the parameter-expansion recursion, Appendix G proves the time-map reduction for flows, Appendix H proves the globalization of local stable fibres under explicit domain assumptions, Appendix I proves the uniform noncompact cohomological inverse theorem, and Appendix J records the external two-sided HPS input and the reduction to the tubular formulation.''')

# Add Bates-Lu-Zeng reference before end if not present
s=s.replace('[8] R. S. Hamilton, *The inverse function theorem of Nash and Moser*, Bulletin of the American Mathematical Society 7 (1982), 65–222.',
'''[8] R. S. Hamilton, *The inverse function theorem of Nash and Moser*, Bulletin of the American Mathematical Society 7 (1982), 65–222.

[9] P. W. Bates, K. Lu, C. Zeng, *Existence and persistence of invariant manifolds for semiflows in Banach space*, Memoirs of the American Mathematical Society 135, no. 645, 1998.''')

out=Path('/home/user/final_manuscript_external_hps_closed.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))

report='''# Evaluation of External HPS Closure Plan

## Verdict

The proposed strategy is the correct way to handle the remaining two-sided HPS gap: do not try to prove the Hadamard matching lemma from separate component equations; import the genuine HPS/Banach invariant-manifold theorem and prove the reduction from the manuscript's tubular formulation.

I implemented the strategy in a cautious form. The manuscript now includes Appendix J, which states the external structural input and verifies the reduction. It does not falsely claim a new self-contained proof of the full two-sided Banach-bundle HPS theorem.

## Citation caution

The finite-dimensional graph-transform mechanism is cited to Hirsch--Pugh--Shub. Banach-space invariant-manifold literature is cited through Bates--Lu and Bates--Lu--Zeng. The manuscript avoids giving an unsupported theorem number or page-specific claim and phrases the import as the structural HPS/Banach graph-transform input.

## Implemented changes

1. Section 4 now says Theorem 4.1 uses the full two-sided HPS Hadamard graph transform.
2. It states that the separate stable-forward/unstable-backward component transform is not used.
3. Appendix J records the external theorem and the reduction from tubular coordinates.
4. Appendix J explains why affine counterexamples only refute the naive componentwise substitute.
5. Reference [9] was added for Bates--Lu--Zeng's Banach-space invariant-manifold monograph.
'''
Path('/home/user/external_hps_closure_evaluation_report.md').write_text(report)
