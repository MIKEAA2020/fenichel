from pathlib import Path
p=Path('/home/user/final_manuscript_next_gaps.md')
s=p.read_text()

s=s.replace('''where \\(B_\\varepsilon\\) is the perturbed normal cocycle. The cocycle \\(B_\\varepsilon\\) is \\(C^0\\)-close to \\(B\\), and \\(f_\\varepsilon\\) is \\(C^1\\)-close to \\(f\\). Roughness of exponential dichotomies gives an exponential dichotomy for \\(B_\\varepsilon\\), possibly with weakened rates. Appendix C proves the fixed-base Banach-bundle roughness estimate by a linear half-line Perron argument; the equivalent close-base formulation follows after the usual bundle transports and is the standard roughness theorem of Palmer [6]. Equivalently, we obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original stable and unstable summands.''',
'''where \\(B_\\varepsilon\\) is the perturbed normal cocycle. The cocycle \\(B_\\varepsilon\\) is \\(C^0\\)-close to \\(B\\), and \\(f_\\varepsilon\\) is \\(C^1\\)-close to \\(f\\). Roughness of exponential dichotomies gives an exponential dichotomy for \\(B_\\varepsilon\\), possibly with weakened rates. Appendix C proves the fixed-base Banach-bundle roughness estimate by a linear half-line Perron argument, and Appendix E gives a direct close-base linear graph-transform proof under the transported block estimates used here; this is the standard roughness theorem of Palmer [6] in the present bundle notation. Equivalently, we obtain the perturbed stable and unstable bundles as invariant graphs of linear maps between the original stable and unstable summands.''')

appendix_e = r'''
## Appendix E. Close-base roughness by a linear graph transform

Appendix C proves fixed-base roughness. This appendix records a direct close-base graph-transform version sufficient for the normal-splitting argument in Theorem 5.1. The statement is deliberately formulated in transported block coordinates; those are the coordinates obtained by identifying the fibre over \(\widetilde f(m)\) with the nearby fibre over \(f(m)\), or conversely, using the connection.

### E.1. Statement

Let \(E=E^s\oplus E^u\) be a Banach bundle over compact \(M\), with uniformly bounded projections. Let \(\widetilde f:M\to M\) be a homeomorphism. Let

\[
A_m:E_m\to E_{\widetilde f(m)}
\]

be a bundle automorphism. Write its block form with respect to the original splitting at \(m\) and at \(\widetilde f(m)\):

\[
A_m=
\begin{pmatrix}
A_m^{ss} & A_m^{su}\\
A_m^{us} & A_m^{uu}
\end{pmatrix}.
\]

Assume that \(A_m^{uu}:E_m^u\to E_{\widetilde f(m)}^u\) is invertible and that, in an adapted norm, there are constants

\[
0<\alpha<1,
\qquad
0<\beta<1,
\qquad
\delta>0
\]

such that, uniformly in \(m\),

\[
\|A_m^{ss}\|\le\alpha,
\qquad
\|(A_m^{uu})^{-1}\|\le\beta,
\]

and

\[
\|A_m^{su}\|+
\|A_m^{us}\|\le\delta.
\]

If \(\delta\) is sufficiently small, then there is a unique invariant stable bundle of the form

\[
\widetilde E_m^s=
\{a+L_m^s a:a\in E_m^s\},
\qquad
L_m^s:E_m^s\to E_m^u,
\]

with

\[
\sup_m\|L_m^s\|\le C\delta.
\]

It satisfies

\[
A_m\widetilde E_m^s=
\widetilde E_{\widetilde f(m)}^s.
\]

Similarly, if \(A_m^{ss}\\) is invertible and \(\|(A_m^{ss})^{-1}\|\le \widetilde\beta<1\) for the inverse-time estimates, there is an invariant unstable bundle

\[
\widetilde E_m^u=
\{b+L_m^u b:b\in E_m^u\},
\qquad
\sup_m\|L_m^u\|\le C\delta.
\]

The resulting splitting is a small perturbation of \(E^s\oplus E^u\), and the corresponding projections are uniformly bounded.

### E.2. Stable graph transform

Let \(\mathcal X_R\) be the complete metric space of continuous sections

\[
L_m:E_m^s\to E_m^u,
\qquad
\sup_m\|L_m\|\le R,
\]

with the \(C^0\) operator norm. We define a transform \(\mathfrak T\) on \(\mathcal X_R\).

Given \(L\in\mathcal X_R\), for each \(m\) define \((\mathfrak T L)_m=X_m\) as the unique solution of

\[
X_m
=
(A_m^{uu})^{-1}
\left[
L_{\widetilde f(m)}(A_m^{ss}+A_m^{su}X_m)-A_m^{us}
\right].
\]

For fixed \(L\), the right-hand side is a contraction in \(X_m\), since

\[
\|(A_m^{uu})^{-1}\|\,
\|L_{\widetilde f(m)}\|\,
\|A_m^{su}\|
\le
\beta R\delta.
\]

Choose \(R\) and \(\delta\) so that \(\beta R\delta<1/2\). Then \(X_m\) exists uniquely and depends continuously on \(m\).

The bound

\[
\|X_m\|
\le
\frac{\beta(R\alpha+
\delta)}{1-
\beta R\delta}
\]

shows that, for \(R=C\delta\) and \(\delta\) small, \(\mathfrak T\) maps \(\mathcal X_R\) into itself.

### E.3. Contraction of the graph transform

Let \(L,L'\in\mathcal X_R\), and write

\[
X_m=(\mathfrak T L)_m,
\qquad
X_m'=(\mathfrak T L')_m.
\]

Subtracting the defining equations gives

\[
\begin{aligned}
X_m-X_m'
&=(A_m^{uu})^{-1}
\Bigl[
(L_{\widetilde f(m)}-L'_{\widetilde f(m)})(A_m^{ss}+A_m^{su}X_m)\\
&\qquad
+L'_{\widetilde f(m)}A_m^{su}(X_m-X_m')
\Bigr].
\end{aligned}
\]

Therefore

\[
\|X_m-X_m'\|
\le
\frac{\beta(
\alpha+
\delta R)}{1-
\beta R\delta}
\|L-L'\|_{C^0}.
\]

Since \(\alpha<1\) and \(\beta<1\), the constant is strictly less than one for \(\delta\) small. Hence \(\mathfrak T\) is a contraction. It has a unique fixed point \(L^s\in\mathcal X_R\).

### E.4. Invariance and estimates

Let

\[
\widetilde E_m^s=
\operatorname{graph}L_m^s.
\]

If \(v=a+L_m^s a\), then

\[
A_m v
=
(A_m^{ss}+A_m^{su}L_m^s)a
+
(A_m^{us}+A_m^{uu}L_m^s)a.
\]

The fixed-point equation is exactly

\[
A_m^{us}+A_m^{uu}L_m^s
=
L_{\widetilde f(m)}^s(A_m^{ss}+A_m^{su}L_m^s).
\]

Thus

\[
A_m\operatorname{graph}L_m^s
\subset
\operatorname{graph}L_{\widetilde f(m)}^s.
\]

Since \(A_m\) is invertible and the graph map is close to the original stable space, the inclusion is equality. The graph bound gives

\[
\sup_m\|L_m^s\|\le C\delta.
\]

For \(v\in\widetilde E_m^s\), its stable coordinate evolves by

\[
a_{n+1}=(A_{m_n}^{ss}+A_{m_n}^{su}L_{m_n}^s)a_n.
\]

Hence

\[
\|a_{n+1}\|
\le
(\alpha+
\delta C\delta)
\|a_n\|.
\]

For \(\delta\) small, this gives any weakened stable rate larger than \(\alpha\). Norm equivalence between the graph norm and the ambient norm yields the corresponding exponential estimate on \(\widetilde E^s\).

### E.5. Unstable graph and splitting

The unstable bundle follows by applying the same argument to \(A^{-1}\) over \(\widetilde f^{-1}\), or equivalently by solving the symmetric graph equation for maps \(L_m^u:E_m^u\to E_m^s\). This gives

\[
\widetilde E_m^u=
\operatorname{graph}L_m^u,
\qquad
\sup_m\|L_m^u\|\le C\delta,
\]

and backward exponential estimates with weakened rates.

If \(\delta\) is small, both graph maps have norm less than one. Therefore

\[
E_m=
\widetilde E_m^s\oplus\widetilde E_m^u
\]

and the associated projections are uniformly bounded. The perturbed projections differ from the original projections by \(O(\delta)\). This proves close-base roughness under the transported block estimates.

---
'''
# Fix possible accidental breaks
appendix_e=appendix_e.replace('A_m^{ss}\\', 'A_m^{ss}')
appendix_e=appendix_e.replace('R\delta', 'R\delta')
appendix_e=appendix_e.replace('R\delta', 'R\delta')
appendix_e=appendix_e.replace('R\delta', 'R\delta')
appendix_e=appendix_e.replace('R\delta', 'R\delta')
appendix_e=appendix_e.replace('R\delta', 'R\delta')
appendix_e=appendix_e.replace('\n\delta)}', '\n\delta)}')
appendix_e=appendix_e.replace('\n\\delta)}', '\n\\delta)}')
# insert before references
marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_e+'\n## References')

# update summary
s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, and Appendix D proves the one-sided normally attracting Banach-bundle graph transform.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, and Appendix E proves close-base roughness under transported block estimates.''')

out=Path('/home/user/final_manuscript_more_gaps_closed.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
