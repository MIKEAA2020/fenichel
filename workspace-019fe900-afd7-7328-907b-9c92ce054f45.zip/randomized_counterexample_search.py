from pathlib import Path
import math, json, random
import numpy as np

rng = np.random.default_rng(20260809)
random.seed(20260809)
results=[]

def add(name, ok, detail):
    results.append({'check': name, 'ok': bool(ok), 'detail': detail})

def rot(t):
    c,s=math.cos(t), math.sin(t)
    return np.array([[c,-s],[s,c]],float)

def trial_green(N=31, shift=7, K=120, variable_splitting=True):
    # random but hyperbolic cocycle over periodic base, target-fibre splitting Q[f(i)] diag(a,b) Q[i]^T
    if math.gcd(N, shift)!=1:
        raise ValueError('shift must be coprime')
    if variable_splitting:
        angles = rng.uniform(0, 2*np.pi, size=N)
    else:
        angles = np.zeros(N)
    Q=np.array([rot(t) for t in angles])
    a=rng.uniform(0.15,0.72,size=N)
    b=rng.uniform(1.25,3.8,size=N)
    B=np.empty((N,2,2)); Ps=np.empty((N,2,2)); Pu=np.empty((N,2,2)); q=np.empty((N,2))
    for i in range(N):
        fi=(i+shift)%N
        B[i]=Q[fi]@np.diag([a[i],b[i]])@Q[i].T
        Ps[i]=Q[i]@np.diag([1.,0.])@Q[i].T
        Pu[i]=Q[i]@np.diag([0.,1.])@Q[i].T
        q[i]=Q[fi]@rng.normal(size=2)
    A=np.zeros((2*N,2*N)); rhs=np.zeros(2*N)
    for i in range(N):
        fi=(i+shift)%N
        A[2*i:2*i+2, 2*fi:2*fi+2]+=np.eye(2)
        A[2*i:2*i+2, 2*i:2*i+2]-=B[i]
        rhs[2*i:2*i+2]=q[i]
    z=np.linalg.solve(A,rhs).reshape(N,2)
    def stable_forward(base,n,k):
        prod=1.0
        for ell in range(k,n):
            idx=(base+ell*shift)%N
            prod*=a[idx]
        return Q[(base+n*shift)%N]@np.diag([prod,0.])@Q[(base+k*shift)%N].T
    def unstable_backward(base,n,k):
        prod=1.0
        for ell in range(n,k):
            idx=(base+ell*shift)%N
            prod*=1.0/b[idx]
        return Q[(base+n*shift)%N]@np.diag([0.,prod])@Q[(base+k*shift)%N].T
    def green(base, wrong=False):
        total=np.zeros(2)
        for j in range(-K,0):
            src=(base+j*shift)%N; tgt=(base+(j+1)*shift)%N
            P=Ps[src] if wrong else Ps[tgt]
            total += stable_forward(base,0,j+1)@(P@q[src])
        for j in range(0,K+1):
            src=(base+j*shift)%N; tgt=(base+(j+1)*shift)%N
            P=Pu[src] if wrong else Pu[tgt]
            total += -unstable_backward(base,0,j+1)@(P@q[src])
        return total
    bases=list(range(min(N,10)))
    good=max(np.linalg.norm(green(base,False)-z[base],np.inf) for base in bases)
    bad=max(np.linalg.norm(green(base,True)-z[base],np.inf) for base in bases)
    return good,bad,np.linalg.cond(A),max(a),min(b)

# Randomized valid-case stress test
num=200
good_errors=[]; wrong_errors=[]; conds=[]
failures=[]
for t in range(num):
    N=int(rng.choice([17,19,23,29,31,37]))
    cop=[s for s in range(2,N) if math.gcd(s,N)==1]
    shift=int(rng.choice(cop))
    try:
        good,bad,cond,maxa,minb=trial_green(N,shift,K=140,variable_splitting=True)
        good_errors.append(good); wrong_errors.append(bad); conds.append(cond)
        if good>1e-8:
            failures.append((t,N,shift,good,bad,cond,maxa,minb))
    except Exception as e:
        failures.append((t,'EXC',str(e)))
add('random_valid_hyperbolic_green_formula_trials', len(failures)==0,
    f"trials={num}, max correct error={max(good_errors):.2e}, median={np.median(good_errors):.2e}, max cond={max(conds):.2e}, failures={failures[:3]}")
# Wrong projection should fail in most variable-splitting trials.
wrong_large=sum(1 for e in wrong_errors if e>1e-3)
add('random_wrong_source_projection_counterexamples_found', wrong_large > 0.9*num,
    f"wrong projection error >1e-3 in {wrong_large}/{num}; median wrong error={np.median(wrong_errors):.2e}; max={max(wrong_errors):.2e}")

# If splitting is constant, source/target projections coincide; this is a control that wrong projection counterexample depends on varying fibres.
const_good=[]; const_wrong=[]
for t in range(20):
    good,bad,_,_,_=trial_green(23,5,K=120,variable_splitting=False)
    const_good.append(good); const_wrong.append(bad)
add('constant_splitting_control_source_equals_target_projection', max(const_wrong)<1e-10,
    f"constant splitting: max wrong-projection error={max(const_wrong):.2e}, max correct={max(const_good):.2e}")

# Randomized attempts to violate stable-fibre convolution hypotheses and find blow-up.
def safe_exp(x):
    if x > 700:
        return float('inf')
    if x < -745:
        return 0.0
    return math.exp(x)

def conv_sups(alpha,beta,gamma,nmax=120):
    stable=[]; cu=[]
    for n in range(nmax+1):
        # Weighted stable term exponent: gamma*n - alpha*(n-k-1) - 2*gamma*k
        ss=0.0
        if alpha <= 0:
            ss=float('inf')
        else:
            for k in range(n):
                term=safe_exp(gamma*n - alpha*(n-k-1) - 2*gamma*k)
                ss += term
                if math.isinf(ss): break
        stable.append(ss)
        # Weighted cu term exponent: gamma*n + beta*(k+1-n) - 2*gamma*k
        cs=0.0
        for k in range(n,nmax+400):
            term=safe_exp(gamma*n + beta*(k+1-n) - 2*gamma*k)
            cs += term
            if math.isinf(cs): break
        cu.append(cs)
    return max(stable),max(cu)
valid_ok=0; invalid_bad=0; invalid_examples=[]
for _ in range(300):
    alpha=rng.uniform(0.5,2.5)
    beta=rng.uniform(0.0,1.5)
    # half valid, half invalid
    if rng.random()<0.5 and beta+0.002<alpha:
        gamma=rng.uniform(beta+1e-3, alpha-1e-3)
        ss,cs=conv_sups(alpha,beta,gamma)
        if ss<50 and cs<50: valid_ok+=1
    else:
        # violate either gamma<alpha or beta<gamma
        if rng.random()<0.5:
            gamma=rng.uniform(alpha+0.02, alpha+1.0)  # stable convolution should grow
        else:
            gamma=rng.uniform(0.01, max(0.02,beta-0.02)) if beta>0.03 else rng.uniform(alpha+0.1,alpha+1.0)
        ss,cs=conv_sups(alpha,beta,gamma)
        if ss>1e4 or cs>1e4 or math.isinf(ss) or math.isinf(cs):
            invalid_bad+=1
            if len(invalid_examples)<3: invalid_examples.append((alpha,beta,gamma,ss,cs))
add('random_rate_gap_valid_cases_bounded', valid_ok>100,
    f"valid bounded cases={valid_ok}; tested random beta<gamma<alpha")
add('random_rate_gap_violations_produce_counterexamples', invalid_bad>50,
    f"invalid blow-up cases={invalid_bad}; examples={invalid_examples}")

# Randomized parabolic convolution: valid vs invalid rho/gamma conditions.
from scipy.integrate import quad
valid_p=0; invalid_p=0; inv_ex=[]
for _ in range(120):
    rho=rng.uniform(0.05,0.95); alpha=rng.uniform(0.5,2.0); gamma=rng.uniform(0.01,alpha-0.01)
    bound=math.gamma(1-rho)/((alpha-gamma)**(1-rho))
    val,_=quad(lambda u: u**(-rho)*math.exp(-(alpha-gamma)*u),0,50,points=[0],limit=200)
    if val<1.001*bound: valid_p+=1
for _ in range(80):
    # invalid gamma>=alpha: integral grows like exp((gamma-alpha)u), sample large t representation over u integral diverges
    rho=rng.uniform(0.05,0.95); alpha=rng.uniform(0.5,1.5); gamma=rng.uniform(alpha+0.05,alpha+0.8)
    # finite cutoff integral at T=80 is already large for many cases
    val,_=quad(lambda u: u**(-rho)*math.exp((gamma-alpha)*u),1e-8,60,limit=200)
    if val>1e5:
        invalid_p+=1
        if len(inv_ex)<3: inv_ex.append((rho,alpha,gamma,val))
add('random_parabolic_valid_convolution_matches_bound', valid_p==120,
    f"valid parabolic trials matching gamma-bound={valid_p}/120")
add('random_parabolic_gamma_ge_alpha_counterexamples', invalid_p>30,
    f"invalid gamma>=alpha large-growth cases={invalid_p}/80; examples={inv_ex}")

# Random HPS constants: find both valid and invalid choices.
valid_hps=0; invalid_hps=0
for _ in range(200):
    C=rng.uniform(1,5); gap=rng.uniform(0.2,2.0); N=int(rng.integers(5,35))
    delta=10**rng.uniform(-5,-2); omega=10**rng.uniform(-4,-1.3); L=10**rng.uniform(-4,-1.3); rho=10**rng.uniform(-2,0)
    q=C*(math.exp(-gap*N)+delta+omega+L)
    if q<1 and C*delta+q*rho<=rho: valid_hps+=1
    # deliberately bad large L/omega or small N
    Cb=rng.uniform(2,8); gapb=rng.uniform(0.1,0.4); Nb=int(rng.integers(1,4)); deltab=rng.uniform(0.02,0.2); omegab=rng.uniform(0.1,0.5); Lb=rng.uniform(0.1,0.6); rhob=rng.uniform(0.01,0.2)
    qb=Cb*(math.exp(-gapb*Nb)+deltab+omegab+Lb)
    if qb>=1 or Cb*deltab+qb*rhob>rhob: invalid_hps+=1
add('random_hps_constant_selection_valid_examples_exist', valid_hps>50,
    f"valid random choices={valid_hps}/200")
add('random_hps_bad_constants_fail_as_expected', invalid_hps==200,
    f"bad choices failing contraction/radius={invalid_hps}/200")

all_ok=all(r['ok'] for r in results)
lines=[]
lines.append('# Randomized Counterexample Search Report')
lines.append('')
lines.append('This search tries to falsify the manuscript formulae in random finite-dimensional models and also deliberately violates hypotheses to see whether the estimates fail as expected.')
lines.append('')
lines.append(f'Overall status: **{"PASS" if all_ok else "ISSUES FOUND"}**')
lines.append('')
for r in results:
    lines.append(f"- {'✅' if r['ok'] else '❌'} **{r['check']}** — {r['detail']}")
lines.append('')
lines.append('## Interpretation')
lines.append('')
lines.append('- No randomized valid hyperbolic cocycle trial falsified the Green formula.')
lines.append('- Random varying-splitting trials produced many counterexamples to the wrong source-fibre projection convention, supporting the target-fibre projection used in the manuscript.')
lines.append('- Deliberate violations of the rate-gap and parabolic smoothing hypotheses produced blow-up or loss of contraction as expected.')
lines.append('- These are randomized finite-dimensional falsification tests, not proofs of the infinite-dimensional theorems.')
Path('/home/user/randomized_counterexample_report.md').write_text('\n'.join(lines))
print(json.dumps({'overall_ok':all_ok,'results':results}, indent=2))
