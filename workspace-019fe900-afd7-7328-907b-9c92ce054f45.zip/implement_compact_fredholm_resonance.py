from pathlib import Path

frac_path=Path('/home/user/fractional_jet_spectrum_research_note.md')
frac=frac_path.read_text()
insert_frac=r'''
---

## 8. Compact return maps and Fredholm resonance

The obstruction in Proposition 7.1 is stated as failure of surjectivity of

\[
I-\mathfrak R_{\le k}(p).
\]

In general Banach spaces this is the correct formulation: non-surjectivity need not be caused by an eigenvector. In compact or smoothing settings, however, the obstruction becomes an ordinary eigenvalue resonance.

### Theorem 8.1. Compact jet-return Fredholm alternative

Let \(Y\) be a Banach space and let

\[
K:Y\to Y
\]

be compact. If

\[
I-K
\]

is not surjective, then \(1\) is an eigenvalue of \(K\). Moreover, this eigenvalue has finite algebraic multiplicity.

Consequently, if the periodic jet-return operator

\[
\mathfrak R_{\le k}(p):\mathfrak J_{\le k,p}\to\mathfrak J_{\le k,p}
\]

is compact and if

\[
I-\mathfrak R_{\le k}(p)
\]

is not surjective, then there exists a nonzero jet

\[
J\in\mathfrak J_{\le k,p}
\]

such that

\[
\mathfrak R_{\le k}(p)J=J.
\]

Thus, in compact-return settings, the periodic obstruction is an eigenvalue-one resonance of finite algebraic multiplicity.

#### Proof

For a compact operator \(K\) on a Banach space, the Riesz--Schauder theorem states that every nonzero point of the spectrum of \(K\) is an eigenvalue of finite algebraic multiplicity, and the only possible accumulation point of the spectrum is \(0\). If \(I-K\) is not surjective, then \(I-K\) is not invertible; hence \(1\in\sigma(K)\). Since \(1\ne0\), Riesz--Schauder implies that \(1\) is an eigenvalue of finite algebraic multiplicity. Applying this to \(K=\mathfrak R_{\le k}(p)\) proves the claim. ∎

### Corollary 8.2. Parabolic compact-return case

Assume a parabolic or smoothing setting in which the linear time-return map along a periodic orbit is compact on the chosen normal fibre space, for example because the sectorial generator has compact resolvent and the return time is positive. Since the tangent jet factors are finite-dimensional, the induced finite jet-return map

\[
\mathfrak R_{\le k}(p)
\]

is compact on the Banach jet fibre. Therefore any failure of surjectivity of

\[
I-\mathfrak R_{\le k}(p)
\]

is equivalent to the existence of an eigen-jet with eigenvalue \(1\).

Without compactness, Proposition 7.1 should not be strengthened in this way: the obstruction may lie in point, continuous, or residual spectrum. The correct general statement remains non-surjectivity of \(I-\mathfrak R_{\le k}(p)\).

'''
marker='---\n\n## 8. Witness: first-jet resonance on a two-cycle'
assert marker in frac
frac=frac.replace(marker, insert_frac+'---\n\n## 9. Witness: first-jet resonance on a two-cycle')
# renumber later sections 9->10 etc maybe existing headings; current has ## 9 Regularity, ##10 examples.
frac=frac.replace('## 9. Regularity spectrum','## 10. Regularity spectrum')
frac=frac.replace('## 10. Model examples','## 11. Model examples')
frac_path.write_text(frac)

main_path=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
main=main_path.read_text()
insert_main=r'''
---

### K.7. Compact return maps and Fredholm resonance

The obstruction in Proposition K.2 is stated as failure of surjectivity of

\[
I-\mathfrak R_{\le k}(p).
\]

In general Banach spaces this is the correct formulation: non-surjectivity need not be caused by an eigenvector. In compact or smoothing settings, however, the obstruction becomes an ordinary eigenvalue resonance.

**Theorem K.3. Compact jet-return Fredholm alternative.** Let \(Y\) be a Banach space and let \(K:Y\to Y\) be compact. If \(I-K\) is not surjective, then \(1\) is an eigenvalue of \(K\), with finite algebraic multiplicity.

Consequently, if the periodic jet-return operator

\[
\mathfrak R_{\le k}(p):\mathfrak J_{\le k,p}\to\mathfrak J_{\le k,p}
\]

is compact and if

\[
I-\mathfrak R_{\le k}(p)
\]

is not surjective, then there exists a nonzero jet

\[
J\in\mathfrak J_{\le k,p}
\]

such that

\[
\mathfrak R_{\le k}(p)J=J.
\]

Thus, in compact-return settings, the periodic obstruction is an eigenvalue-one resonance of finite algebraic multiplicity.

The proof is the Riesz--Schauder theorem: if \(I-K\) is not surjective, then \(I-K\) is not invertible, so \(1\in\sigma(K)\). Since \(1\ne0\) and \(K\) is compact, \(1\) is an eigenvalue of finite algebraic multiplicity.

**Corollary K.4. Parabolic compact-return case.** Assume a parabolic or smoothing setting in which the linear time-return map along a periodic orbit is compact on the chosen normal fibre space, for example because the sectorial generator has compact resolvent and the return time is positive. Since the tangent jet factors are finite-dimensional, the induced finite jet-return map \(\mathfrak R_{\le k}(p)\) is compact on the Banach jet fibre. Therefore any failure of surjectivity of \(I-\mathfrak R_{\le k}(p)\) is equivalent to the existence of an eigen-jet with eigenvalue \(1\).

Without compactness, Proposition K.2 should not be strengthened in this way: the obstruction may lie in point, continuous, or residual spectrum. The correct general statement remains non-surjectivity of \(I-\mathfrak R_{\le k}(p)\).

'''
marker_main='---\n\n### K.7. Witness: first-jet resonance on a two-cycle'
assert marker_main in main
main=main.replace(marker_main, insert_main+'---\n\n### K.8. Witness: first-jet resonance on a two-cycle')
main=main.replace('### K.8. Regularity spectrum','### K.9. Regularity spectrum')
main=main.replace('### K.9. Model examples','### K.10. Model examples')
main=main.replace('#### K.9.1. Hyperbolic toral base','#### K.10.1. Hyperbolic toral base')
main=main.replace('#### K.9.2. Isometric base dynamics','#### K.10.2. Isometric base dynamics')
main_path.write_text(main)
print('updated')
