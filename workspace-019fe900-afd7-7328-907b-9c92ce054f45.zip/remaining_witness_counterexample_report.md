# Witness and Counterexample Verification for Remaining Items

This report verifies appendices and claims that were not covered by earlier witness-level checks, especially Appendix H (global stable fibres) and Appendix I (noncompact uniform cohomological inverse).

Overall: **PASS**

## ✅ H1_global_stable_union_by_iteration_witness

For F(y)=y/2 and local tube (-rho,rho), every sampled y enters the local stable tube after N iterates; W^s is the union of F^{-N}(W_loc).

```json
{
  "rho": 0.1,
  "samples_(y,N,enters,tracking_error)": [
    [
      0.03,
      0,
      true,
      0.0
    ],
    [
      0.2,
      1,
      true,
      0.0
    ],
    [
      1.0,
      4,
      true,
      0.0
    ],
    [
      10.0,
      7,
      true,
      0.0
    ],
    [
      -7.5,
      7,
      true,
      0.0
    ]
  ]
}
```

## ✅ H2_phase_projection_independence_witness

For the same model, the global phase projection pi^s(y)=0 is independent of the entry time N.

```json
{
  "samples_(y,phase_N,phase_Nplus1,agree)": [
    [
      0.03,
      0,
      0,
      true
    ],
    [
      0.2,
      0,
      0,
      true
    ],
    [
      1.0,
      0,
      0,
      true
    ],
    [
      10.0,
      0,
      0,
      true
    ],
    [
      -7.5,
      0,
      0,
      true
    ]
  ]
}
```

## ✅ H3_domain_assumption_counterexample

If F(y)=y/2 is only defined on (-1,1), the point y=2 cannot be included in a global stable set by inverse iteration; Appendix H correctly requires intermediate iterates to remain in the domain.

```json
{
  "local_domain": [
    -1,
    1
  ],
  "test_point": 2.0,
  "in_domain": false
}
```

## ✅ H4_noninvertible_equality_counterexample

For a noninvertible map such as F(y)=y^2 on R with W=R, F(W)=[0,infty) is not W; equality in Appendix H requires a diffeomorphism/domain condition.

```json
{
  "map": "F(y)=y^2",
  "W": "R",
  "F(W)": "[0,infty)",
  "equality": false
}
```

## ✅ I1_noncompact_uniform_scalar_inverse_witness

On noncompact M=R with f=id and B=1/2, the inverse on C_b^0 is explicit: z=2q and ||z||_infty<=2||q||_infty.

```json
{
  "max_residual": 0.0,
  "norm_q": 0.9755452191726695,
  "norm_z": 1.951090438345339,
  "bound_ratio": 2.0
}
```

## ✅ I2_noncompact_shift_green_formula_finite_support_witness

On M=Z with shift base and constant dichotomy, the Green formula solves the bounded cohomological equation for finite-support forcing.

```json
{
  "max_residual": 2.220446049250313e-16,
  "a_s": 0.4,
  "b_u": 2.0
}
```

## ✅ I3_nonuniform_dichotomy_inverse_unbounded_counterexample

Without uniform contraction, bounded q need not have bounded solution: f=id, B(x)=1-1/(1+|x|), q=1 gives z(x)=1+|x|.

```json
{
  "x_values": [
    0.0,
    1.0,
    10.0,
    100.0,
    1000.0
  ],
  "B_values": [
    0.0,
    0.5,
    0.9090909090909091,
    0.9900990099009901,
    0.999000999000999
  ],
  "solution_values": [
    1.0,
    2.0,
    10.999999999999996,
    100.99999999999991,
    1001.0000000000339
  ]
}
```

## ✅ I4_Cb1_norm_needed_witness

The C_b^1 estimate must measure derivative norms: q=sin(Nx) has derivative N and z=2q has derivative 2N. Sup norm alone cannot control C^1 output.

```json
{
  "(N,||q_prime||,||z_prime||,ratio)": [
    [
      1,
      1,
      2,
      2.0
    ],
    [
      10,
      10,
      20,
      2.0
    ],
    [
      100,
      100,
      200,
      2.0
    ],
    [
      1000,
      1000,
      2000,
      2.0
    ]
  ]
}
```

## ✅ E1_close_base_scalar_graph_exact_witness

Exact scalar close-base graph equation has a small invariant graph root and the graph-transform contraction factor is <1.

```json
{
  "alpha": 0.5,
  "Auu": 2.5,
  "Asu": 0.03,
  "Aus": -0.02,
  "roots": [
    0.01000150045016882,
    66.6566651662165
  ],
  "small_root": 0.01000150045016882,
  "invariance_residual": -8.673617379884035e-19,
  "contraction_factor": 0.2001440388937432
}
```

## Interpretation

- Appendix H is supported by an explicit global-stable construction for F(y)=y/2 and by counterexamples showing why domain and invertibility hypotheses are needed.
- Appendix I is supported by exact noncompact scalar and shift models, and by counterexamples showing why uniform contraction and C_b^k norms are necessary.
- Appendix E receives an additional exact scalar graph-transform witness.