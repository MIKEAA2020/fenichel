from pathlib import Path
p=Path('/home/user/final_manuscript_more_gaps_closed.md')
s=p.read_text()

# Add reference in Section 5 parameter expansion paragraph.
s=s.replace('''Differentiating the invariance equation gives the coefficients \\(h_j\\) recursively. At each order one solves a linear cohomological equation of the form treated in Theorem 3.1.''',
'''Differentiating the invariance equation gives the coefficients \\(h_j\\) recursively. At each order one solves a linear cohomological equation of the form treated in Theorem 3.1. Appendix F records the abstract expansion argument and the recursive coefficient equations.''')

appendix_f = r'''
## Appendix F. Parameter expansions of invariant sections

This appendix justifies the expansion statement used in Theorem 5.1. It is an abstract consequence of the graph equation, the cohomological inverse, and the parameter differentiability supplied by the invariant-section theorem. It does not add new dynamical hypotheses; it records exactly what the expansion coefficients solve once parameter regularity is available.

### F.1. Abstract formulation

Let \(X_r\) and \(Y_r\) be Banach spaces of sections, for example

\[
X_r=\Gamma^r(E),
\qquad
Y_r=\Gamma^r(f^*E),
\]

or the corresponding transported difference-quotient spaces. Let

\[
\Psi:(-
\varepsilon_0,
\varepsilon_0)\times U	o Y_r,
\qquad
(\varepsilon,h)
\mapsto
\Psi_\varepsilon(h),
\]

be the transported graph residual, with \(U\subset X_r\) a neighbourhood of the zero section. Assume

\[
\Psi_0(0)=0,
\]

and

\[
D_h\Psi_0(0)=\mathcal A,
\]

where

\[
\mathcal A h=h\circ f-Bh
\]

is the cohomological operator. Assume that \(\mathcal A:X_r
to Y_r\) is an isomorphism and that \(\Psi\) is \(C^{N+1}\) in \((\varepsilon,h)\) in the section topologies under consideration. Then the Banach implicit function theorem gives a unique \(C^{N+1}\) curve

\[
\varepsilon\mapsto h_\varepsilon
a
\in X_r
\]

with

\[
\Psi_\varepsilon(h_\varepsilon)=0,
\qquad
h_0=0.
\]

The HPS graph transform supplies this curve in the manuscript. The point here is that, once it is known to be sufficiently differentiable in \(\varepsilon\), the coefficient equations follow by differentiating \(\Psi_\varepsilon(h_\varepsilon)=0\).

### F.2. First coefficient

Let

\[
\eta_j:=\partial_\varepsilon^j h_\varepsilon|_{\varepsilon=0}.
\]

Differentiating once gives

\[
D_\varepsilon\Psi_0(0)+D_h\Psi_0(0)\eta_1=0.
\]

Thus

\[
\mathcal A\eta_1
=
-\partial_\varepsilon\Psi_0(0),
\]

and therefore

\[
\eta_1
=
-\mathcal G\,
\partial_\varepsilon\Psi_0(0).
\]

This is the first-order cohomological equation for the displacement of the invariant graph.

### F.3. Higher coefficients

For \(n\ge2\), differentiating \(n\) times gives

\[
\mathcal A\eta_n+R_n(
\eta_1,
\ldots,
\eta_{n-1})=0,
\]

where \(R_n\) is a universal finite sum of derivatives of \(\Psi\) at \((0,0)\) applied to the previously computed coefficients. Explicitly,

\[
R_n
=
\sum_{
\substack{a+b\ge1,\ a\le n,\ b\le n\\
(a,b)\ne(0,1)}}
C_{a,b,n}
D_\varepsilon^aD_h^b\Psi_0(0)
[
\eta_{j_1},
\ldots,
\eta_{j_b}
],
\]

where the sum is over indices satisfying

\[
a+j_1+
\cdots+j_b=n,
\qquad
1\le j_i
e n.
\]

The term \((a,b)=(0,1)\) with \(j_1=n\) is precisely \(\mathcal A\eta_n\) and is excluded from \(R_n\). Hence

\[
\eta_n
=
-
\mathcal G R_n(
\eta_1,
\ldots,
\eta_{n-1}).
\]

Thus every coefficient is obtained by solving one linear cohomological equation with the same inverse \(\mathcal G\).

### F.4. Expansion with or without factorials

Taylor's theorem gives

\[
h_\varepsilon
=
\sum_{j=1}^{N}
\frac{
\varepsilon^j}{j!}
\eta_j
+O(\varepsilon^{N+1})
\]

in \(X_r\). If one writes the expansion in the form

\[
h_\varepsilon
=
\varepsilon h_1+
\varepsilon^2 h_2+
\cdots+
\varepsilon^N h_N
+O(\varepsilon^{N+1}),
\]

then

\[
h_j=\frac{1}{j!}\eta_j.
\]

In the tubular coordinates used in the manuscript, the unperturbed invariant manifold is the zero section, so the constant coefficient is

\[
h_0=0.
\]

### F.5. Bounds and remainder

If \(\Psi\) is \(C^{N+1}\) with bounded derivatives on a neighbourhood of \((0,0)\), Taylor's theorem in Banach spaces gives

\[
\left\|
h_\varepsilon-
\sum_{j=1}^{N}
\frac{
\varepsilon^j}{j!}
\eta_j
\right\|_{X_r}
\le
C_N|
\varepsilon|^{N+1}.
\]

The constants depend on bounds for the derivatives of \(\Psi\), on the inverse bound for \(\mathcal G\), and on the parameter-bunching constants that give differentiability of \(\varepsilon\mapsto h_\varepsilon\). This proves the expansion statement used in the main text.

---
'''
# fix accidental newline artifacts in raw (some deliberate due wrapping but not broken commands)
appendix_f = appendix_f.replace('(-\n\\varepsilon_0', '(-\\varepsilon_0')
appendix_f = appendix_f.replace('\\mathcal A:X_r\nto Y_r', '\\mathcal A:X_r\\to Y_r')
appendix_f = appendix_f.replace('h_\\varepsilon\na\n\\in', 'h_\\varepsilon\\in')
appendix_f = appendix_f.replace('R_n(\n\\eta_1', 'R_n(\\eta_1')
appendix_f = appendix_f.replace('[\n\\eta_', '[\\eta_')
appendix_f = appendix_f.replace('+\n\\cdots', '+\\cdots')
appendix_f = appendix_f.replace('j_i\ne n', 'j_i<n')
appendix_f = appendix_f.replace('R_n(\n\\eta_1', 'R_n(\\eta_1')
appendix_f = appendix_f.replace('\\frac{\n\\varepsilon', '\\frac{\\varepsilon')
appendix_f = appendix_f.replace('\\left\\|\nh_', '\\left\\|h_')
appendix_f = appendix_f.replace('\\frac{\n\\varepsilon', '\\frac{\\varepsilon')
appendix_f = appendix_f.replace('\\right\\|', '\\right\\|')

marker='''---

## References'''
assert marker in s
s=s.replace(marker, '\n---\n'+appendix_f+'\n## References')

s=s.replace('Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, and Appendix E proves close-base roughness under transported block estimates.',
'''Appendix A supplies a self-contained proof of the smooth-splitting version of the \\(C^k\\) cohomological inverse theorem, Appendix B supplies a self-contained half-line Perron proof of the local strong-fibre theorem, Appendix C proves the fixed-base roughness of exponential dichotomies in Banach bundles, Appendix D proves the one-sided normally attracting Banach-bundle graph transform, Appendix E proves close-base roughness under transported block estimates, and Appendix F proves the parameter-expansion recursion.''')

out=Path('/home/user/final_manuscript_parameter_gap_closed.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
