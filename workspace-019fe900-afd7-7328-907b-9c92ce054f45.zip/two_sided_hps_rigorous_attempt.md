# Rigorous Attempt: Full Two-Sided Banach-Bundle HPS Invariant-Section Theorem

## Executive verdict

I attempted to close the full two-sided Banach-bundle HPS invariant-section theorem. The result is **not a complete closure**. The proof can be pushed to a precise conditional reduction, but one essential lemma remains: the **two-sided Hadamard matching lemma**. This is exactly the finite-dimensional HPS mechanism that is nontrivial even before passing to Banach fibres.

Therefore I should not add a “proof” of the full two-sided theorem to the manuscript unless that matching lemma is either fully proved or precisely cited. The current manuscript is correct to keep Theorem 4.1 as the structural HPS input.

The attempt below records what can be proved cleanly and where the proof stops.

---

## 1. Target theorem

Let \(E=E^s\oplus E^u\to M\) be a Banach bundle over a compact finite-dimensional base, and let

\[
F_\varepsilon(m,\eta)=
(b_\varepsilon(m,\eta),g_\varepsilon^s(m,\eta),g_\varepsilon^u(m,\eta))
\]

be a local bundle diffeomorphism near the zero section. The unperturbed zero section is invariant, and the normal linear part has a stable/unstable exponential dichotomy over \(f\). The goal is to construct an invariant graph

\[
h=h^s+h^u:M\to E^s\oplus E^u
\]

satisfying

\[
F_\varepsilon(m,h(m))
=
(f_h(m),h(f_h(m))).
\]

The proof must handle both a forward-contracting stable direction and a backward-contracting unstable direction.

---

## 2. What can be proved directly

Assume strong transported remainder estimates, including base-derivative estimates, and assume all graph maps below are well-defined in a fixed tube.

For an admissible graph \(h\), define the forward base map

\[
\beta_h^+(m)=b_+(m,h(m))
\]

and the backward base map

\[
\beta_h^-(m)=b_-(m,h(m)),
\]

where \(F^{-1}(m,
\eta)=(b_-(m,
\eta),g_-^s(m,
\eta),g_-^u(m,
\eta))\).

For small \(\rho,L,\delta\), both \(\beta_h^+\) and \(\beta_h^-\) are diffeomorphisms close to \(f\) and \(f^{-1}\), respectively.

One can define two one-sided component transforms:

\[
(H_+^s h)(y)=g_+^s(x,h(x)),
\qquad x=(\beta_h^+)^{-1}(y),
\]

and

\[
(H_-^u h)(x)=g_-^u(y,h(y)),
\qquad y=(\beta_h^-)^{-1}(x).
\]

Then define

\[
Hh:=H_+^s h+H_-^u h.
\]

In the linear model

\[
F(c,s,u)=(f(c),B^s_c s,B^u_c u),
\]

this reduces to

\[
(Hh)^s(f(m))=B_m^s h^s(m),
\]

and

\[
(Hh)^u(m)=(B_m^u)^{-1}h^u(f(m)),
\]

which is contractive in the two normal components.

---

## 3. Direct contraction estimates

Using the same estimates as in the normally attracting graph transform and in the unstable inverse transform, one obtains

\[
\|H_+^s h_1-H_+^s h_2\|_{C^0}
\le
(\nu_s+
\mu)
\|h_1-h_2\|_{C^0},
\]

and

\[
\|H_-^u h_1-H_-^u h_2\|_{C^0}
\le
(\nu_u+
\mu)
\|h_1-h_2\|_{C^0},
\]

where

\[
\nu_s=
\sup_m\|B_m^s\|<1,
\qquad
\nu_u=
\sup_m\|(B_m^u)^{-1}\|<1,
\]

in an adapted norm, and \(\mu\to0\) as the tube radius, graph aperture, and perturbation size tend to zero.

Hence

\[
\|Hh_1-Hh_2\|_{C^0}
\le q\|h_1-h_2\|_{C^0},
\qquad q<1,
\]

for sufficiently small constants.

Similarly, the Lipschitz preservation estimates take the form

\[
\operatorname{Lip}(H_+^s h)
\le
(\nu_{s,1}+
\mu)
\operatorname{Lip}(h)+
\mu,
\]

and

\[
\operatorname{Lip}(H_-^u h)
\le
(\nu_{u,1}+
\mu)
\operatorname{Lip}(h)+
\mu,
\]

where

\[
\nu_{s,1}=
\sup_m\|B_m^s\|\,\|Df(m)^{-1}\|<1,
\]

and

\[
\nu_{u,1}=
\sup_m\|(B_m^u)^{-1}\|\,\|Df(m)\|<1.
\]

Thus the transform \(H\) has a unique fixed point in the admissible class.

This part of the argument uses only Banach-space contraction estimates and is rigorously supportable.

---

## 4. The obstruction: matching does not yet imply invariance

Let \(h\) be the fixed point of \(H\). Then we know:

1. the **stable component** of the forward image of the graph matches the stable component of \(h\):

   \[
   g_+^s(m,h(m))=h^s(\beta_h^+(m));
   \]

2. the **unstable component** of the backward image of the graph matches the unstable component of \(h\):

   \[
   g_-^u(y,h(y))=h^u(\beta_h^-(y)).
   \]

To prove graph invariance, we need

\[
F(m,h(m))=(\beta_h^+(m),h(\beta_h^+(m))).
\]

The stable component is known. The missing part is

\[
g_+^u(m,h(m))=h^u(\beta_h^+(m)).
\]

The backward matching equation gives this only if the forward and backward base matchings are compatible:

\[
\beta_h^-(\beta_h^+(m))=m.
\]

Equivalently,

\[
\beta_h^-=(\beta_h^+)^{-1}.
\]

This is the nontrivial Hadamard matching lemma.

---

## 5. Precise remaining lemma

A full self-contained proof of the two-sided theorem therefore requires the following lemma.

### Hadamard matching lemma

Let \(h\) be a fixed point of the two-sided component transform \(H\) in the admissible class. Then

\[
\beta_h^-\circ\beta_h^+=\operatorname{id}_M
\]

and

\[
\beta_h^+\circ\beta_h^-=
\operatorname{id}_M.
\]

Consequently,

\[
F(m,h(m))=(\beta_h^+(m),h(\beta_h^+(m))).
\]

This lemma is exactly the HPS two-sided matching mechanism. It is not a formal consequence of the separate stable and unstable component contractions written above. It requires an additional argument about unique intersections of the appropriate local stable/unstable plaque constructions, or the original HPS graph-transform proof.

---

## 6. Conditional theorem that follows

The following conditional statement is rigorously supported by the estimates above.

### Conditional two-sided Banach-bundle graph transform theorem

Assume:

1. the stable and unstable component transforms \(H_+^s\) and \(H_-^u\) are well-defined in the admissible class;
2. the \(C^0\) contraction estimates above hold;
3. the Lipschitz preservation estimates above hold;
4. the Hadamard matching lemma holds.

Then there exists a unique admissible Lipschitz section \(h\) satisfying the invariant graph equation

\[
F(m,h(m))=(f_h(m),h(f_h(m))).
\]

The proof is immediate:

- Banach’s fixed-point theorem gives a unique fixed point of \(H\);
- the matching lemma turns that fixed point into an invariant graph;
- the jet-extension argument then gives \(C^r\) regularity under bunching.

Thus the only genuinely unclosed part is the matching lemma plus its jet extension in Banach bundles.

---

## 7. Why this should not be inserted as a proof

The argument above is useful, but it is not a complete proof of the full two-sided Banach-bundle HPS theorem, because the matching lemma remains unproved.

Adding it to the manuscript as a proof would risk the same problem as the rejected Appendix B: it would hide the hardest HPS step under a plausible but unproved assertion.

The manuscript should therefore continue to state Theorem 4.1 as the structural HPS input, while the appendices prove surrounding cases:

- Appendix D proves the one-sided normally attracting graph transform;
- Appendix B proves fixed-orbit stable/unstable fibres;
- Appendix E proves the linear close-base graph transform;
- the full two-sided nonlinear invariant-section theorem remains the imported HPS mechanism.

---

## Final status

I cannot honestly close the full two-sided Banach-bundle HPS invariant-section theorem without proving the Hadamard matching lemma and the associated jet-extension argument. The proof above reduces the problem to that exact lemma and verifies that the Banach-fibre estimates around it are feasible.

So the rigorous attempt sharpens the remaining gap but does not close it.
