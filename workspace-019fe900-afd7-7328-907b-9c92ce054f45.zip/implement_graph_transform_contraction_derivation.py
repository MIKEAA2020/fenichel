from pathlib import Path
p=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
s=p.read_text()
old='''Since \\(b_1(x_1)=b_2(x_2)=y\\) and \\(b_i\\) is uniformly close to \\(f\\), inverse function estimates give

\\[
d_M(x_1,x_2)
\\le
C\\|D_\\eta b_\\varepsilon\\|_{C^0}
\\|h_1-h_2\\|_{C^0}
\\le
\\mu\\|h_1-h_2\\|_{C^0},
\\]

where \\(\\mu=\\mu(\\rho,L,\\delta_\\varepsilon)\\to0\\). Using

\\[
g_\\varepsilon(m,\\eta)=
\\tau_{b_\\varepsilon(m,\\eta)\\leftarrow f(m)}B_m\\eta+r_\\varepsilon(m,\\eta),
\\]

we obtain

\\[
\\|\\mathcal H_\\varepsilon h_1-
\\mathcal H_\\varepsilon h_2\\|_{C^0}
\\le
(\\nu_0+
\\mu)
\\|h_1-h_2\\|_{C^0}.
\\]

Choosing \\(\\rho,L,\\delta_\\varepsilon\\) small gives a contraction factor \\(q<1\\). The radius estimate is'''
new='''Since \\(b_1(x_1)=b_2(x_2)=y\\), write

\\[
b_1(x_1)-b_1(x_2)=b_2(x_2)-b_1(x_2)
\\]

in a local chart on \\(M\\). The right-hand side is controlled by the fibre derivative of \\(b_\\varepsilon\\):

\\[
d_M(b_1(x_2),b_2(x_2))
\\le
\\|D_\\eta b_\\varepsilon\\|_{C^0}
\\|h_1-h_2\\|_{C^0}.
\\]

Since \\(b_1^{-1}\\) has uniformly bounded Lipschitz constant, with bound \\(\\|Df^{-1}\\|+O(\\delta_\\varepsilon)+O(L)+O(\\omega(\\rho))\\), we get the base preimage estimate

\\[
d_M(x_1,x_2)
\\le
\\mu_{\\mathrm{base}}
\\|h_1-h_2\\|_{C^0},
\\]

where

\\[
\\mu_{\\mathrm{base}}
\\le
C\\|D_\\eta b_\\varepsilon\\|_{C^0}
\\le
C(\\delta_\\varepsilon+\\omega(\\rho)).
\\]

All values below are transported to the common target fibre \\(E_y\\). Using

\\[
g_\\varepsilon(m,\\eta)=
\\tau_{b_\\varepsilon(m,\\eta)\\leftarrow f(m)}B_m\\eta+r_\\varepsilon(m,\\eta),
\\]

split the difference into a pure fibre shift at \\(x_1\\) and a base-induced shift from \\(x_1\\) to \\(x_2\\). The pure fibre term is bounded by

\\[
\\left(\\nu_0+C\\delta_\\varepsilon+\\omega(\\rho)\\right)
\\|h_1-h_2\\|_{C^0},
\\]

where \\(\\nu_0=\\sup_m\\|B_m\\|<1\\). The base-induced term is bounded by

\\[
\\mu_{\\mathrm{base}}
\\left[
C\\delta_\\varepsilon+\\omega(\\rho)
+L(\\nu_0+C\\delta_\\varepsilon+\\omega(\\rho))
\\right]
\\|h_1-h_2\\|_{C^0}.
\\]

The terms coming from the variation of the fibre transports are included in the same \\(C\\delta_\\varepsilon+\\omega(\\rho)\\) bound, since the target bases differ by \\(O(\\|D_\\eta b_\\varepsilon\\|\\|h_1-h_2\\|)\\). Hence

\\[
\\|\\mathcal H_\\varepsilon h_1-
\\mathcal H_\\varepsilon h_2\\|_{C^0}
\\le
(\\nu_0+
\\mu)
\\|h_1-h_2\\|_{C^0},
\\]

where one may take

\\[
\\mu
=
C\\delta_\\varepsilon+\\omega(\\rho)
+
\\mu_{\\mathrm{base}}
\\left[
C\\delta_\\varepsilon+\\omega(\\rho)
+L(\\nu_0+C\\delta_\\varepsilon+\\omega(\\rho))
\\right].
\\]

Thus \\(\\mu\\to0\\) as \\(\\rho,L,\\delta_\\varepsilon\\to0\\). Choosing the constants in the order described above gives a contraction factor \\(q=\\nu_0+\\mu<1\\). The radius estimate is'''
assert old in s
s=s.replace(old,new)
out=Path('/home/user/final_manuscript_fractional_spectrum_added.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))

report='''# Evaluation of Proposed Graph-Transform Contraction Derivation

## Verdict

The derivation is valid for the one-sided normally attracting graph transform after two technical corrections:

1. Since admissible sections are initially only Lipschitz, the induced base map \\(b_h\\) should be treated as a bi-Lipschitz homeomorphism, not as a \\(C^1\\) diffeomorphism, until the fixed point is upgraded to \\(C^r\\).
2. The intermediate vertical comparison must be made after transporting all fibres to the common target fibre \\(E_y\\). Variation of the target fibre transport contributes additional small terms controlled by \\(D_\\eta b_\\varepsilon\\), and these are absorbed into \\(\\mu\\).

I implemented the corrected derivation in Appendix D.3. It remains a proof of the normally attracting graph transform only; it is not a proof of the full two-sided HPS transform.
'''
Path('/home/user/graph_transform_contraction_derivation_evaluation.md').write_text(report)
