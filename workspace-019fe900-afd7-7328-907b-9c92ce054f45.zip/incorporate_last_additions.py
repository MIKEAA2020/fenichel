from pathlib import Path
p = Path('/home/user/final_manuscript.md')
s = p.read_text()

# 1. Stronger pointwise remainder bound in Theorem 4.1
old = '''   Assume also that the base nonlinear part satisfies

   \\\[
   \\|D_\\eta b_\\varepsilon(m,\\eta)\\|
   \\le
   C\\delta_\\varepsilon+\\omega(\\rho)
   \\\]

   on the same tube. This follows from \\(D_\\eta b_0(m,0)=0\\) when \\(F_\\varepsilon\\) is \\(C^1\\)-close to \\(F_0\\).

Then there exist constants'''.replace('\\\[','\\[').replace('\\\]','\\]')
new = '''   Equivalently, after reducing the tube if necessary, these estimates imply

   \\\[
   \\|r_\\varepsilon(m,\\eta)\\|
   \\le
   C\\delta_\\varepsilon+\\omega(\\rho)\\|\\eta\\|.
   \\\]

   Assume also that the base nonlinear part satisfies

   \\\[
   \\|D_\\eta b_\\varepsilon(m,\\eta)\\|
   \\le
   C\\delta_\\varepsilon+\\omega(\\rho)
   \\\]

   on the same tube. This follows from \\(D_\\eta b_0(m,0)=0\\) when \\(F_\\varepsilon\\) is \\(C^1\\)-close to \\(F_0\\).

Then there exist constants'''.replace('\\\[','\\[').replace('\\\]','\\]')
assert old in s
s = s.replace(old, new)

# 2. Perturbative assumptions after hypothesis 3
old = '''3. For \\(\\varepsilon\\neq0\\), the maps \\(F_\\varepsilon\\) are sufficiently \\(C^1\\)-close to \\(F_0\\) on a small tube.

4. Let'''
new = '''3. For \\(\\varepsilon\\neq0\\), the maps \\(F_\\varepsilon\\) are sufficiently \\(C^1\\)-close to \\(F_0\\) on a small tube. In particular, \\(b_\\varepsilon(m,0)\\) is \\(C^1\\)-close to \\(f(m)\\), \\(g_\\varepsilon(m,0)=O(\\delta_\\varepsilon)\\), and the normal linear part \\(D_\\eta g_\\varepsilon(m,0)\\), transported to the fibre over \\(f(m)\\), is \\(O(\\delta_\\varepsilon)\\)-close to \\(B_m\\).

4. Let'''
assert old in s
s = s.replace(old, new)

# 3. Graph distance after center matching and HPS imported caveat
old = '''The graph transform acts as a contraction in the \\(C^0\\) graph metric, not in the Lipschitz norm. The Lipschitz bound is preserved separately by cone invariance. Thus the fixed point is obtained in the complete metric space \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric, while the cone estimates ensure that the transform maps \\(\\mathcal B_{\\rho,L}\\) into itself.'''
new = '''The graph transform acts as a contraction in the \\(C^0\\) graph metric, not in the Lipschitz norm. The \\(C^0\\) graph distance is measured by the maximal transported vertical separation after the center coordinates have been matched. This is the metric in which the normal hyperbolicity gap gives contraction. The Lipschitz bound is preserved separately by cone invariance. Thus the fixed point is obtained in the complete metric space \\(\\mathcal B_{\\rho,L}\\) with the \\(C^0\\) metric, while the cone estimates ensure that the transform maps \\(\\mathcal B_{\\rho,L}\\) into itself.'''
assert old in s
s = s.replace(old, new)

old = '''The \\(C^0\\) contraction gives the zeroth-order estimate; derivative estimates require these lifted jet contractions.

---

## 5. Fenichel persistence theorem'''
new = '''The \\(C^0\\) contraction gives the zeroth-order estimate; derivative estimates require these lifted jet contractions.

Thus Theorem 4.1 is the imported HPS mechanism. A fully self-contained proof would require carrying out the Hadamard graph transform and its jet extensions in the stated Banach-bundle category; otherwise one should cite a source that proves this version with the required uniformity.

---

## 5. Fenichel persistence theorem'''
assert old in s
s = s.replace(old, new)

# 4. Parabolic additions in Section 8.2
old = '''be an interpolation scale, with \\(X_1=D(A)\\). Consider a semilinear parabolic fast-slow system of the form'''
new = '''be an interpolation scale, with \\(X_1=D(A)\\). Since \\(A\\) is sectorial on \\(X_0\\), it generates an analytic semigroup. In an interpolation scale one has estimates of the form

\\[
\\|e^{At}\\|_{\\mathcal L(X_0,X_\\theta)}
\\le
C t^{-\\theta}e^{at},
\\qquad t>0.
\\]

These smoothing estimates are part of the functional framework and replace the bounded-map estimates used in the compact invertible theorem. Consider a semilinear parabolic fast-slow system of the form'''
assert old in s
s = s.replace(old, new)

old = '''generates a uniformly exponentially dichotomous analytic semigroup. In particular, spectral separation alone is not sufficient. One requires uniform semigroup estimates, uniformly bounded dichotomy projections, and uniform resolvent bounds.

The Perron operator is formulated in weighted mild-solution spaces. For a stable coordinate \\(a\\), the stable and unstable components are given by'''
new = '''generates a uniformly exponentially dichotomous analytic semigroup. In particular, spectral separation alone is not sufficient. One requires uniform semigroup estimates, uniformly bounded dichotomy projections, and uniform resolvent bounds. A typical sufficient hypothesis is a uniform resolvent estimate: for some \\(\\eta>0\\),

\\[
\\sup_{v\\in Y_0}
\\sup_{\\operatorname{Re}\\lambda\\ge -\\eta}
\\|(\\lambda-L_v)^{-1}\\|_{\\mathcal L(X_0)}
<\\infty,
\\]

together with uniform bounds on the associated spectral or dichotomy projections.

The Perron operator is formulated in weighted mild-solution spaces such as

\\[
C_\\gamma([0,\\infty),X_\\theta)
:=
\\left\\{
\\eta:
\\|\\eta\\|_\\gamma
=
\\sup_{t\\ge0}e^{\\gamma t}\\|\\eta(t)\\|_{X_\\theta}
<\\infty
\\right\\}.
\\]

For a stable coordinate \\(a\\), the stable and unstable components are given by'''
assert old in s
s = s.replace(old, new)

old = '''and

\\[
\\eta^u(t)
=
-
\\int_t^\\infty
e^{L^u(t-s)}P^uR(s,\\eta(s))\\,ds.
\\]

The analytic smoothing estimates give convolution bounds of the form'''
new = '''and

\\[
\\eta^u(t)
=
-
\\int_t^\\infty
e^{L^u(t-s)}P^uR(s,\\eta(s))\\,ds.
\\]

The unstable integral is meaningful only on a backward well-posed unstable subspace. In many parabolic applications the unstable space is finite-dimensional, so backward evolution on that subspace is well-defined. In purely normally attracting problems, the unstable term is absent and the construction simplifies.

The analytic smoothing estimates give convolution bounds of the form'''
assert old in s
s = s.replace(old, new)

# 5. Noncompact additions
old = '''Let \\(M\\) be a complete finite-dimensional \\(C^{r+1}\\) manifold with bounded geometry. Assume the existence of a uniform tubular radius, uniformly bounded bundle projections, uniform exponential dichotomy estimates, and uniform bunching constants.'''
new = '''Let \\(M\\) be a complete finite-dimensional \\(C^{r+1}\\) manifold with bounded geometry. Bounded geometry may be taken to include a positive injectivity radius, uniformly bounded curvature and covariant derivatives up to the required order, a uniformly controlled bundle atlas, a uniform tubular radius, uniformly bounded bundle projections, and uniformly bounded derivatives of \\(f\\), \\(f^{-1}\\), \\(B\\), and the nonlinear terms. Assume uniform exponential dichotomy estimates and uniform bunching constants.'''
assert old in s
s = s.replace(old, new)

old = '''is complete in the \\(C^0\\) metric. The graph transform is defined globally using the uniform cone fields, and the contraction estimates are uniform in the base point.

If \\(M\\) has boundary, one must impose inflowing or overflowing invariance conditions, or introduce a localized cutoff.'''
new = '''is complete in the \\(C^0\\) metric. The graph transform is defined globally using the uniform cone fields, and the contraction estimates are uniform in the base point.

For global invariance one must ensure that orbits remain in the region where the tube and estimates are valid. Common hypotheses are: global definition and uniform closeness on the relevant region; a cutoff outside a controlled neighbourhood; a local theorem combined with continuation while the orbit remains in the tube; or inflowing/overflowing invariance when a boundary is present.

If \\(M\\) has boundary, one must impose inflowing or overflowing invariance conditions, or introduce a localized cutoff.'''
assert old in s
s = s.replace(old, new)

# 6. Banach-dimensional additions
old = '''with \\(N_m\\) complemented. Assume the existence of a \\(C^r\\) tubular neighbourhood with uniformly bounded derivatives. In Hilbert spaces this is natural, since orthogonal complements are available.'''
new = '''with \\(N_m\\) complemented. Unlike the finite-dimensional case, a tubular neighbourhood theorem is not automatic for arbitrary Banach submanifolds. One should assume explicitly that \\(M\\) is a split submanifold, the normal bundle is complemented, and the tubular chart and its inverse have uniformly bounded derivatives up to the required order. In Hilbert spaces this is natural, since orthogonal complements are available.'''
assert old in s
s = s.replace(old, new)

old = '''The proof then proceeds in bounded section spaces \\(C_b^k(M,N)\\). Bunching is formulated in an adapted Finsler metric. The Hirsch–Pugh–Shub section theorem applies with uniform constants.'''
new = '''The proof then proceeds in bounded section spaces \\(C_b^k(M,N)\\). Bunching is formulated in an adapted Finsler metric. The adapted metric must be uniformly equivalent to the original Banach norm, or the equivalence constants must be tracked explicitly. For \\(C^r\\) regularity on Banach bases, one must control the jet or difference-quotient theory in uniformly bounded charts. The main complications are lack of local compactness, possible absence of smooth partitions of unity, derivative loss in composition operators, and the need for uniform transition-map estimates. The Hirsch–Pugh–Shub section theorem applies with uniform constants.'''
assert old in s
s = s.replace(old, new)

# 7. Random additions
old = '''be a random cocycle. Assume that the normal linear cocycle \\(B(\\omega)\\) admits a random exponential dichotomy, either uniform or tempered. The Perron operator is defined pathwise, and the fixed point yields a random invariant section'''
new = '''be a random cocycle. Assume that the normal linear cocycle \\(B(\\omega)\\) admits a random exponential dichotomy, either uniform or tempered. In the tempered case the dichotomy estimates take the form

\\[
\\|\\Phi^s(\\omega,n)\\|
\\le
C(\\omega)e^{-\\alpha n},
\\qquad
\\|\\Phi^u(\\omega,-n)\\|
\\le
C(\\omega)e^{-\\alpha n},
\\]

where \\(C(\\omega)\\) is tempered. The Perron map is then defined on tempered weighted spaces whose norms depend on \\(\\omega\\). The Perron operator is defined pathwise, and the fixed point yields a random invariant section'''
assert old in s
s = s.replace(old, new)

old = '''Measurability follows from measurable selection or from convergence of measurable iterates. In infinite-dimensional random settings, the multiplicative ergodic theorem may be used to verify the dichotomy under compactness or quasi-compactness assumptions; see Ruelle [7].'''
new = '''Measurability follows from measurable selection or from convergence of measurable iterates. In infinite-dimensional random settings, the multiplicative ergodic theorem may be used to verify the dichotomy under compactness or quasi-compactness assumptions; see Ruelle [7]. In Banach spaces this typically also requires measurability of projections and integrability of logarithmic growth. In many applications one assumes the random dichotomy directly and uses the multiplicative ergodic theorem only as a verification tool.'''
assert old in s
s = s.replace(old, new)

# 8. Quasilinear additions
old = '''The invariant graph is sought in a stronger space \\(X_{s+\\sigma}\\), while residuals are estimated in \\(X_s\\). If parabolic smoothing recovers the lost derivatives, the Perron method applies directly. If not, a Nash–Moser scheme may be required; see Hamilton [8].'''
new = '''The invariant graph is sought in a stronger space \\(X_{s+\\sigma}\\), while residuals are estimated in \\(X_s\\). A typical tame estimate has the form

\\[
\\|F(h)\\|_s
\\le
C_s(1+\\|h\\|_{s+\\sigma}),
\\]

while the linear inverse may satisfy a loss estimate

\\[
\\|\\mathcal Gq\\|_s
\\le
C_s\\|q\\|_{s+\\sigma}.
\\]

If parabolic smoothing or maximal regularity recovers the lost derivatives, the Perron method applies directly. For quasilinear parabolic equations, maximal regularity often replaces the elementary semigroup estimate. One may work in spaces such as

\\[
L^p(0,T;X_1)\\cap W^{1,p}(0,T;X_0),
\\]

or in Hölder spaces adapted to the interpolation scale. If smoothing is unavailable, a Nash–Moser scheme may be required; see Hamilton [8].'''
assert old in s
s = s.replace(old, new)

out = Path('/home/user/final_manuscript_newly_revised.md')
out.write_text(s)
print(out, len(s.splitlines()), len(s))
