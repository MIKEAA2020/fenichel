# Evaluation of Proposed Appendix B Before Implementation

## Verdict

Do **not** insert the proposed Appendix B verbatim. It contains the right strategic idea—prove the Banach-fibre HPS theorem in the paper rather than leaving it as an uncited standard extension—but the proposed proof is not yet journal-ready. Several parts are correct or salvageable, but there are also structural errors and underproved steps.

The most serious issue is that the appendix asserts forward invariance of center cones in a two-sided normally hyperbolic setting. That assertion is generally false when unstable directions are present.

## Critical issues

### 1. Forward center-cone invariance is false in the two-sided case

The proposed B.4 states:

> \(DF_\varepsilon\) maps center cones strictly inside center cones.

This is false for a normally hyperbolic map with unstable normal directions.

A linear witness is

\[
F(c,s,u)=(c,\tfrac12 s,2u).
\]

Let the center cone be

\[
\|(s,u)\|\le \kappa |c|.
\]

The vector

\[
(c,s,u)=(1,0,0.75\kappa)
\]

lies in the center cone, but its image is

\[
(1,0,1.5\kappa),
\]

which does not lie in the same center cone. Thus forward center-cone invariance fails as soon as the unstable direction expands faster than the center.

The HPS/Hadamard graph transform in the two-sided case does not rely on simple forward center-cone invariance. It uses stable matching in backward time and unstable matching in forward time, or an equivalent two-sided transform. The appendix should replace this claim with a statement that the Hadamard transform preserves admissible graphs by two-sided stable/unstable matching.

### 2. The Hadamard matching equations are plausible but need a stronger invariance proof

The proposed matching equations

\[
\eta^s(m)
=
B_{f^{-1}(m)}^s
\left[
 h^s(b_-(m,\eta(m)))-R_-^s(m,\eta(m))
\right]
\]

and

\[
\eta^u(m)
=
(B_m^u)^{-1}
\left[
 h^u(b_+(m,\eta(m)))-R_+^u(m,\eta(m))
\right]
\]

are a reasonable way to express the two-sided Hadamard transform. In the unperturbed linear case they reduce to the standard contracting formulas.

However, B.9 does not fully prove that a fixed point of this transform is an invariant graph. It invokes a “standard HPS matching lemma” and then argues by fibrewise uniqueness, but the uniqueness statement itself needs to be formulated and proved.

The proof also appeals to the Section 5 argument that \(f_\varepsilon\) is a diffeomorphism. That is acceptable if equality of invariant sets is deferred to the main Fenichel theorem, but it is circular if Theorem B itself claims equality before proving \(f_\varepsilon\) is a diffeomorphism.

A safer theorem statement would first conclude local graph invariance in the form

\[
F_\varepsilon(m,h(m))=(f_\varepsilon(m),h(f_\varepsilon(m)))
\]

with \(f_\varepsilon\) close to \(f\), and then prove equality after the local-diffeomorphism-close-to-identity lemma.

### 3. Lipschitz preservation has a non-small term

In B.8 the remainder estimate contains

\[
\|R_-^s(m_1,\eta(m_1))-R_-^s(m_2,\eta(m_2))\|
\le C d_M+(C\delta_\varepsilon+\omega(\rho))d_\eta.
\]

The term \(C d_M\) is not small. It cannot then be absorbed into

\[
\mu(\rho,L,
\delta_\varepsilon)(d_M+d_\eta)
\]

unless one has shown that the relevant base derivative of the remainder is small.

The estimate should instead be of the form

\[
\|R_-^s(m_1,\eta(m_1))-R_-^s(m_2,\eta(m_2))\|
\le
(C\delta_\varepsilon+\omega(\rho))(d_M+d_\eta).
\]

This follows only under stronger smallness assumptions on the full derivative of the nonlinear remainder, including the base derivative. The appendix should state those hypotheses explicitly.

### 4. Jet extension is still too schematic

B.11–B.12 are the right idea, but not yet a self-contained proof. They say transported difference quotients converge by the “standard HPS argument” and that the induced transform is a contraction. For a journal-ready self-contained appendix, one must specify:

- the jet/difference-quotient spaces;
- the induced graph transform on those spaces;
- the exact contraction estimate for first and higher jets;
- how lower-order Faà di Bruno terms enter;
- why continuous projections are enough, or otherwise assume enough regularity of the splitting;
- how the local chart estimates patch globally.

As written, this is a proof outline, not a complete proof.

### 5. Regularity assumptions on the splitting/projections are underspecified

The statement assumes a topological splitting with continuous uniformly bounded projections. For \(C^r\) graph regularity and jet transforms, this is not enough unless one explicitly works in the HPS topological-jet/difference-quotient framework.

The appendix should choose one of two routes:

1. assume the splitting and projections have enough regularity; or
2. formulate the full transported difference-quotient theorem and prove the required estimates.

The current text mixes both approaches.

### 6. Parameter dependence is underproved

B.14 says that composition and inversion of \(C^{r+1}\) maps are \(C^\ell\) in the \(C^0\) section topology and that parameter regularity follows from the parameter-dependent contraction theorem. This is plausible at \(C^0\), but the claimed higher parameter regularity under bunching needs a more precise mixed base/parameter jet argument.

The statement should be weakened or expanded.

### 7. The theorem statement may be stronger than the proof

The theorem statement concludes

\[
F_\varepsilon(\operatorname{graph}h_\varepsilon)=\operatorname{graph}h_\varepsilon.
\]

But the appendix first constructs a Lipschitz section, only later upgrades it to \(C^r\), and only indirectly gets the internal map \(f_\varepsilon\). Equality of the image requires showing that \(f_\varepsilon\) is onto, typically by the compact local-diffeomorphism-close-to-identity argument.

This should either be included in the appendix or left to the main theorem.

## What is worth keeping

The following parts are valuable and should be retained after correction:

1. the statement that the Banach-bundle HPS theorem should be proved rather than cited vaguely;
2. the adapted one-step reduction, with the existing warning about uniform equivalence of adapted norms;
3. the section-space and transported-difference setup;
4. the Hadamard matching equations, after tightening hypotheses;
5. the fibrewise contraction proof for the matching equations;
6. the \(C^0\) contraction estimate for the graph transform;
7. the iterate-reduction lemma;
8. the quantitative \(O(\varepsilon)\) estimate strategy.

## Required corrections before implementation

Before inserting Appendix B, revise it as follows:

1. Delete the false claim that \(DF_\varepsilon\) maps center cones strictly inside center cones in the two-sided case.
2. Replace it with a two-sided admissible-graph preservation lemma based on stable/unstable matching.
3. Strengthen the nonlinear remainder hypotheses to include small base derivatives of the remainders needed for Lipschitz preservation.
4. Prove the HPS matching lemma, or explicitly state it as a lemma and prove it from the contraction estimates.
5. Avoid circular use of the main Section 5 diffeomorphism argument inside the appendix; either include the proof or state only local graph invariance until the main theorem proves equality.
6. Make a clean choice between smooth splitting assumptions and continuous-projection/difference-quotient assumptions.
7. Expand or weaken the parameter-dependence claim.
8. Present B.11–B.12 as a proof outline unless the full jet/difference-quotient estimates are supplied.

## Recommendation

Do not implement the proposed appendix verbatim. The right next step is to add a shorter, corrected appendix that proves the Banach-bundle HPS theorem at the level actually supportable in the manuscript, or to label the appendix as a detailed proof outline and keep the theorem as an imported HPS mechanism with precise assumptions.

If the goal is a fully self-contained journal proof, the appendix needs substantial rewriting before insertion.
